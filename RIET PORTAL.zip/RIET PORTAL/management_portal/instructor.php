<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
<a href="student information"></a>
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <title>Dashboard</title>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
       <?php
       include "sidebar.php";
       ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
            <?php
              include "header.php";
            ?>
              <div class="container-fluid">
      <div class="container">
  <div class="row">
    <div class="col-md-3">
    <h4 class="font-weight-bold text-dark">Instructors</h4>
    <?php

    ?>
    <!-- <p>you have total 11 instructions</p> -->
      <!-- Your content goes here -->
    </div>
    <div class="col-md-9">
        <div class="float-right">
        <button type="button" class="btn btn-infop-2 mr-1"style="background-color:white;"><img src="img/vector (19).svg" alt="photo" style="color: #fdfcfc;margin-right:10px;">Filtered By</button>
     <button type="button" class="p-2"style="background-color:#043c8B;border:none;color:white;"><i class="fa-solid fa-plus" style="color: #fdfcfc;margin-right:10px;"></i> </button>  instructions</button>
    <button type="button" class="p-2"style="background-color:#043c8B;border:none;color:white;"><i class="fa-solid fa-plus" style="color: #fdfcfc;margin-right:10px;"></i>  <a class="link" href="updateinstructor.php" >Edit instructions</button>
    <button type="button" class="p-2"style="background-color:#043c8B;border:none;color:white;"><i class="fa-solid fa-plus" style="color: #fdfcfc;margin-right:10px;"></i>  <a class="link" href="addnewinstructor.php" >Add instructions</button>
</div>
      <!-- Another column, taking up the other half of the container -->
    </div>
  </div>
</div>
    <section class="intro">
  <div class=" h-100">
    <div class="mask d-flex align-items-center h-100">
      <div class="container"style="background-color:white;border-radius:6px;">
        <div class="row justify-content-center">
          <div class="col-12">
            <div class="table-responsive">
              <table class="table mb-0">
              <thead>
                 <tr>
                 <th>Instructor id</th>
                    <th>Instructor name</th>
                    <!-- <th>Instructor type</th> -->
                    <th>Email</th>
                    <th>Role</th>
                    
                    <th>Assigned_course</th>
                    <th>Batch</th>
                  </tr>
              </thead>
                <tbody>
                <?php 
include "db.php";
$query = "SELECT * FROM add_instructor";
$select_all_posts_query = mysqli_query($connection, $query);

while($row = mysqli_fetch_assoc($select_all_posts_query)) {
    $Instructor_id =  $row['Instructor_id'];
   $Instructor_name =  $row['Instructor_name'];
   $Email =  $row['Email'];
   $Role =  $row['Role'];
   $Assigned_course=  $row['Assigned_course'];
   $Batch=$row['Batch'];



  
// Assuming $post_id is defined and contains the post ID value

// Example va


?>
                
                <tr>
                    <th scope="row"><input type="checkbox"class="mr-2"> <?php echo $Instructor_id; ?></th>
                    <td><?php echo $Instructor_name ;?></td>
                    <td><?php echo $Email ;?></td>
                    <td><?php echo $Role; ?></td>
                    <td><?php echo $Assigned_course; ?></td>
                    <td><?php echo $Batch; ?></td>                  
                  </tr> 

                  <?php 
}
                  ?>
  
                </tbody>
              
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

                </div>
                <!-- /.container-fluid -->
  
            </div>
            <!-- End of Main Content -->
            <?php
include "footer.php";
?>
  
  
        </div>

       
        <!-- End of Content Wrapper -->
        </div>
         
                  <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>