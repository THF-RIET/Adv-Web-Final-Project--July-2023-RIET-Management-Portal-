
<!DOCTYPE html>
<html lang="en">
<head>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
<a href="student information"></a>
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <title>Dashboard</title>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
       <?php
       include "sidebar.php";
       ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
            <?php
              include "header.php";
            ?>

    <div class="container" style="width: 21.75rem;height: 37rem;border-radius: 1.25rem;background: #FFF; position:relative;top:30px;">
        <h2 style="text-align: center; top:15px;position:relative; color: #222;
font-family: Inter;
font-size: 1.25rem;
font-style: normal;
font-weight: 600;
line-height: normal;">Update Instructor</h2>
        <form  action="" method="post">
           
           <input type="text" id="Instructor ID" name="Instructor ID" placeholder="Instructor Id" required style="  width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;background: #ECECEC; position:relative; top:17px;">

           <br>
           <br><input type="text" id="Instructor name" name="Instructor name" placeholder="Instructor name" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;background: #ECECEC; position:relative; top:13px;">

           <br>
           <br><input type="text" id="name" name="name" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;;background: #ECECEC; position:relative; top:13px;">

           <br>
           <br><input type="text" id="Email" name="Email" placeholder="Email" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem; border:#ECECEC;background: #ECECEC; position:relative; top:13px;">
           
           <br>
           <br><input type="text" id="Instructor Type" name="Instructor Type" placeholder="Instructor Type" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;background: #ECECEC; position:relative; top:13px;">

           <br>
           <br><input type="text" id="Role" name="Role" placeholder="Role" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC; background: #ECECEC; position:relative; top:13px;">

           <br>
           <br><input type="text" id="Assigned Course" name="Assigned Course" placeholder="Assigned Course" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;background: #ECECEC; position:relative; top:13px;">

           <br>

           <br><input type="text" id="Batch" name="Batch" placeholder="Batch" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;background: #ECECEC; position:relative; top:13px;">

            <br>
       
        </form>
        <br>
        <input  style="color: #FFF;font-family: san sarif;font-size: 1rem;font-style: normal;font-weight: 600; line-height: normal;width: 6rem;height: 2.6875rem;flex-shrink: 0;border-radius: 0.5rem;background: #46972C;position:relative; left:70%; top:30px; " type="submit" value="Register">
    </div>
    
</body>
</html>
