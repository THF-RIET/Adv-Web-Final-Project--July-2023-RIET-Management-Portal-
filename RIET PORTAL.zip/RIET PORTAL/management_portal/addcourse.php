<?php
include "db.php";
if(isset($_POST['add_course'])){
    $Course_id = $_POST['Course_id'];
    $Course_name=$_POST['Course_name'];
    $Course_type=$_POST['Course_type'];
    $Instructor_name=$_POST['Instructor'];

    
    
    
    $Duration = $_POST['Duration'];
    $Fee_per_month = $_POST['fee_per_month'];
    $Batch = $_POST['Batch'];


    

    

     $insertQuery = "INSERT INTO add_course ( `Course_name`, `Course_type`, `Instructor`, `Duration`, `fee_per_month`, `Batch`) 
     VALUES ('{$Course_name}','{$Course_type}','{$Instructor_name}','{$Duration}','{$Fee_per_month}','{$Batch}')";

     $query = mysqli_query($connection, $insertQuery);
     if($query){
        header("Location: secondcourse.php");
     }else{
        die("Failed". mysqli_error($connection));
     }
    }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
<a href="student information"></a>
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <title>Dashboard</title>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
       <?php
       include "sidebar.php";
       ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
            <?php
              include "header.php";
            ?>

    <div class="container" style="width: 21.75rem;height: 37rem;border-radius: 1.25rem;background: #FFF; position:relative;top:30px;">
        <h2 style="text-align: center; top:15px;position:relative; color: #222;
font-family: Inter;
font-size: 1.25rem;
font-style: normal;
font-weight: 600;
line-height: normal;">Add New course</h2>
        <form  action="" method="post">
           
           <br><input type="text" id="Course name" name="Course_name" placeholder="Course name" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;background: #ECECEC; position:relative; top:13px;">

           <br>
           <br><input type="text" id="name" name="Course_type" placeholder="Course Type" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;;background: #ECECEC; position:relative; top:13px;">

           <br>
           <br><input type="text" id="Email" name="Instructor" placeholder="Instructor" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem; border:#ECECEC;background: #ECECEC; position:relative; top:13px;">
           
           <br>
           <br><input type="text" id="Duration" name="Duration" placeholder="Duration" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;background: #ECECEC; position:relative; top:13px;">

           <br>
           <br><input type="text" id="Role" name="fee_per_month" placeholder="Fee Per Month" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC; background: #ECECEC; position:relative; top:13px;">

           <br>

        

           <br><input type="text" id="Batch" name="Batch" placeholder="Batch" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;background: #ECECEC; position:relative; top:13px;">

            <br>
                            <input type="submit" class="btn btn-primary" name="add_course" value="add" style="color: #FFF;font-family: san sarif;font-size: 1rem;font-style: normal;font-weight: 600; line-height: normal;width: 6rem;height: 2.6875rem;flex-shrink: 0;border-radius: 0.5rem;background: #46972C;position:relative; left:70%; top:30px; ">
      
        </form>
        <br>
    </div>
    
</body>
</html>
