<?php
include "db.php";
$Course_id = $_GET['update'];
$query = "SELECT * FROM add_course where course_id= {$Course_id}";
                $select_all_posts_query = mysqli_query($connection, $query);

                while($row = mysqli_fetch_assoc($select_all_posts_query)) {
                    $course_id =  $row['Course_id'];
                   $course_name =  $row['Course_name'];
                   $course_type= $row['Course_type'];
                   $instructor =  $row['Instructor'];
                   $duration =  $row['Duration'];
                   $fee_per_month =  $row['fee_per_month'];
                   $batch=$row['Batch'];
                }
                ?>




<!DOCTYPE html>
<html lang="en">
<head>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
<a href="student information"></a>
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <title>Dashboard</title>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
       <?php
       include "sidebar.php";
       ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
            <?php
              include "header.php";
            ?>

    <div class="container" style="width: 21.75rem;height: 37rem;border-radius: 1.25rem;background: #FFF; position:relative;top:30px;">
        <h2 style="text-align: center; top:15px;position:relative; color: #222;
font-family: Inter;
font-size: 1.25rem;
font-style: normal;
font-weight: 600;
line-height: normal;">Update Course</h2>
<?php

if(isset($_POST['updatecourse'])){
    $course_id = $_POST['Course_id']; // Add this line to fetch Course_id from the form
    $course_name = $_POST['Course_name'];
    $course_type = $_POST['Course_type'];
    $instructor_name = $_POST['Instructor'];
    $duration = $_POST['Duration'];
    $fee_per_month = $_POST['Fee_per_month'];
    $batch = $_POST['Batch'];

    $updateQuery = "UPDATE `add_course` SET `Course_id`='$course_id',`Course_name`='$course_name',
    `Course_type`='$course_type',`Instructor`='$instructor_name',`Duration`='$duration',
    `fee_per_month`='$fee_per_month',`Batch`='$batch' WHERE Course_id='$course_id' ";
    
    $query = mysqli_query($connection, $updateQuery);
    
    if ($query) {
        // header_remove();
        //  header("Location:secondcourse.php");
        echo "<script type= 'text/javascript'>alert('Record Updated Successfully!');</script>";
        // exit();
    } else {
        echo 'Update failed';
    }
}
?>

        <form  action="" method="post">
        <input type="hidden" name="Course_id" value="<?php echo $Course_id; ?>">
           
           <input type="text" id="Instructor ID" name="Course_name" value="<?php echo $course_name;  ?>" required style="  width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;background: #ECECEC; position:relative; top:17px;">

           <br>
           <br><input type="text" id="Instructor name" name="Course_type" value="<?php echo $course_type;  ?>" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;background: #ECECEC; position:relative; top:13px;">


           <br>
           <br><input type="text" id="Email" name="Instructor" value="<?php echo $instructor;  ?>" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem; border:#ECECEC;background: #ECECEC; position:relative; top:13px;">
           
           <br>
           <br><input type="text" id="Instructor Type" name="Duration" value="<?php echo $duration;  ?> " required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;background: #ECECEC; position:relative; top:13px;">

           <br>
           <br><input type="text" id="Role" name="Fee_per_month" value="<?php echo $fee_per_month;  ?>" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC; background: #ECECEC; position:relative; top:13px;">

           

           <br>

           <br><input type="text" id="Batch" name="Batch" value="<?php echo $batch;  ?>" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;background: #ECECEC; position:relative; top:13px;">

            <br>
            <input  style="color: #FFF;font-family: san sarif;font-size: 1rem;font-style: normal;font-weight: 600; line-height: normal;width: 6rem;height: 2.6875rem;flex-shrink: 0;border-radius: 0.5rem;background: #46972C;position:relative; left:70%; top:30px; " type="submit" name="updatecourse" value="updatecourse">
 
        </form>
        <br>
       <!-- <button name="update_course" style="color: #FFF;font-family: san sarif;font-size: 1rem;font-style: normal;font-weight: 600; line-height: normal;width: 6rem;height: 2.6875rem;flex-shrink: 0;border-radius: 0.5rem;background: #46972C;position:relative; left:70%; top:30px; " type="submit" >Update Course</button>  -->
          </div>

  
</body>
</html>
