<?php
include "db.php";


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">




  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">


</head>

<body id="page-top">
<?php

 
    
    if (isset($_POST['add_student'])) {
      $std_id = $_POST["std_id"];
        $student_name = $_POST['student_name'];
        $Father_name =$_POST['Father_name'];
        $CNIC = $_POST['CNIC'];
        $Email = $_POST['Email'];
        $Contact = $_POST['Contact']; 
       
        
        if ($CNIC == "" || empty($CNIC)) {
            echo 'This field is required';
        } else {
//             // Use prepared statements to prevent SQL injection
            $selectQuery = "SELECT * FROM add_student WHERE CNIC = '{$CNIC}'";
            $runQuery = mysqli_query($connection, $selectQuery);
            $result = mysqli_num_rows($runQuery);
//             $stmt = mysqli_prepare($connection, $selectQuery);
if ($result > 0) {
    die('Query  failed: ' . mysqli_error($connection));
}
        


// $success = mysqli_stmt_execute($stmt);
// if ($success > 0 ) {
//     die('Query execution failed: ' . mysqli_error($connection));
// }

// $result = mysqli_stmt_get_result($stmt);
// if ($result == false) {
//     die('Getting result failed: ' . mysqli_error($connection));
// }
//  else {
                
                $insertQuery = "INSERT INTO add_student(std_id, student_name, Father_name, CNIC, Email, Contact)
                 VALUES ('$std_id','$student_name','$Father_name','$CNIC','$Email','$Contact')";
                $conquery = mysqli_query($connection, $insertQuery);
                // mysqli_stmt_bind_param($stmt, $category_title);
                // $query = mysqli_stmt_execute($stmt);
                if ($conquery) {
                    echo 'Data Inserted';
                  
                } else {
                    echo 'Data not Inserted';
                }
            }
        }
    

?>


  <div id="wrapper">

    <!-- Sidebar -->
    <?php
    include "sidebar.php";
    ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <?php
        include "header.php";
        
        ?>

<div class="container" style="width: 21.75rem;height: 37rem;border-radius: 1.25rem;background: #FFF; position:relative;top:30px;">
        <h2 style="text-align: center; top:15px;position:relative; color: #222;
font-family: Inter;
font-size: 1.25rem;
font-style: normal;
font-weight: 600;
line-height: normal;">Add New Student</h2>
        <form  action="" method="post">
           
           <br><input type="text" id="Course name" name="std_id" placeholder="std id" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;background: #ECECEC; position:relative; top:13px;">

           <br>
           <br><input type="text" id="name" name="student_name" placeholder="student name" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;;background: #ECECEC; position:relative; top:13px;">

           <br>
           <br><input type="text" id="Email" name="Father_name" placeholder="Father name" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem; border:#ECECEC;background: #ECECEC; position:relative; top:13px;">
           
           <br>
           <br><input type="text" id="Duration" name="CNIC" placeholder="CNIC" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;background: #ECECEC; position:relative; top:13px;">

           <br>
           <br><input type="text" id="Role" name="Email" placeholder="Email" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC; background: #ECECEC; position:relative; top:13px;">

           <br>

        

           <br><input type="text" id="Batch" name="Contact" placeholder="Contact" required style="width: 18.1875rem;height: 2rem;border-radius: 0.3125rem;border:#ECECEC;background: #ECECEC; position:relative; top:13px;">

            <br>
                            <input type="submit" class="btn btn-primary" name="add_student" value="add" style="color: #FFF;font-family: san sarif;font-size: 1rem;font-style: normal;font-weight: 600; line-height: normal;width: 6rem;height: 2.6875rem;flex-shrink: 0;border-radius: 0.5rem;background: #46972C;position:relative; left:70%; top:30px; ">
      
        </form>
        <br>
    </div>
      </form>
       
        <?php

        include "footer.php"
        ?>
</body>

</html>