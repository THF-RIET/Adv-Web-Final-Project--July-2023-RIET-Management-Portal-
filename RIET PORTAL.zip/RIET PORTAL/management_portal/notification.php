<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div style="width: 100%; height: 100%; background: white; box-shadow: 0px 1px 3px rgba(54, 74, 99, 0.05); border-radius: 4px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
    <div style="align-self: stretch; height: 795px; justify-content: flex-start; align-items: flex-start; display: inline-flex">
        <div style="width: 380px; padding-right: 1px; border-right: 1px #E5E9F2 solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
            <div style="width: 379px; height: 604px; flex-direction: column; justify-content: center; align-items: center; display: flex">
                <div style="width: 379px; height: 604.27px; position: relative; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                    <div style="height: 91.89px; padding-top: 24px; padding-bottom: 25px; padding-left: 24px; padding-right: 24px; border-bottom: 1px #DBDFEA solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                        <div style="width: 331px; justify-content: center; align-items: center; display: inline-flex">
                            <div style="width: 40px; align-self: stretch; padding-top: 8.45px; padding-bottom: 7.55px; padding-left: 9.83px; padding-right: 10.17px; background: #043C8B; border-radius: 20px; justify-content: center; align-items: center; display: inline-flex">
                                <div style="color: white; font-size: 14px; font-family: DM Sans; font-weight: 700; line-height: 23.10px; letter-spacing: 0.84px; word-wrap: break-word">AB</div>
                            </div>
                            <div style="align-self: stretch; padding-left: 16px; flex-direction: column; justify-content: center; align-items: flex-start; display: inline-flex">
                                <div style="padding-bottom: 0.80px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                    <div style="color: #364A63; font-size: 14px; font-family: DM Sans; font-weight: 700; line-height: 23.10px; word-wrap: break-word">Abu Bin Ishtiyak</div>
                                    <div style="color: #8094AE; font-size: 12px; font-family: DM Sans; font-weight: 400; line-height: 19.80px; word-wrap: break-word">info@softnio.com</div>
                                </div>
                            </div>
                            <div style="flex: 1 1 0; align-self: stretch; padding-top: 9px; padding-bottom: 9px; padding-left: 151.54px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                <div style="width: 18.45px; height: 18px; padding-top: 0.76px; padding-bottom: 1.49px; padding-left: 0.09px; padding-right: 14.59px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                    <div style="width: 3.76px; height: 15.75px; background: #526484"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="width: 379px; height: 52.80px; position: relative">
                        <div style="height: 18px; padding-right: 10px; left: 24px; top: 16.39px; position: absolute; opacity: 0.80; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="width: 18px; height: 18px; padding-top: 0.47px; padding-bottom: 1.23px; padding-right: 1.72px; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                <div style="width: 16.28px; height: 16.29px; background: #526484"></div>
                            </div>
                        </div>
                        <div style="left: 56px; top: 16px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 500; line-height: 20.80px; word-wrap: break-word">Personal Infomation</div>
                        </div>
                        <div style="width: 16px; height: 20.80px; padding-top: 6.07px; padding-bottom: 6.74px; padding-right: 11.34px; left: 343px; top: 36.80px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="width: 4.66px; height: 7.98px; background: #526484"></div>
                        </div>
                    </div>
                    <div style="height: 77.80px; padding-bottom: 1px; border-bottom: 1px #DBDFEA solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                        <div style="height: 76.80px; padding-top: 12px; padding-bottom: 12px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                            <div style="width: 379px; height: 52.80px; position: relative">
                                <div style="height: 18px; padding-right: 10px; left: 24px; top: 16.39px; position: absolute; opacity: 0.80; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="width: 18px; height: 18px; padding-top: 1.62px; padding-bottom: 2.36px; padding-right: 4.50px; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="width: 13.50px; height: 14.03px; background: #043C8B"></div>
                                    </div>
                                </div>
                                <div style="left: 56px; top: 16px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #043C8B; font-size: 14px; font-family: DM Sans; font-weight: 500; line-height: 20.80px; word-wrap: break-word">Notifications</div>
                                </div>
                                <div style="width: 16px; height: 20.80px; padding-top: 6.07px; padding-bottom: 6.74px; padding-right: 11.34px; left: 343px; top: 36.80px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="width: 4.66px; height: 7.98px; background: #043C8B"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="width: 331px; height: 104.56px; position: relative">
                        <div style="left: 0px; top: 0px; position: absolute; color: #8094AE; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 1.65px; word-wrap: break-word">Last Login</div>
                        <div style="left: 0px; top: 21.19px; position: absolute; color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">06-29-2020 02:39pm</div>
                        <div style="left: 0px; top: 60.28px; position: absolute; color: #8094AE; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 1.65px; word-wrap: break-word">Login IP</div>
                        <div style="left: 0px; top: 81.47px; position: absolute; color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">192.129.243.28</div>
                    </div>
                </div>
            </div>
        </div>
        <div style="flex: 1 1 0; padding-top: 40px; padding-bottom: 103.89px; padding-left: 40px; padding-right: 40px; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 20px; display: inline-flex">
            <div style="padding-top: 10.73px; padding-bottom: 10.75px; justify-content: center; align-items: center; gap: 938px; display: inline-flex">
                <div style="align-self: stretch; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 7.39px; display: inline-flex">
                    <div style="color: #364A63; font-size: 24px; font-family: DM Sans; font-weight: 700; line-height: 26.40px; word-wrap: break-word">Notifications</div>
                </div>
                <div style="padding-top: 9px; padding-bottom: 9px; padding-left: 8.77px; padding-right: 2.78px"></div>
            </div>
            <div style="height: 573.19px; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 32px; display: flex">
                <div style="width: 1112px; height: 573.19px; position: relative">
                    <div style="height: 29.19px; padding-top: 8px; padding-bottom: 7.19px; padding-left: 20px; padding-right: 1042px; left: 0px; top: 0px; position: absolute; background: #EBEEF2; border-radius: 4px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                        <div style="color: #E85347; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 2.20px; word-wrap: break-word">Unread</div>
                    </div>
                    <div style="height: 29.19px; padding-top: 8px; padding-bottom: 7.19px; padding-left: 20px; padding-right: 1042px; left: 0px; top: 339.52px; position: absolute; background: #EBEEF2; border-radius: 4px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                        <div style="width: 56px; color: #46972C; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 2.20px; word-wrap: break-word">READ</div>
                    </div>
                    <div style="width: 1112px; height: 74px; left: 0px; top: 57.52px; position: absolute; background: rgba(235, 237, 242, 0.50); border-radius: 20px; border-bottom: 1px #E5E9F2 solid">
                        <div style="width: 199px; padding-right: 426px; left: 64px; top: 37px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                            <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">2 hrs ago</div>
                            </div>
                        </div>
                        <div style="padding-right: 325px; left: 64px; top: 15px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                            <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">You have Requested to withdraw</div>
                        </div>
                        <div style="width: 45px; height: 43px; left: 13px; top: 15px; position: absolute; background: rgba(70, 151, 44, 0.40); border-radius: 9999px"></div>
                        <div style="width: 20px; height: 25px; left: 26px; top: 24px; position: absolute; color: white; font-size: 20px; font-family: DM Sans; font-weight: 700; line-height: 20px; word-wrap: break-word">N</div>
                    </div>
                    <div style="width: 1112px; height: 74px; left: 0px; top: 147.52px; position: absolute; background: rgba(235, 237, 242, 0.50); border-radius: 20px; border-bottom: 1px #E5E9F2 solid">
                        <div style="width: 199px; padding-right: 426px; left: 64px; top: 37px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                            <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">2 hrs ago</div>
                            </div>
                        </div>
                        <div style="padding-right: 325px; left: 64px; top: 15px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                            <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">You have Requested to withdraw</div>
                        </div>
                        <div style="width: 45px; height: 43px; left: 13px; top: 15px; position: absolute; background: rgba(70, 151, 44, 0.40); border-radius: 9999px"></div>
                        <div style="width: 1112px; height: 74px; left: 0px; top: 91px; position: absolute; background: rgba(235, 237, 242, 0.50); border-radius: 20px; border-bottom: 1px #E5E9F2 solid">
                            <div style="width: 199px; padding-right: 426px; left: 64px; top: 37px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">2 hrs ago</div>
                                </div>
                            </div>
                            <div style="padding-right: 325px; left: 64px; top: 15px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                                <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">You have Requested to withdraw</div>
                            </div>
                            <div style="width: 45px; height: 43px; left: 13px; top: 15px; position: absolute; background: rgba(70, 151, 44, 0.40); border-radius: 9999px"></div>
                            <div style="width: 20px; height: 25px; left: 26px; top: 24px; position: absolute; color: white; font-size: 20px; font-family: DM Sans; font-weight: 700; line-height: 20px; word-wrap: break-word">N</div>
                        </div>
                        <div style="width: 20px; height: 25px; left: 26px; top: 24px; position: absolute; color: white; font-size: 20px; font-family: DM Sans; font-weight: 700; line-height: 20px; word-wrap: break-word">N</div>
                    </div>
                    <div style="width: 1112px; height: 74px; left: 0px; top: 503.52px; position: absolute; background: rgba(235, 237, 242, 0.50); border-radius: 20px; border-bottom: 1px #E5E9F2 solid">
                        <div style="width: 199px; padding-right: 426px; left: 64px; top: 37px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                            <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">2 hrs ago</div>
                            </div>
                        </div>
                        <div style="padding-right: 325px; left: 64px; top: 15px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                            <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">You have Requested to withdraw</div>
                        </div>
                        <div style="width: 45px; height: 43px; left: 13px; top: 15px; position: absolute; background: rgba(70, 151, 44, 0.40); border-radius: 9999px"></div>
                        <div style="width: 20px; height: 25px; left: 26px; top: 24px; position: absolute; color: white; font-size: 20px; font-family: DM Sans; font-weight: 700; line-height: 20px; word-wrap: break-word">N</div>
                    </div>
                    <div style="width: 1112px; height: 74px; left: 0px; top: 397.52px; position: absolute; background: rgba(235, 237, 242, 0.50); border-radius: 20px; border-bottom: 1px #E5E9F2 solid">
                        <div style="width: 199px; padding-right: 426px; left: 64px; top: 37px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                            <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">2 hrs ago</div>
                            </div>
                        </div>
                        <div style="padding-right: 325px; left: 64px; top: 15px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                            <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">You have Requested to withdraw</div>
                        </div>
                        <div style="width: 45px; height: 43px; left: 13px; top: 15px; position: absolute; background: rgba(70, 151, 44, 0.40); border-radius: 9999px"></div>
                        <div style="width: 20px; height: 25px; left: 26px; top: 24px; position: absolute; color: white; font-size: 20px; font-family: DM Sans; font-weight: 700; line-height: 20px; word-wrap: break-word">N</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>