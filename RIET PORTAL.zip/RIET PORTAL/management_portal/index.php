<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
<a href="student information"></a>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
       <?php
       include "sidebar.php";
       ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
            <?php
              include "header.php";
            ?>
           <div class="container">
        <div class="row">
    <div class="col-md-8">
      <h3 class="font-weight-bold text-dark">Dashboard</h3>
      <p>Welcome to Learnig Management Dashboard.</p>
      <div style="background-color:white;border-radius:6px;padding:24px 12px;">
      <div>
        <div>
    <p class="float-right ml-3 class="dropdown-toggle data-bs-toggle="dropdown" aria-expanded="false">select Batch  <img src="img/vector (10).svg" alt="photo">
    <div class="dropdown">
  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="#">Batch 2023</a></li>
  </ul>
</div>
  </p>
  </div>
  <div>
    <p class="float-right class="dropdown-toggle data-bs-toggle="dropdown" aria-expanded="false">select Courses  <img src="img/vector (10).svg" alt="photo">
    <div class="dropdown">
  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="#">Adv Web Development</a></li>
    <li><a class="dropdown-item" href="#">Digital marketing</a></li>
    <li><a class="dropdown-item" href="#">Graphic Designing</a></li>
  </ul>
</div>
  </p>
</div>
</div>

      <h4 class="text-dark font-weight-bold">Active students</h4> 
      <p>How do your students visited in the time.</p>
      <div class="float-right mr-5">
      </div>
      <div>
      <p class=" class="dropdown-toggle data-bs-toggle="dropdown" aria-expanded="false">Monthly <img src="img/vector (10).svg" alt="photo">
      <div class="dropdown">
  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="#">january</a></li>
    <li><a class="dropdown-item" href="#">Febraury</a></li>
    <li><a class="dropdown-item" href="#">March</a></li>
    <li><a class="dropdown-item" href="#">April</a></li>
    <li><a class="dropdown-item" href="#">May</a></li>
    <li><a class="dropdown-item" href="#">june</a></li>
    <li><a class="dropdown-item" href="#">July</a></li>
    <li><a class="dropdown-item" href="#">August</a></li>
    <li><a class="dropdown-item" href="#">september</a></li>
    <li><a class="dropdown-item" href="#">October</a></li>
    <li><a class="dropdown-item" href="#">November</a></li>
    <li><a class="dropdown-item" href="#">December</a></li>
  </ul>
</div>
    </p>
    </div>
      <h3 class="text-dark">9.28k</h3>
      <img src="img/vector (8).svg" alt="photo">  <img src="img/percent.png" alt="photo">
    <img class="mt-2"src="img/line image.png"width="100%" alt="photo">
    <div class="container">
  <div class="row">
    <div class="col-md-6 mt-2">
      <p>01 jan, 2020</p>
    </div>
    <div class="col-md-6 mt-2">
      <p class="float-right">30 jan, 2020</p>
    </div>
  </div>
</div>
</div>
    </div>
    <div class="col-md-4">
      <div style="background-color:white;border-radius:6px;margin-top:80px;padding-top:20px;">
       <h5 class="font-weight-bold text-dark ml-3">Summary<div class="float-right text-secondary font-weight-normal">30 days <img class="mr-3"src="img/vector (10).svg" alt="photo"></div></h5>
       <div class="container p-3">
      <div class="row">
    <div class="col-md-6">
      <img src="img/circle image.png"alt="photo">
    </div>
    <div class="col-md-4 mt-3 ml-2">
   
  <h6 class="mt-5 ml-5 text-dark">Male<span class="ml-3 text-dark font-weight-bold">4,305</span></h6>
  <h6 class="mt-3 ml-5 text-dark">Female<span class="ml-3 text-dark font-weight-bold">482</span></h6>
  </div>
  </div>
</div>
    </div>
    </div>
  </div>
</div>
     <!--footer-->
     <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top border-bottom border-left border-right"style="background-color:white;">
    <p class="mb-0 text-body-secondary ml-4">@ 2023 -RIET LMS by Advance Web Application Develoment Students Of Batch July-2023</p>
  </footer>
                  <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>