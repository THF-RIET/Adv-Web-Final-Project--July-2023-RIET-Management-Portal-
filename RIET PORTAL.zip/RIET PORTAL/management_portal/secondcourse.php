

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
<a href="student information"></a>
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <title>Dashboard</title>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>


<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php 
            include "sidebar.php";
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

            <?php
                include "header.php";
             ?>
            <!-- Topbar -->
        

              <div class="container-fluid">
      <div class="container">
  <div class="row">
    <div class="col-md-3">
    <h4 class="font-weight-bold text-dark">Courses</h4>
    <!-- <p>you have total 11 instructions</p> -->
      <!-- Your content goes here -->
    </div>
    <div class="col-md-9">
        <div class="float-right">
        <button type="button" class="btn btn-infop-2 mr-1"style="background-color:white;"> <svg xmlns="http://www.w3.org/2000/svg"style="color: #fdfcfc;margin-right:10px;" width="16" height="10" viewBox="0 0 16 10" fill="none">
  <path d="M12.8909 5.57492H3.89087C3.67993 5.57492 3.50122 5.50168 3.35474 5.35519C3.20825 5.20871 3.13501 5.03 3.13501 4.81906C3.13501 4.61984 3.20825 4.44699 3.35474 4.30051C3.50122 4.15402 3.67993 4.08078 3.89087 4.08078H12.8909C13.1018 4.08078 13.2805 4.15402 13.427 4.30051C13.5735 4.44699 13.6467 4.61984 13.6467 4.81906C13.6467 5.03 13.5735 5.20871 13.427 5.35519C13.2805 5.50168 13.1018 5.57492 12.8909 5.57492ZM15.8967 1.07492C15.8967 0.863983 15.8235 0.685272 15.677 0.538788C15.5305 0.392303 15.3518 0.319061 15.1409 0.319061H1.64087C1.42993 0.319061 1.25122 0.392303 1.10474 0.538788C0.958252 0.685272 0.88501 0.863983 0.88501 1.07492C0.88501 1.28586 0.958252 1.46457 1.10474 1.61105C1.25122 1.75754 1.42993 1.83078 1.64087 1.83078H15.1409C15.3518 1.83078 15.5305 1.75754 15.677 1.61105C15.8235 1.46457 15.8967 1.28586 15.8967 1.07492ZM10.6409 8.58078C10.6409 8.36984 10.5676 8.19113 10.4211 8.04465C10.2747 7.89816 10.0959 7.82492 9.88501 7.82492H6.89673C6.68579 7.82492 6.50708 7.89816 6.3606 8.04465C6.21411 8.19113 6.14087 8.36984 6.14087 8.58078C6.14087 8.78 6.21411 8.95285 6.3606 9.09933C6.50708 9.24582 6.68579 9.31906 6.89673 9.31906H9.88501C10.0959 9.31906 10.2747 9.24582 10.4211 9.09933C10.5676 8.95285 10.6409 8.78 10.6409 8.58078Z" fill="#526484"/>
</svg> Filtered By</button>
     <button type="button" class="p-2"style="background-color:#46972C;border:none;color:white;"><i class="fa-solid fa-plus" style="color: #fdfcfc;margin-right:10px;"></i><a href="personal update.php"></a>view Course</button>
    <button type="button" class="p-2"style="background-color:#043c8B;border:none;color:white;"><i class="fa-solid fa-plus" style="color: #fdfcfc;margin-right:10px;"></i><a href="addcourse.php">Add Course</button>
</div>
      <!-- Another column, taking up the other half of the container -->
    </div>
  </div>
</div>
    <section class="intro">
  <div class=" h-100">
    <div class="mask d-flex align-items-center h-100">
      <div class="container"style="background-color:white;border-radius:6px;">
        <div class="row justify-content-center">
          <div class="col-12">
            <div class="table-responsive">
              <table class="table mb-0">
                <thead>
                 <tr>
                 <th>Course Name</th>
                    <th>Course type</th>
                    <th>Instructor</th>
                    <th>Duration</th>
                    
                    <th>Fee</th>
                    <th>Batch</th>
                  </tr>
                </thead>
                <tbody>
<?php 
include "db.php";
$query = "SELECT * FROM add_course";
$select_all_posts_query = mysqli_query($connection, $query);

while($row = mysqli_fetch_assoc($select_all_posts_query)) {
    $Course_id =  $row['Course_id'];
   $Course_name =  $row['Course_name'];
   $Course_type =  $row['Course_type'];
   $instructor =  $row['Instructor'];
   $Duration =  $row['Duration'];
   $Fee_per_month=$row['fee_per_month'];
   $Batch=$row['Batch'];



  
// Assuming $post_id is defined and contains the post ID value

// Example va


?>



                    <tr>
                    <th scope="row"><input type="checkbox"class="mr-2"> <?php echo $Course_name; ?></th>
                    <td><?php echo $Course_type ;?></td>
                    <td><?php echo $instructor; ?></td>
                    <td><?php echo $Duration; ?></td>
                   
                    <td><?php echo $Fee_per_month; ?></td>
                    <td><?php echo $Batch; ?></td>                  
                    <?php  echo "<td><a href='updatecourse.php?update={$Course_id}'><button type='button' class='p-2'style='background-color:#46972C;border:none;color:white;' >Edit</button></td></a> ";             ?>
                  </tr>

                  <?php 
}
                  ?>
                  </tbody>
               
              
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

        </div>
        <!-- End of Content Wrapper -->
  
    </div>
    <?php

include "footer.php";


?>
                  <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>