<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <a href="student information"></a>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <title>Dashboard</title>
    <!-- Link your CSS file -->
    <link rel="stylesheet" href="style.css">
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <style>
        button {
            width: 80px;
            padding: 4.45px 10.17px 4.55px 10.83px;
            background: green;
            border-radius: 10px;
            display: flex;
            align-items: center;
            color: white;
            position: relative;
            left: 100%;
            /* font-size: 13px; */
            font-family: Montserrat;
            /* font-weight: 400; */
            /* line-height: 16.25px; */
            /* word-wrap: break-word */
        }
    </style>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <div class="sidebar">
            <ul class="navbar-nav  sidebar sidebar-dark accordion" id="accordionSidebar">

                <!-- Sidebar - Brand -->
                <a style="background-color: #46972C;" sidebar-brand d-flex align-items-center justify-content-center>
                    <div class="sidebar-brand-icon p-2">
                        <img class="ml-4 w-50" src="img/hunar logo.png" alt="photo">
                    </div>
                    <div class="sidebar-brand-text mx-3"></div>
                </a>
                <!-- Divider -->
                <div class="sidebar-divider my-0 px-2">
                    <!-- Nav Item - Dashboard -->
                    <li class="nav-item active bg-gray-300 mt-5" style="border-radius:6px;width:100%">
                        <a class="nav-link" href="index.php">
                            <img src="img/Vector.svg" alt="photo">
                            <span style="color:#165BAA;">Dashboard</span></a>
                    </li>
                    <!-- Divider -->
                    <div class="sidebar-divider">
                        <!-- Heading -->
                        <div class="sidebar-heading">
                        </div>
                        <!-- Nav Item - Pages Collapse Menu -->
                        <li class="nav-item">
                        <li class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                            aria-expanded="true" aria-controls="collapseTwo">
                            <a class="nav-link ml-3" href="courses.php">
                                <img src="img/Vector (1).svg" alt="photo">
                                <span class="font-weight-bold" style="Color:#8094AE;">Courses</span></a>
                        </li>
                        <!-- Nav Item - Utilities Collapse Menu -->
                        <!-- Divider -->
                        <!-- Heading -->
                        <div class="sidebar-heading">
                        </div>
                        <!-- Nav Item - Pages Collapse Menu -->
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="tables.php">
                                <img src="img/Vector (2).svg" alt="photo">
                                <span class="font-weight-bold" style="Color:#8094AE;">Instructors</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="tables.php">
                                <img src="img/Vector (2).svg" alt="photo">
                                <span class="font-weight-bold" style="Color:#8094AE;">Students</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="tables.php">
                                <img src="img/Vector (5).svg" alt="photo">
                                <span class="font-weight-bold" style="Color:#8094AE;">Enrolments</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="tables.php">
                                <img src="img/Vector (15).svg" alt="photo">
                                <span class="font-weight-bold" style="Color:#8094AE;">Announcments</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="tables.php">
                                <img src="img/Vector (16).svg" alt="photo">
                                <span class="font-weight-bold" style="Color:#8094AE;">Admin profile</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="tables.php">
                                <img src="img/Vector (17).svg" alt="photo">
                                <span class="font-weight-bold" style="Color:#8094AE;">Accounts</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="tables.php">
                                <img src="img/Vector (18).svg" alt="photo">
                                <span class="font-weight-bold" style="Color:#8094AE;">settings</span></a>
                        </li>
                        <!-- Divider -->
                        <hr class="sidebar-divider d-none d-md-block">
                    </div>
            </ul>
        </div>
        <!-- End of Sidebar -->



        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->

            <div class="header">
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->
                    <form
                        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            <button class="btn" type="button">
                                <i class="fas fa-search fa-sm"></i>
                            </button>
                            <input type="text" class="form-control bg-light border-0 small"
                                placeholder="search anything" aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">

                            </div>
                        </div>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="img/Vector (7).svg" alt="photo">
                                <!-- Counter - Alerts -->
                                <span class="badge badge-danger badge-counter"></span>
                            </a>
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    Alerts Center
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-primary">
                                            <i class="fas fa-file-alt text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 12, 2019</div>
                                        <span class="font-weight-bold">A new monthly report is ready to download!</span>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-success">
                                            <i class="fas fa-donate text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 7, 2019</div>
                                        $290.29 has been deposited into your account!
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-warning">
                                            <i class="fas fa-exclamation-triangle text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 2, 2019</div>
                                        Spending Alert: We've noticed unusually high spending for your account.
                                    </div>
                                </a>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                            </div>
                        </li>

                        <!-- Nav Item - Messages -->
                        <!-- <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-envelope fa-fw"></i> -->
                        <!-- Counter - Messages -->
                        <!-- <span class="badge badge-danger badge-counter">7</span> -->
                        </a>
                        <!-- Dropdown - Messages -->
                        <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                            aria-labelledby="messagesDropdown">
                            <h6 class="dropdown-header">
                                Message Center
                            </h6>
                            <a class="dropdown-item d-flex align-items-center" href="#">
                                <div class="dropdown-list-image mr-3">
                                    <img class="rounded-circle" src="img/undraw_profile_1.svg" alt="...">
                                    <div class="status-indicator bg-success"></div>
                                </div>
                                <div class="font-weight-bold">
                                    <div class="text-truncate">Hi there! I am wondering if you can help me with a
                                        problem I've been having.</div>
                                    <div class="small text-gray-500">Emily Fowler · 58m</div>
                                </div>
                            </a>
                            <a class="dropdown-item d-flex align-items-center" href="#">
                                <div class="dropdown-list-image mr-3">
                                    <img class="rounded-circle" src="img/undraw_profile_2.svg" alt="...">
                                    <div class="status-indicator"></div>
                                </div>
                                <div>
                                    <div class="text-truncate">I have the photos that you ordered last month, how
                                        would you like them sent to you?</div>
                                    <div class="small text-gray-500">Jae Chun · 1d</div>
                                </div>
                            </a>
                            <a class="dropdown-item d-flex align-items-center" href="#">
                                <div class="dropdown-list-image mr-3">
                                    <img class="rounded-circle" src="img/undraw_profile_3.svg" alt="...">
                                    <div class="status-indicator bg-warning"></div>
                                </div>
                                <div>
                                    <div class="text-truncate">Last month's report looks great, I am very happy with
                                        the progress so far, keep up the good work!</div>
                                    <div class="small text-gray-500">Morgan Alvarez · 2d</div>
                                </div>
                            </a>
                            <a class="dropdown-item d-flex align-items-center" href="#">
                                <div class="dropdown-list-image mr-3">
                                    <img class="rounded-circle" src="https://source.unsplash.com/Mv9hjnEUHR4/60x60"
                                        alt="...">
                                    <div class="status-indicator bg-success"></div>
                                </div>
                                <div>
                                    <div class="text-truncate">Am I a good boy? The reason I ask is because someone
                                        told me that people say this to all dogs, even if they aren't good...</div>
                                    <div class="small text-gray-500">Chicken the Dog · 2w</div>
                                </div>
                            </a>
                            <a class="dropdown-item text-center small text-gray-500" href="#">Read More Messages</a>
                        </div>
                        </li>

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img class="img-fluid rounded-circle m-1  p-2" style="background-color:#46972C"
                                    src="img/Vector.png" alt="photo">
                                <ul class="list-group">
                                    <span class="mr-2 d-lg-inline text-gray-600 small">Administrator</span>
                                    <span class="mr-2 d-lg-inline text-gray-600 small">Dr.Adeel <img
                                            src="img/Vector (6).svg" alt="photo"></span>

                                </ul>
                                <!-- <span class="mr-2 d-lg-inline text-gray-600 small" >Administrator</span>
                                    <span class="mr-2 d-lg-inline text-gray-600 small">Dr.Adeel</span> </a> -->

                                <!-- Dropdown - User Information -->
                                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                    aria-labelledby="userDropdown">
                                    <a class="dropdown-item" href="#">
                                        <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                        Profile
                                    </a>
                                    <a class="dropdown-item" href="#">
                                        <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                        Settings
                                    </a>
                                    <a class="dropdown-item" href="#">
                                        <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                        Activity Log
                                    </a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                        Logout
                                    </a>
                                </div>
                        </li>
                    </ul>
                </nav>
            </div>

            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">
                <div class="container">
                    <div class="row">

                        <div class="c col-md-4">
                            <div class="container">
                                <div class="blue-box">
                                    <div class="blue-text">AB</div>
                                </div>
                                <div class="content-wrapper">
                                    <div>
                                        <div class="name ">Abu Bin Ishtiyak <img class="img1" src="img/img2.png"
                                                alt="picture"></div>
                                        <div class="email">info@softnio.comim</div>
                                    </div>
                                </div>
                                <div class="line">
                                    <div class="stripe">
                                        <div class="inner-stripe"></div>
                                    </div>
                                </div>
                            </div>

                            <img src="img/img.png" alt="photo"><span style="color:#043c8B;margin-left:10px;">personal
                                information<img src="img/img1.png" height="10" style="margin-left: 20px;"
                                    alt="picture"></span>
                            <div class="not">
                                <img src="img/img3.png" alt="photo"><span class="text-secondary"
                                    style="margin-left: 10px;">Notification<img src="img/img1.png" height="7"
                                        style="margin-left: 20px;" alt="picture"></span>
                            </div>
                            <div class="info mt-3">
                                <div class="text-secondary m-0">
                                    <p class="mt-3">Last login</p>
                                    <p>08-29-2020 02:39pm</p>
                                    <p>Login IP</p>
                                    <p>192.129.243.28</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-8">
                            <h3 class="mt-3">personal information</h3>

                            <p class="text-secondary">Basic info, like your name and address, that you use on Nio
                                Platform.</p>
                            <div class="basic text-secondary">basic</div>
                            <div class="row" style="width: 70%; margin: 0px;">
                                <div class="element col-4">
                                    <div class="mt-3">
                                        <label for="fullname">Fullname</label>
                                    </div>
                                </div>
                                <div class="col-8">
                                    <div class="mt-3">
                                        <input class="input" type="text" name="Fullname" id="Fullname"
                                            placeholder="Abu Bin Ishtiyak">

                                    </div>
                                </div>
                                <hr class="sidebar-divider my-0">

                                <div class="element col-4 ">
                                    <div class="mt-3">
                                        <label for="Cnic">Cnic</label>
                                    </div>
                                </div>
                                <div class="col-8">
                                    <div class="mt-3">
                                        <input class="input" type="text" name="Cnic" id="Cnic"
                                            placeholder="42501815518">
                                    </div>
                                </div>
                                <hr class="sidebar-divider my-0">

                                <div class="element col-4 ">
                                    <div class="mt-3">
                                        <label for="Email">Email</label>
                                    </div>
                                </div>
                                <div class=" col-8">
                                    <div class="mt-3">
                                        <input class="input" type="text" name="Email" id="Email"
                                            placeholder="Info@gmail.com">
                                    </div>
                                </div>
                                <hr class="sidebar-divider my-0">

                                <div class="element col-4 ">
                                    <div class="mt-3">
                                        <label for="Phonenumber">Phonenumber</label>
                                    </div>
                                </div>
                                <div class="col-8 ">
                                    <div class="mt-3">
                                        <input class="input" type="text" name="Phonenumber" id="Phonenumber"
                                            placeholder="03002559852">
                                    </div>
                                </div>
                                <hr class="sidebar-divider my-0">

                                <div class="element col-4 ">
                                    <div class="mt-3">
                                        <label for="Date of Birth">Date of Birth</label>
                                    </div>
                                </div>
                                <div class="col-8">
                                    <div class="mt-3">
                                        <input class="input" type="text" name="Date of Birth " id="Date of Birth"
                                            placeholder="12 7 2002">
                                    </div>
                                </div>
                                <hr class="sidebar-divider my-0">

                                <div class="element col-4 ">
                                    <div class="mt-3">
                                        <label for="Address">Address</label>
                                    </div>
                                </div>
                                <div class="col-8">
                                    <div class="mt-3">
                                        <input class="input" type="text" name="Address " id="Address" placeholder="2337 Kildeer Drive,
                Kentucky, Canada ">
                                    </div>
                                </div>
                                <!-- <hr class="sidebar-divider my-0"> -->
                                <hr>

                                <div class="element col-4 ">
                                    <div class="mt-3">
                                        <label for="Position">Position</label>
                                    </div>
                                </div>
                                <div class="col-8">
                                    <div class="mt-3">
                                        <input class="input" type="text" name="Position " id="Position"
                                            placeholder="Institute Manager">
                                    </div>
                                </div>
                                <hr class="sidebar-divider my-0">
                                <button> <img  src="img/update.png" alt=""> Update</button>



                            </div>
                        </div>
                        <!-- Bootstrap core JavaScript-->
                        <script src="vendor/jquery/jquery.min.js"></script>
                        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

                        <!-- Core plugin JavaScript-->
                        <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

                        <!-- Custom scripts for all pages-->
                        <script src="js/sb-admin-2.min.js"></script>

                        <!-- Page level plugins -->
                        <script src="vendor/chart.js/Chart.min.js"></script>

                        <!-- Page level custom scripts -->
                        <script src="js/demo/chart-area-demo.js"></script>
                        <script src="js/demo/chart-pie-demo.js"></script>
                        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
                            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
                            crossorigin="anonymous"></script>
</body>

</html>