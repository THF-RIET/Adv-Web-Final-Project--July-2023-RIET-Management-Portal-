<?php
include "db.php";
?>
<!DOCTYPE html><!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Add New Fee Record</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    


    

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>
    <style>
      html, body {
      min-height: 100%;
      }
      body, div, form, input, select, textarea, label, p { 
      padding: 0;
      margin: 0;
      outline: none;
      font-family: Roboto, Arial, sans-serif;
      font-size: 14px;
      color: #666;
      line-height: 22px;
      }
      h1 {
      position: absolute;
      margin: 0;
      font-size: 40px;
      color: #fff;
      z-index: 2;
      line-height: 83px;
      }
      textarea {
      width: calc(100% - 12px);
      padding: 5px;
      }
      .testbox {
      display: flex;
      justify-content: center;
      align-items: center;
      height: inherit;
      padding: 20px;
      }
      form {
      width: 70%;
      padding:10px;
      border-radius: 6px;
      background: #fff;
      box-shadow: 0 0 8px  #669999; 
      }
      
      input, select, textarea {
      margin-bottom: 10px;
      border: 1px solid;
      border-radius: 3px;
      }
      input {
      width: calc(100% - 10px);
      padding: 5px;
      
      }
      input[type="date"] {
      padding: 4px 5px;
      }
      textarea {
      width: calc(100% - 12px);
      padding: 5px;
      }
      .item:hover p, .item:hover i, .question:hover p, .question label:hover, input:hover::placeholder {
      color:  #669999;
      }
      .item input:hover, .item select:hover, .item textarea:hover {
      border: 1px solid transparent;
      box-shadow: 0 0 3px 0  #669999;
      color: #669999;
     
      }
      .item {
      position: relative;
      margin: 10px 0;
      }
      .item span {
      color: red;
      }
      .week {
      display:flex;
      justfiy-content:space-between;
      }
      .colums {
      display:flex;
      justify-content:space-between;
      flex-direction:row;
      flex-wrap:wrap;
      }
      .colums div {
      width:35%;
      }
      input[type="date"]::-webkit-inner-spin-button {
      display: none;
      }
      .item i, input[type="date"]::-webkit-calendar-picker-indicator {
      position: absolute;
      font-size: 20px;
      color:  #a3c2c2;
      
      }
      .item i {
      right: 1%;
      top: 30px;
      z-index: 1;
      }
      input[type=radio], input[type=checkbox]  {
      display: none;
      }
      label.radio {
      position: relative;
      display: inline-block;
      margin: 5px 20px 15px 0;
      cursor: pointer;
      }
      .question span {
      margin-left: 30px;
      }
      .question-answer label {
      display: block;
      }
      label.radio:before {
      content: "";
      position: absolute;
      left: 0;
      width: 17px;
      height: 17px;
      border-radius: 50%;
      border: 2px solid #ccc;
      }
      input[type=radio]:checked + label:before, label.radio:hover:before {
      border: 2px solid  #669999;
      }
      label.radio:after {
      content: "";
      position: absolute;
      top: 6px;
      left: 5px;
      width: 8px;
      height: 4px;
      border: 3px solid  #669999;
      border-top: none;
      border-right: none;
      transform: rotate(-45deg);
      opacity: 0;
      }
      input[type=radio]:checked + label:after {
      opacity: 1;
      }
      .flax {
      display:flex;
      justify-content:space-around;
      }
      .btn-block {
      margin-top: 10px;
      text-align: right;
      }
      button {
      width: 150px;
      padding: 10px;
      border: none;
      border-radius: 5px; 
      background: green;
      font-size: 16px;
      color: #fff;
      cursor: pointer;
      }
    
     /* Default styles for larger screens (min-width: 600px) */
/* @media (min-width: 600px) {
  .name-item,
  .city-item {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    background-color: #666;
  }

  .name-item input,
  .name-item div {
    width: calc(100% - 80px);
  }

  .name-item div input {
    width: 97%;
  }

  .name-item div label {
    display: block;
    padding-bottom: 5px;
  }
} */

/* Responsive styles for smaller screens (max-width: 599px) */
@media (max-width: 599px) {
  .name-item,
  .city-item {
    /* Change the display to block to stack elements vertically */
    display: block;
    background-color: #666;
    /* Add padding or margins as needed for spacing */
    padding: 10px;
    margin-bottom: 10px;
  }

  .name-item input,
  .name-item div,
  .name-item div input,
  .name-item div label {
    /* Reset width or set to 100% for full width on smaller screens */
    width: 100%;
  }
}

      .itemss{
        color: black;
        position: relative;
      }
    </style>
<body class="manoo">
<?php
if (isset($_POST['submit'])) {
        $category_title = $_POST['cat_title'];
        if ($category_title == "" || empty($category_title)) {
            echo 'This field is required';
        } else {
            $selectQuery = "SELECT * from fee_record where (title) = '{$category_title}'";
            $runQuery = mysqli_query($connection, $selectQuery);
            $result = mysqli_num_rows($runQuery);
            if($result >0){
                echo "This category already exists";
            }else{
                $insertQuery = "INSERT into categories (title) VALUE ('{$category_title}') ";
                $query = mysqli_query($connection, $insertQuery);
                if ($query) {
                    echo 'Data Inserted';
                    header("Location: categories.php");
                } else {
                    echo 'Data not Inserted';
                }
            }
            
        }
    }
?>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php 
            include "sidebar.php";
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
             <?php
                include "header.php";
            
             ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                <div class="haseeb">
      <form action="" method="post">
        <h2 class="item">ADD New Fee Record </h2>
        <div class="colums">
          <div class="item">
            <label for="fname"></label>
            <input id="fname" type="text" name="fname" placeholder="Reciept ID" required/>
          </div>
          <div class="item">
            <label for="lname"> </label>
            <input id="lname" type="text" name="lname"  placeholder="SMS Form no"/>
          </div>
          <div class="item">
            <label for="address1"></label>
            <input id="address1" type="text"   name="address1" placeholder="Batch" required/>
          </div>
          <div class="item">
            <label for="address2"></label>
            <input id="address2" type="text"   name="address2" placeholder="Father Name" required/>
          </div>
          <div class="item">
            <label for="state"></label>
            <input id="state" type="text"   name="state" placeholder="Student Name" required/>
          </div>
          <div class="item">
            <label for="zip"></label>
            <input id="zip" type="text" name="zip" placeholder="Tuition Fee" required/>
          </div>
          <div class="item">
            <label for="city"></label>
            <input id="city" type="text"   name="city" placeholder="Rupees" required/>
          </div>
          <div class="item">
            <label for="eaddress"></label>
            <input id="eaddress" type="text"   name="eaddress" placeholder="Batch Start Month" required/>
          </div>
          <div class="item">
            <label for="phone"></label>
            <input id="phone" type="tel"   name="phone" placeholder="Approved Scholorship" required/>
          </div>
        </div>
        
              
        <div class="form-group">
        <input type="submit" name="submit" id="submit" value="Add" class="btn btn_primary">
        </div>
        </div>
      </form>
    </div>

                                
                                  



           
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            
  
            <!-- End of Footer -->
  
        </div>
        <!-- End of Content Wrapper -->
  
    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        
          </div>
  
    </div>
    <?php

include "footer.php";


?>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
  
</body>

</html>


