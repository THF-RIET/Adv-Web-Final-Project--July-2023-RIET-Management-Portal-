<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Batch</title>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
           
        }

        .update-form {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            /* border: 1px solid #ddd; */
            border-radius: 8px;
            background-color: #f9f9f9;
            position: relative;
            right: 17%;
           
        }

        .form-group {
            margin-bottom: 20px;
            border-radius: 20px;
background: #FFF;
height: 140px;
        } 

        label {
            display: block;
            font-size: 18px;
            margin-bottom: 15px;
        } 

        input {
            margin-bottom: 10px;
            width: 50%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            /* box-sizing: border-box; */
            border-radius: 5px;
            background: #ECECEC;
            position: relative;
           
            left: 9%;
    
        }

        .haseeb {
            background-color: #46972C;
            color: #fff;
            padding: 12px 20px;
            font-size: 16px;
            border: none;
            border-radius: 9px;
            cursor: pointer;
            margin-left: 350px;
            position: relative;
            margin-bottom:3%;
            left: 10%;
        }
        #haseeb1{
            color: black;
            position: relative;
            left: 5%;
            margin-top: 3%;
        }

        /* Media Queries for Responsive Layout */
        @media screen and (max-width: 600px) {
            .update-form {
                margin: 20px;
            }
        }

        @media screen and (max-width: 400px) {
            input, textarea {
                font-size: 14px;
            }
        }
    </style>
    <!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
<a href="student information"></a>
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <title>Dashboard</title>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        
       <?php
       include "sidebar.php";
       ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
            <?php
              include "header.php";
            ?>
</head>
<body>
<h2 id="haseeb1">Update Batch</h2>
    <div class="update-form">
     
        <form action="" method="post">
            <div class="form-group">

                <input type="text" id="batchNumber" name="batchNumber" placeholder=" Batch Number" required>
                
            <button class="haseeb" type="submit">Update</button>
        </form>
    </div>
    
    </body>
</html>
