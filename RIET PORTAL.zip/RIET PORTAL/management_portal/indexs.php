<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <a href="student information"></a>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <title>Dashboard</title>
    <!-- Link your CSS file -->
    <link rel="stylesheet" href="style.css">
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <style>
        button {
            width: 80px;
            padding: 4.45px 10.17px 4.55px 10.83px;
            background: green;
            border-radius: 10px;
            display: flex;
            align-items: center;
            color: white;
            position: relative;
            left: 100%;
            /* font-size: 13px; */
            font-family: Montserrat;
            /* font-weight: 400; */
            /* line-height: 16.25px; */
            /* word-wrap: break-word */
        }
    </style>

</head>

<body id="page-top">

<div id="wrapper">
<?php
include "sidebar.php";
?>
    <!-- Page Wrapper -->
  
        <!-- End of Sidebar -->



        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php
include "header.php";
           ?>


            <!-- Content Wrapper -->
            <div id="content-wrapper" >

                <div class="container">
                    <div class="row">

                        <div class="col-md-4">
                            <div class="container">
                                <div class="blue-box">
                                    <div class="blue-text">AB</div>
                                </div>
                                <div class="content-wrapper">
                                    <div>
                                        <div class="name ">Abu Bin Ishtiyak <img class="img1" src="img/img2.png"
                                                alt="picture"></div>
                                        <div class="email">info@softnio.comim</div>
                                    </div>
                                </div>
                                <div class="line">
                                    <div class="stripe">
                                        <div class="inner-stripe"></div>
                                    </div>
                                </div>
                            </div>

                            <img src="img/img.png" alt="photo"><span style="color:#043c8B;margin-left:10px;">personal
                                information<img src="img/img1.png" height="10" style="margin-left: 20px;"
                                    alt="picture"></span>
                            <div class="not">
                                <img src="img/img3.png" alt="photo"><span class="text-secondary"
                                    style="margin-left: 10px;"> <a href="notification.php">Notification </a><img src="img/img1.png" height="7"
                                        style="margin-left: 20px;" alt="picture"></span>
                            </div>
                            <div class="info mt-3">
                                <div class="text-secondary m-0">
                                    <p class="mt-3">Last login</p>
                                    <p>08-29-2020 02:39pm</p>
                                    <p>Login IP</p>
                                    <p>192.129.243.28</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-8">
                            <a href="updates.php">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="icon bi bi-pencil-square" viewBox="0 0 16 16">
                                    <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                    <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                                  </svg>
                                </a>
                            <h3 class="mt-3">personal information</h3>

                            <p class="text-secondary">Basic info, like your name and address, that you use on Nio
                                Platform.</p>
                            <div class="basic text-secondary">basic</div>
                            <div class="row" style="width: 70%; margin: 0px;">
                                <div class="element col-4">
                                    <div class="mt-3">
                                        <label for="fullname">Fullname</label>
                                    </div>
                                </div>
                                <div class="col-8">
                                    <div class="mt-3">
                                        <input class="input" type="text" name="Fullname" id="Fullname"
                                            placeholder="Abu Bin Ishtiyak">

                                    </div>
                                </div>
                                <hr class="sidebar-divider my-0">

                                <div class="element col-4 ">
                                    <div class="mt-3">
                                        <label for="Cnic">Cnic</label>
                                    </div>
                                </div>
                                <div class="col-8">
                                    <div class="mt-3">
                                        <input class="input" type="text" name="Cnic" id="Cnic"
                                            placeholder="42501815518">
                                    </div>
                                </div>
                                <hr class="sidebar-divider my-0">

                                <div class="element col-4 ">
                                    <div class="mt-3">
                                        <label for="Email">Email</label>
                                    </div>
                                </div>
                                <div class=" col-8">
                                    <div class="mt-3">
                                        <input class="input" type="text" name="Email" id="Email"
                                            placeholder="Info@gmail.com">
                                    </div>
                                </div>
                                <hr class="sidebar-divider my-0">

                                <div class="element col-4 ">
                                    <div class="mt-3">
                                        <label for="Phonenumber">Phonenumber</label>
                                    </div>
                                </div>
                                <div class="col-8 ">
                                    <div class="mt-3">
                                        <input class="input" type="text" name="Phonenumber" id="Phonenumber"
                                            placeholder="03002559852">
                                    </div>
                                </div>
                                <hr class="sidebar-divider my-0">

                                <div class="element col-4 ">
                                    <div class="mt-3">
                                        <label for="Date of Birth">Date of Birth</label>
                                    </div>
                                </div>
                                <div class="col-8">
                                    <div class="mt-3">
                                        <input class="input" type="text" name="Date of Birth " id="Date of Birth"
                                            placeholder="12 7 2002">
                                    </div>
                                </div>
                                <hr class="sidebar-divider my-0">

                                <div class="element col-4 ">
                                    <div class="mt-3">
                                        <label for="Address">Address</label>
                                    </div>
                                </div>
                                <div class="col-8">
                                    <div class="mt-3">
                                        <input class="input" type="text" name="Address " id="Address" placeholder="2337 Kildeer Drive,
                Kentucky, Canada ">
                                    </div>
                                </div>
                                <!-- <hr class="sidebar-divider my-0"> -->
                                <hr>

                                <div class="element col-4 ">
                                    <div class="mt-3">
                                        <label for="Position">Position</label>
                                    </div>
                                </div>
                                <div class="col-8">
                                    <div class="mt-3">
                                        <input class="input" type="text" name="Position " id="Position"
                                            placeholder="Institute 
                                            Manager">
                                    </div>
                                </div>
                                <hr class="sidebar-divider my-0">
                               


                            </div>
                            
                            <?php
                                include "footer.php";
                                ?>
                        </div>
                        <!-- Bootstrap core JavaScript-->
                        <script src="vendor/jquery/jquery.min.js"></script>
                        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

                        <!-- Core plugin JavaScript-->
                        <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

                        <!-- Custom scripts for all pages-->
                        <script src="js/sb-admin-2.min.js"></script>

                        <!-- Page level plugins -->
                        <script src="vendor/chart.js/Chart.min.js"></script>

                        <!-- Page level custom scripts -->
                        <script src="js/demo/chart-area-demo.js"></script>
                        <script src="js/demo/chart-pie-demo.js"></script>
                        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
                            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
                            crossorigin="anonymous"></script>
</body>

</html>