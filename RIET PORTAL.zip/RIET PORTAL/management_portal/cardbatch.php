<!DOCTYPE html>
<html>
  <head>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="globals.css" />
    <link rel="stylesheet" href="style.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
     
     @media (max-width: 768px) 
            .div-nk-content {
                width: 100%;
            }
.div-nk-content .div-nk-content-body {
  position: relative;
  width: 552px;
  height: 227px;
  top: 31px;
  left: 29px;
}

.div-nk-content .div-nk-block-between {
  position: absolute;
  width: 552px;
  height: 64px;
  top: 0;
  left: 0;
}

.div-nk-content .div-nk-block-head {
  display: inline-flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 8.8px;
  position: absolute;
  top: 0;
  left: 0;
}

.div-nk-content .heading-courses {
  position: relative;
  width: fit-content;
  margin-top: -1px;
  font-family: "DM Sans", Helvetica;
  font-weight: 700;
  color: #364a63;
  font-size: 28px;
  letter-spacing: -0.84px;
  line-height: 30.8px;
  white-space: nowrap;
}

.div-nk-content .text-wrapper {
  position: relative;
  width: fit-content;
  font-family: "DM Sans", Helvetica;
  font-weight: 400;
  color: #8094ae;
  font-size: 14px;
  letter-spacing: 0;
  line-height: 23.1px;
  white-space: nowrap;
}

.div-nk-content .list-wrapper {
  display: inline-flex;
  flex-direction: column;
  align-items: flex-start;
  position: absolute;
  top: 6px;
  left: 401px;
}

.div-nk-content .list {
  display: inline-flex;
  align-items: center;
  position: relative;
  flex: 0 0 auto;
}

.div-nk-content .item {
  display: inline-flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: 8px;
  position: relative;
  flex: 0 0 auto;
}

.div-nk-content .link {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 8px 19px;
  position: relative;
  flex: 0 0 auto;
  background-color: #dcef0c;
  border-radius: 4px;
  border: 1px solid;
}

.div-nk-content .emphasis {
  position: relative;
  flex: 0 0 auto;
}

.div-nk-content .span {
  display: inline-flex;
  flex-direction: column;
  align-items: center;
  padding: 0px 0px 0px 7.89px;
  position: relative;
  flex: 0 0 auto;
}

.div-nk-content .div {
  position: relative;
  width: fit-content;
  margin-top: -1px;
  font-family: "DM Sans", Helvetica;
  font-weight: 700;
  color: #0f1728;
  font-size: 13px;
  text-align: center;
  letter-spacing: 0.26px;
  line-height: 20px;
  white-space: nowrap;
}

.div-nk-content .div-card {
  width: 552px;
  position: absolute;
  top: 91px;
  left: 0;
  background-color: #ffffff;
  border-radius: 4px;
  box-shadow: 0px 1px 3px #364a630d;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.div-nk-content .div-card-inner-group {
  position: relative;
  align-self: stretch;
  width: 100%;
  height: 136.5px;
}

.div-nk-content .div-card-inner {
  width: 590px;
  padding: 1px 1px 1px;
  position: relative;
  left: -14px;
  border-bottom-width: px;
  border-bottom-style: solid;
  border-color: #dbdfea;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.div-nk-content .div-2 {
  display: inline-flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  position: relative;
  flex: 0 0 auto;
}

.div-nk-content .div-3 {
  display: inline-flex;
  align-items: center;
  padding: 0px 24.7px 0px 0px;
  position: relative;
  flex: 0 0 auto;
}

.div-nk-content .cell {
  padding: 14.49px 10px 14.01px 24px;
  display: inline-flex;
  flex-direction: column;
  align-items: flex-start;
  position: relative;
  flex: 0 0 auto;
  border-bottom-width: 1px;
  border-bottom-style: solid;
  border-color: #dbdfeae6;
}

.div-nk-content .label {
  position: relative;
  width: 18px;
  height: 18px;
  background-color: #ffffff;
  border-radius: 4px;
  border: 2px solid;
  border-color: #dbdfea;
  box-shadow: inset 0px 1px 1px 2px #10192413;
}

.div-nk-content .div-wrapper {
  padding: 12.28px 360.66px 12.22px 8px;
  display: inline-flex;
  flex-direction: column;
  align-items: flex-start;
  position: relative;
  flex: 0 0 auto;
  border-bottom-width: 1px;
  border-bottom-style: solid;
  border-color: #dbdfeae6;
}

.div-nk-content .text-wrapper-2 {
  position: relative;
  width: fit-content;
  margin-top: -1px;
  font-family: "DM Sans", Helvetica;
  font-weight: 700;
  color: #8094ae;
  font-size: 13px;
  letter-spacing: 0;
  line-height: 21.5px;
  white-space: nowrap;
}

.div-nk-content .data {
  padding: 28.49px 10px 26.51px 24px;
  display: inline-flex;
  flex-direction: column;
  align-items: flex-start;
  position: relative;
  flex: 0 0 auto;
  border-bottom-width: 1px;
  border-bottom-style: solid;
  border-color: #dbdfeae6;
}

.div-nk-content .link-wrapper {
  padding: 16px 20px 17px 8px;
  display: inline-flex;
  flex-direction: column;
  align-items: flex-start;
  position: relative;
  flex: 0 0 auto;
  border-bottom-width: 1px;
  border-bottom-style: solid;
  border-color: #dbdfeae6;
}

.div-nk-content .link-2 {
  position: relative;
  width: 426.66px;
  height: 40px;
}

.div-nk-content .heading {
  display: inline-flex;
  flex-direction: column;
  align-items: flex-start;
  padding: 0px 0px 0.14px;
  position: absolute;
  top: 10px;
  left: 62px;
}

.div-nk-content .text-wrapper-3 {
  position: relative;
  width: fit-content;
  margin-top: -1px;
  font-family: "DM Sans", Helvetica;
  font-weight: 700;
  color: #364a63;
  font-size: 15.6px;
  letter-spacing: -0.16px;
  line-height: 17.2px;
  white-space: nowrap;
}

.div-nk-content .div-user-avatar {
  display: flex;
  width: 40px;
  height: 40px;
  align-items: center;
  justify-content: center;
  padding: 8.45px 10.19px 7.55px 9.81px;
  position: absolute;
  top: 0;
  left: 0;
  background-color: #46972c;
  border-radius: 4px;
}

.div-nk-content .text-wrapper-4 {
  position: relative;
  width: fit-content;
  margin-top: -1px;
  font-family: "DM Sans", Helvetica;
  font-weight: 700;
  color: #ffffff;
  font-size: 14px;
  letter-spacing: 0.84px;
  line-height: 23.1px;
  white-space: nowrap;
}
.div-nk-content .div-card {
  width: 552px;
  position: absolute;
  top: 91px;
  left: 0;
  background-color: #ffffff;
  border-radius: 4px;
  box-shadow: 0px 1px 3px #364a630d;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
.div-nk-wrap {
  background-color: #ffffff;
  position: fixed;
  top: 25px;
  position: relative;
  width: 500px;
  margin-inline: 700px;
    position: absolute;
    top: 50px;
}

.div-nk-wrap .overlap-group {
  position: absolute;
  width: 500px;
  height: 150px;
  right: 70px;
  top: 60px;
  left: 30px;
  background-color: #ffffff;
  border-color: #dbdfea;
  border-radius: 20px;

}

.div-nk-wrap .group {
  position: absolute;
  width: 150px;
  height: 59px;
  top: 62px;
  left: 392px;
}



.div-nk-wrap .batch-number {
  position: absolute;
  width: 153px;
  top: 10px;
  left: 26px;
  font-family: "Inter-Regular", Helvetica;
  font-weight: 400;
  color: #7d7d7d;
  font-size: 12px;
  letter-spacing: 0;
  line-height: 18.9px;
  white-space: nowrap;
}

.div-nk-wrap .dashboard {
  position: absolute;
  width: 222px;
  top: -50px;
  left: 50px;
  font-family: "Inter-SemiBold", Helvetica;
  font-weight: 600;
  color: #222222;
  font-size: 20px;
  letter-spacing: 0;
  border-radius: 19px;
}
.input{
  position: absolute;
  padding: 50px;
  height: 100px;
  
}
#Name {
  padding: 8px; /* Adjust the padding as needed */
  width: 130%;
  height: 30px;
   /* Mathe input fill the container */
   /* Include padding in the input's total width */
  margin-bottom: 20px; /* Add margin at the bottom for spacing */
  border: none; /* Add a border for a cleaner look */
  border-radius: 5px;
  background-color: #dddfe3; /* Optional: Add border-radius for rounded corners */
}

.btn-warning {
  background-color: #f6ff00;
  color: rgb(9, 8, 8);
  padding: 10px 20px;
  border: none;
  position: relative;
  cursor: pointer;
  border-radius: 8px;

  /* Change background color on hover */
  &:hover {
    background-color: #ffcc00;
    /* Additional hover styles if needed */
  }
}

.btn-warning .icon {
  background-image: url('img/plus.svg'); /* Replace with the path to your icon image */
  background-size: contain; /* Adjust as needed */
  width: 20px; /* Adjust the width of the icon */
  height: 20px; /* Adjust the height of the icon */
  display: inline-block;
  vertical-align: middle; /* Align the icon vertically with the text */
  margin-right: 10px; /* Optional: Add margin to the right of the icon */
}

      

    </style>
    
  
                
            
  </head>
  <body style="background-color:  #e1e6f5;">
  
  <?php 
            include "sidebar.php";
        ?>
    <div class="div-nk-content">
   
      <div class="div-nk-content-body">
        <div class="div-nk-block-between">
          <div class="div-nk-block-head">
            <div class="heading-courses">Batch</div>
            <p class="text-wrapper">You have total 1 batch.</p>
          </div>
          <div class="list-wrapper">
            <button type="button" class="btn btn-warning">
              <i class="icon"></i> Edit Batch
            </button>

          </div>
        </div>
        <div class="div-card">
          <div class="div-card-inner-group">
            <div class="div-card-inner">
              <div class="div-2">
                <div class="div-3">
                  <div class="cell"><div class=""><input type="checkbox"class="mr-2"></div></div>
                  <div class="div-wrapper"><div class="text-wrapper-2">Batch Name</div></div>
                </div>
                <div class="div-2">
                  <div class="div-3">
                    <div class="data"><div class=""><input type="checkbox"class="mr-2"></div></div>
                    <div class="link-wrapper">
                      <div class="link-2">
                        <div class="heading"><div class="text-wrapper-3">Batch-July-2023</div></div>
                        <div class="div-user-avatar"><div class="text-wrapper-4">RD</div></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="div-nk-wrap">
      <div class="overlap-group">
        <div class="btn btn-primary" style=" position: absolute; right: 1%; width: 100px; display: inline-block; padding: 9px 12px; font-size: 14px; font-weight: 400; line-height: 1.42857143; text-align: center; white-space: nowrap; vertical-align: middle; touch-action: manipulation; cursor: pointer; user-select: none; background-image: none; border: 1px solid transparent; border-radius: 8px; color: #fff;  background: #46972C; margin: 20%; box-shadow: #222222;">Add</div>

        <div class="overlap">
          <div class="batch-number"></div>
          <div class="input">
          <input type="text" id="Name" name="Name" placeholder="Batch Number">
        </div>
        
      
      <div class="dashboard">Add New&nbsp;&nbsp;Batch</div>
      </div>
    </div>
  </div>
      </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>
