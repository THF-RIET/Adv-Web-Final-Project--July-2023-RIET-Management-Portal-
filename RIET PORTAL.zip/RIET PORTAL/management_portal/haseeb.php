<?php
include "db.php";


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">




  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">


  <style>
    body {
      min-height: 90%;
      margin-bottom: 10%;
    }

    body,
    div,
    form,
    input,
    select,
    textarea,
    label,
    p {
      padding: 0;
      margin: 0;
      outline: none;
      font-family: Roboto, Arial, sans-serif;
      font-size: 14px;
      color: #666;
      line-height: 22px;
    }

    h1 {
      position: absolute;
      margin: 0;
      font-size: 40px;
      color: #fff;
      z-index: 2;
      line-height: 83px;
    }

    textarea {
      width: calc(100% - 12px);
      padding: 5px;
    }

    .testbox {
      display: flex;
      justify-content: center;
      align-items: center;
      height: inherit;
      padding: 20px;
    }

    form {
      width: 70%;
      padding: 10px;
      border-radius: 6px;
      background: #fff;
      box-shadow: 0 0 8px #669999;
    }

    input,
    select,
    textarea {
      margin-bottom: 10px;
      border: 1px solid;
      border-radius: 3px;
    }

    input {
      width: calc(100% - 10px);
      padding: 5px;
    }

    input[type="date"] {
      padding: 4px 5px;
    }

    textarea {
      width: calc(100% - 12px);
      padding: 5px;
    }

    .item input:hover,
    .item select:hover,
    .item textarea:hover {
      border: 1px solid transparent;
      box-shadow: 0 0 3px 0 #669999;
      color: #669999;

    }

    .item {
      position: relative;
      margin: 10px 0;
      ;
    }

    .item span {
      color: red;
    }

    .week {
      display: flex;
      justfiy-content: space-between;
    }

    .colums {
      display: flex;
      justify-content: space-between;
      flex-direction: row;
      flex-wrap: wrap;
    }

    .colums div {
      width: 23%;
    }

    input[type="date"]::-webkit-inner-spin-button {
      display: none;
    }

    .item i,
    input[type="date"]::-webkit-calendar-picker-indicator {
      position: absolute;
      font-size: 20px;
      color: #a3c2c2;

    }

    .item i {
      right: 1%;
      top: 30px;
      z-index: 1;
    }

    input[type=radio],
    input[type=checkbox] {
      display: none;
    }

    label.radio {
      position: relative;
      display: inline-block;
      margin: 5px 20px 15px 0;
      cursor: pointer;
    }

    .question span {
      margin-left: 30px;
    }

    .question-answer label {
      display: block;
    }

    label.radio:before {
      content: "";
      position: absolute;
      left: 0;
      width: 17px;
      height: 17px;
      border-radius: 50%;
      border: 2px solid #ccc;
    }

    input[type=radio]:checked+label:before,
    label.radio:hover:before {
      border: 2px solid #669999;
    }

    label.radio:after {
      content: "";
      position: absolute;
      top: 6px;
      left: 5px;
      width: 8px;
      height: 4px;
      border: 3px solid #669999;
      border-top: none;
      border-right: none;
      transform: rotate(-45deg);
      opacity: 0;
    }

    input[type=radio]:checked+label:after {
      opacity: 1;
    }

    .flax {
      display: flex;
      justify-content: space-around;
    }

    .btn-block {
      margin-top: 10px;
      text-align: right;
    }

    button {
      width: 150px;
      padding: 10px;
      border: none;
      border-radius: 5px;
      background: green;
      font-size: 16px;
      color: #fff;
      cursor: pointer;
    }

    button:hover {
      background: yellow;
      position: relative;
      right: 50px
    }

    @media (min-width: 568px) {

      .name-item,
      .city-item {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        background-color: #666;
      }



      .name-item input,
      .name-item div {
        width: calc(50% - 20px);
      }

      .name-item div input {
        width: 97%;
      }

      .name-item div label {
        display: block;
        padding-bottom: 5px;
      }
    }

    .haseeb {
      color: white;
      border-radius: 2px;
      position: relative;
      padding: 10px;
    }

    .gender-checkbox {
      margin-bottom: 10px;
    }

    .flag-input {
      padding-left: 30px;
      /* Adjust as needed based on the flag size */
      background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAC3CAMAAAAGjUrGAAAAyVBMVEUPQiH///8ALgDo6Ojc4N3V1dX///4AMQAQQSEAMgAPQiAALAAAKgAANAAPQx8ANwwAKAAAOxQAPRoAPhYAPxnn7uoAOBDx9fMANwgANwCwwLUFPhyTppn7//sNRB4APBHJzcpKbVMgTjGfsKXG18ssVDrX4NgAOhzI1c5WdVtJZlI5WkWInY1og266yb/k6uU1X0OzyrtbdWRziHeuvbQlSzNtiHh8lYRefWVRbFmcraAAEQAYRis1VUAqWDg1VkNpf3KEnIq4vboV5ZAfAAAIpklEQVR4nO2df3uiSBKAadaFtgMYEBVFNKvRc6PBrDpxzDlzuf3+H+pAE0csTEI3XrV3/c4f88w8Y03zBqqrf9Bqv/8mzp2p/U/xGxGnomNfRbkoJxDlBKKcQJQTiHICUU4gyglEOYEoJxDlBKKcQJQTiHICUU4gyglEOYEoJxDlBKKcQJQTiHICUU4gyglEOYEoJxDlBKKcQJQTiHICUU4gyglEOYEoJxDlBKKcQJQTiKROaPILDUmdsFA5yRIG4R9hyTELIKETvzoY3o96pcYshHROQnO0IuN/+E6JMQsilxPK7EHHIJOaz5STHVRz212DkInus3Ii8iGTE0f/s5GEGzcxHxxNJie0X+sQYpCGhvrgaBI5ceyH9CYhxtRFLE12yOKE3c52RshjjaImE00WJzQ0432slc6Ukx2+P96HmpvYD44miRN30HgL9dQv6qRX/iBABifuqLWLY5Bh4TcLa3+FpQ8XJXDyroSQhlk4lVQrY7NXshR0J9RzWskdsmMZFP64HZPYOphkGqXME32a0J2E7j6XGAap3BT/gdtJnTe03v/kUMfV/3wSlILthFXHhziLOoeTYfLB2XsD/HawrDSagpN0yE6Yvnp/cMjY+vzfA4LUCXm0Uwtu9dswSU0L96qd0Pb6V5hXlyNC0N19dtNnTXOzq/smwtUSrpP69FeUOVeU2l5qNLJn832ckcfbmndwndjzX1FmxTudhP5z+lmDtKLdb0nCLd6fn4LohDJ9+CuIseXqLeqL45YYJDKdq3ZSfzgKMuH7+WZikIisA0d48gXTiXnohpPi5Ll4hqVUC6xlpilzq4RBNaKTJD2+d8PJPU8LPzrUr9Zn82xTFj5XU7LgOXHcQ01POHpQ6t08dVonLZlwVMIQNCe03T2O0S3Y6/TN7xPYkrV4p6Nh3ide5of8UKyqcJ8beS0xNk2eppyA5iTI3CatonnAf+iOI9iU6Kl+xX2xnrlNxoVDeDV9+xyfJhTS0nzhlWYsJ+7yKMESsrKLJ0fW69v65qWSbcy8KTwZieSE6uNMiFmfq/WU1dv67hEy9oaNiNxbjF3juJj6o2yITZ33AhzzrUQ5ZJfYcq7SSXuYDTHyuS/DvttFmPxz+9qNd3ffqsobaw+SEzPblUaUf565tu/AfniOW6ua+s/lcMwxTjgGx4l38ui0XP6Bm/u4WwWpvvXBvhvYgqsbOE6yxUnSWQT8TsLEr9Gqvw+HaZp5xUoUHCf6SV0+r2rcl8HcJLuuuSakzoDihHkRiMDvpFoh8xveT+eB4sT7A0QQuNvNOOnKy1wKRHFS655GMAXKrPbLhGcV5DwoTqoxyT48c1vASf1RdOHvBBwnlcxgh5BGINJTCC8Qn4DhhIWnw9mWh7urLwuCExp+AyG2Ze+XEAHDif8AQvyLf7xTPhhO3GcQYoG+AfQIjHxSm4EQ3dplLo8LBCfsdLST0LGxN4AegeLkBYTg21RwIVCcDEGIiG8F/TJgOLGhE7LgnnwsHzmcGGTYvtAFcoDR7+TkEzKW6HtIUJzAfocYI3kSiiT1CSEzeSoUjHzSf8wJMtYxXz3PgHGf5Ix3EqbC+xXLAsNJOMiLMrQvc4XFwXBC+2A7AEnnUGQp7zHyCa1WYBCDc4PsBUC5T+y/85w0TMG1qrJAmY9t5nXGaXf8f+zEe8qN05KkvkdaL85LsoS8yNH14Dgxc/ZxpillIEWBj+Mkt7pPKHlBjxMcJ+H2TKhnjr1+pYO0T+lki9+BaFvGhnlBkJyce3jI+EZ016I4SE569XPBhrrgrkVxkPbHMv3+ZBn9wBI9peA4YZr7/ZwTsmkil7No++2t3BcrUqKpiysFzUlzfTZeC1kK3jtNdn59/yZFPKdQ7nk7PCfB+RuFRA+BqBTa3Aw4P4rnRNPn50NGC8EFZGa//sW77R7xvVE3b/r+wMyi/Pu5nJ4+I9xL0IhO2E3u6Pid2OZ7pyfFDTqkyz0bg3leQf1bzht9bxgGaUzTt0AL5xXGmDltkLnFnZFQz3AIZuRs5ZbSve07tOClOU7dStdep/yDSVQn7PRdhFPmG6voEaG+tUlzd7fKX+JgOmGatz3/9OyJB7qvfXFUmIyoffPn7mCYZHjNfxwg8tlB/cWn0TvfvnicLHO86mC1+0xLaBoG+eygnpmz7yJDkm/iqfWFF2TDmv6wenuBdNMXmYRBP3dL73zhfxivHb3f03q5DxHVGA1dXVsf5u7WYvP/2E40lj+Hf4oRLwd6zc27Xer9QN8uj15JfxHc84TvxGl/UOO/EaUPRDQeLkaBXq25vhcmeL7v1qp6dbQYZo4uWOmCRxagO0kSQf1zKQcak1V3uXn6MRqMfkw3r93V/ek8THzlZ5Ht8cMCUj6jY13zeUoHqO+eWdqAGIejCQ5/k/nj8FZ8ilsGJ8njo8cltCNhdivaFGmcsJ71WZ3yFaKFWcbXbMjhJCnz9UVEPiv0P8KIyHxQ439NWT4nCX3nXqwZHbOkdVV5nNDw5tyC6VdoLUrbYCuPk/Qt+5+TjydU8kl7nlVf7HyPY2Rykn75zuvZpbCPmEwFpksAcjnRqBv8+/y6zxnG33Xv6s8r+AgWeLNC90rl1eSfzM5FOiea4wTB81fr2ijemK746ahZJHTCKOvfTF/23zxjnJby+5S6/7vxbGvWNVb21/XI52SPF1gP3Y/ulmiyHlm1i+yTlNWJtju90Ft0JznJZR7PNnpV/MC+M0jsZHdMX2DeNp9eZy+r+O7uLo5X3fXrSLfsfv2Cu96kdrKHeW4taNu2adp2O2i64aU3p1yBk3SEmJ497TiUUlbKKO9jrsLJfxnlBKKcQJQTiHICUU4gyglEOYEoJxDlBKKcQJQTiHICUU4gyglEOYEoJxDlBKKcQJQTiHICUU4gyglEOYEoJxDlBKKcQJQTiHICUU4gyglEOYEoJxDlBHL3uzh/y3GcZ1n8BzTYsjrJ2JTiAAAAAElFTkSuQmCC');
      background-repeat: no-repeat;
      background-size: 20px;
      /* Adjust as needed based on the flag size */
      background-position: 5px center;
      /* Adjust as needed based on the flag size and padding */
      border: 1px solid #ccc;
      /* Optional: Add border for styling */
      height: 30px;
      /* Adjust as needed based on the flag size */
    }



    .gender input[type="radio"] {
      width: 20px;
      display: inline-block;
      height: 10px;
      border: 2px solid black;
      margin-right: 5px;
    }

    .gender label {
      color: black;
      display: inline;
      margin-right: 5px;
      width: 100px;
    }

    .gender input[type="radio"]:checked {
      background-color: black;
      border-color: black;
    }

    .zakat label {
      color: black;
      display: inline;
      margin-right: 5px;
      width: 100px;
    }

    .zakat input[type="radio"] {
      width: 20px;
      display: inline-block;
      height: 10px;
      border: 2px solid black;
      margin-right: 5px;
    }

    .zakat input[type="radio"]:checked {
      background-color: black;
      border-color: black;
    }
  </style>

</head>

<body id="page-top">
<?php

 
    
    if (isset($_POST['submit'])) {
        $std_name = $_POST['sname'];
        $Father_name =$_POST['fname'];
        $Gender= $_POST['gender'];
        $CNIC = $_POST['CNIC'];
        $EMail = $_POST['email'];
        $Contact = $_POST['phone']; 
        $EContact = $_POST['e_contact'];
        $Date_of_birth = $_POST['date_B'];
        $Batch = $_POST['batch'];
        $Courses = $_POST['browser'];
        $Shift = $_POST['shift'];
        // $Zakat = $_POST['zakat'];
        $Qualifications = $_POST['qualifications'];
        $SSC = $_POST['SSC'];
        $HSC = $_POST['HSC'];
        $ScholorShip = $_POST['Scholor'];
        $Address = $_POST['Address_of'];
        $District_city = $_POST['City'];
        $Admissione = $_POST['Fee'];
        $category_title = $_POST['phone'];
        
        if ($category_title == "" || empty($category_title)) {
            echo 'This field is required';
        } else {
//             // Use prepared statements to prevent SQL injection
            $selectQuery = "SELECT * FROM update_student WHERE u_cnic = '{$CNIC}'";
            $runQuery = mysqli_query($connection, $selectQuery);
            $result = mysqli_num_rows($runQuery);
//             $stmt = mysqli_prepare($connection, $selectQuery);
if ($result > 0) {
    die('Query  failed: ' . mysqli_error($connection));
}
        


// $success = mysqli_stmt_execute($stmt);
// if ($success > 0 ) {
//     die('Query execution failed: ' . mysqli_error($connection));
// }

// $result = mysqli_stmt_get_result($stmt);
// if ($result == false) {
//     die('Getting result failed: ' . mysqli_error($connection));
// }
//  else {
                
                $insertQuery = "INSERT INTO update_student
                                (std_name, std_contact, gender, 
                                Father_name, u_cnic, email, e.contact, date_of_brth, 
                                batch, courses, shift, zakat, l_qulaification, SSC, HSC,
                                Scholor_reqiured, addres, District_city, Admission_fee) 
                                VALUES ($std_name,$Contact,$Gender,$Father_name,$CNIC,
                                $EMail,$EContact,$Date_of_birth,$Batch,$Courses,$Shift,'',
                                $Qualifications,$SSC,$HSC,$ScholorShip,$Address,$District_city,'')";

                $conquery = mysqli_query($connection, $insertQuery);
                // mysqli_stmt_bind_param($stmt, $category_title);
                // $query = mysqli_stmt_execute($stmt);
                if ($conquery) {
                    echo 'Data Inserted';
                    header("Location: student.php");
                } else {
                    echo 'Data not Inserted';
                }
            }
        }
    

?>


  <div id="wrapper">

    <!-- Sidebar -->
    <?php
    include "sidebar.php";
    ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <?php
        include "header.php";
        
        ?>

        <div class="testbox">

          <form action="" method="post">
            <h2 class="itemss">Update Student</h2>
            <div class="colums">
              <div class="item">
                <label for="fname"></label>
                <input id="fname" type="text" name="sname" placeholder="Student Name" required />
              </div>
              <div class="item">
                <label for="lname"> </label>
                <input id="lname" type="text" name="fname" placeholder="Father Name" />
              </div>
              <div class="item">



                <label for="address1"></label>

                <input class="flag-input" type="text" name="phone" value="+92" placeholder="  03064620684" required />

              </div>

              <div class="gender">
                <label for="Gender">Gender:</label>
                <label for="male">Male</label>
                <input type="radio" id="male" name="gender" value="male">

                <label for="female">Female</label>
                <input type="radio" id="female" name="gender" value="female">
              </div>
              <div class="item">
                <label for="state"></label>
                <input id="state" type="text" name="CNIC" placeholder="CNIC" required />
              </div>
              <div class="item">
                <label for="zip"></label>
                <input id="zip" type="text" name="email" placeholder="Email" required />
              </div>
              <div class="item">
                <label for="city"></label>
                <input class="flag-input" type="text" name="e_contact" placeholder="Emergency Contact" required />
              </div>
              <div class="item">
                <label for="eaddress"></label>
                <input id="eaddress" type="text" name="date_B" placeholder="Date of Birth" required />
              </div>
              <div class="item">
                <label for="phone"></label>
                <input id="phone" type="tel" name="batch" placeholder="Batch" required />
              </div>
              <div class="
          item">
                <input list="browsers" name="browser" id="browser" placeholder="Course">
                <datalist id="browsers">
                  <option value="Advance Web Application">
                  <option value="Video editing">
                  <option value="Digital Marketing">
                  <option value="Graphic">
                  <option value="Amazon ">
                </datalist>
              </div>
              <div class="item ">
                <!-- <input id="haseeb" name="shift" id="shift" placeholder="Shift"> -->
                <select id="haseeb" name="shift">
                  <option value="shift">shift</option>
                  <option value="morinig">morinig</option>
                  <option value="evening">evening</option>

                </select>
              </div>

              <!-- <div class="zakat" id="zakat" name="zakat">
                <label for="radio">Zakat:</label>


                <label for="zakat">Yes</label>
                <input type="radio" id="zakat" name="zakat" value="yes">

                <label for="zakat">No</label>
                <input type="radio" id="zakat" name="zakat" value="no">
              </div> -->

              <div class="item">
                <label for="phone"></label>
                <input id="phone" type="tel" name="qualifications" placeholder="Last Qualification" required />
              </div>


              <div class="item">
                <label for="phone"></label>
                <input id="phone" type="tel" name="SSC" placeholder="SSC" required />
              </div>

              <div class="item">
                <label for="phone"></label>
                <input id="phone" type="tel" name="HSC" placeholder="HSC" required />
              </div>

              <div class="item">
                <label for="phone"></label>
                <input id="phone" type="tel" name="Scholor" placeholder="Scholorship reqiure" required />
              </div>
              <div class="item">
                <label for="phone"></label>
                <input id="phone" type="tel" name="Address_of" placeholder="Address" required />
              </div>


              <div class="item">
                <label for="phone"></label>
                <input id="phone" type="tel" name="City" placeholder="District City" required />
              </div>

              <div class="item">
                <label for="phone"></label>
                <input id="phone" type="tel" name="Fee" placeholder="Admission Fee" required />
              </div>




              <div class="item">
                <label for="phone"></label>
                <input id="phone" type="tel" name="phone" placeholder="" required />
              </div>


            </div>


            <div class="btn-block">
          <button type="submit" href="/">Register</button>
        </div>
          </form>
        </div>




        <br>
        <?php

        include "footer.php"
        ?>
</body>

</html>