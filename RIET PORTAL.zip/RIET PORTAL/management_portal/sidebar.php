<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="sidebar">
        <ul class="navbar-nav  sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a style="background-color: #46972C;" sidebar-brand d-flex align-items-center justify-content-center
                href="index.html">
                <div class="sidebar-brand-icon p-2">
                    <img class="mr-2"src="img/hunar logo.png" alt="photo">
                     <!-- <svg xmlns="http://www.w3.org/2000/svg" width=" 21.984px" height="16.008px" viewBox="0 0 22 17" fill="none">
                        <path d="M21 9.5H0.984375C0.71875 9.5 0.488281 9.40234 0.292969 9.20703C0.0976563 9.01172 0 8.77344 0 8.49219C0 8.22656 0.0976563 7.99609 0.292969 7.80078C0.488281 7.60547 0.71875 7.50781 0.984375 7.50781H21C21.2656 7.50781 21.4961 7.60547 21.6914 7.80078C21.8867 7.99609 21.9844 8.22656 21.9844 8.49219C21.9844 8.77344 21.8867 9.01172 21.6914 9.20703C21.4961 9.40234 21.2656 9.5 21 9.5ZM21.9844 1.50781C21.9844 1.22656 21.8867 0.988281 21.6914 0.792969C21.4961 0.597656 21.2656 0.5 21 0.5H0.984375C0.71875 0.5 0.488281 0.597656 0.292969 0.792969C0.0976563 0.988281 0 1.22656 0 1.50781C0 1.77344 0.0976563 2.00391 0.292969 2.19922C0.488281 2.39453 0.71875 2.49219 0.984375 2.49219H21C21.2656 2.49219 21.4961 2.39453 21.6914 2.19922C21.8867 2.00391 21.9844 1.77344 21.9844 1.50781ZM21.9844 15.5C21.9844 15.2188 21.8867 14.9805 21.6914 14.7852C21.4961 14.5898 21.2656 14.4922 21 14.4922H0.984375C0.71875 14.4922 0.488281 14.5898 0.292969 14.7852C0.0976563 14.9805 0 15.2188 0 15.5C0 15.7812 0.0976563 16.0195 0.292969 16.2148C0.488281 16.4102 0.71875 16.5078 0.984375 16.5078H21C21.2656 16.5078 21.4961 16.4102 21.6914 16.2148C21.8867 16.0195 21.9844 15.7812 21.9844 15.5Z" fill="white"/>
                        </svg> 
                    -->
                </div>
                <div class="sidebar-brand-text mx-3"></div>
            </a>

            <!-- Divider -->
            <div class="sidebar-divider my-0 px-2">

                <!-- Nav Item - Dashboard -->
                <li class="nav-item active bg-gray-200 mt-5" style="border-radius:6px;width:100%">
                    <a class="nav-link" href="index.php">
                        <img src="img/haseeb.svg" >
                        <span class="text-primary ml-3">Dashboard</span></a>
                </li>

                <!-- Divider -->
                <div class="sidebar-divider">

                    <!-- Heading -->
                    <div class="sidebar-heading">
                    </div>

                    <!-- Nav Item - Pages Collapse Menu -->
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="secondcourse.php" >
                            
                            <img src="img/Vector (1).svg" alt="photo">
                            <span class="font-weight-bold ml-3" style="Color:#8094AE;">Courses</span>
                        </a>
                        
                    </li>

                    <li class="nav-item">
                        <a class="nav-link collapsed" href="instructor.php">
                        <img src="img/Vector (2).svg" alt="photo">
                            <span class="font-weight-bold ml-3" style="Color:#8094AE;">Instructor</span>
                        </a>
                        
                    </li>
                   
                        
                    </li>
                    <li class="nav-item">
                    <a class="nav-link collapsed" href="studentss.php">
                    <img src="img/Vector (3).svg" alt="photo">
                            <span class="font-weight-bold ml-3" style="Color:#8094AE;">Students</span>
                        </a>
                        
                    </li>
                    <!-- Nav Item - Utilities Collapse Menu -->
                    <!-- <li class="nav-item">
                    <a class="nav-link collapsed" href="fee.php">
                    <img src="img/Vector (3).svg" alt="photo">
                            <span class="font-weight-bold ml-3" style="Color:#8094AE;">enrollment</span>
                        </a>
                        
                    </li> -->
                    <!-- Divider -->
                    <!-- <hr class="sidebar-divider"> -->

                    <!-- Heading -->
                    <div class="sidebar-heading">
                    </div>

                    <!-- Nav Item - Pages Collapse Menu -->
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="" data-target="#collapsePages" aria-expanded="true"
                            aria-controls="collapsePages">
                            <img src="img/Vector (11) copy.svg" alt="photo">
                            <span class="font-weight-bold ml-3" style="Color:#8094AE;">Anouncement</span>
                        </a>
                        
                    </li>

                    <!-- Nav Item - Charts -->
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="indexs.php" >
                          
                            <img src="img/Vector (12) .svg" alt="photo">
                            <span class="font-weight-bold ml-3" style="Color:#8094AE;">Admin Profile</span>
                        </a>
                      
                    </li>
                    <!-- <li class="nav-item">
                <a class="nav-link" href="charts.html">
                  <img src="img/Vector (4).svg" alt="photo">
                    <span>OJT records</span>
                </a>
            </li>   -->
                    <!-- Nav Item - Tables -->
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="manoo.php" >
                           
                            <img src="img/Vector (5).svg" alt="photo">
                            <span class="font-weight-bold ml-3" style="Color:#8094AE;">Accounts</span></a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link collapsed" href="tables.html" data-toggle="collapse"
                            data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
                            <img src="img/Vector (13) .svg" alt="photo">
                            <span class="font-weight-bold ml-3" style="Color:#8094AE;">Settings</span></a>
                    </li>


                    
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="update.php">
                           
                            <img src="img/Vector (13) .svg" alt="photo">
                            <span class="font-weight-bold ml-3" style="Color:#8094AE;">Batch</span></a>
                    </li>
                    <!-- Divider -->
                    <hr class="sidebar-divider d-none d-md-block">

                    <!-- Sidebar Toggler (Sidebar)
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div> -->

                    <!-- Sidebar Message -->
                    <!-- <div class="sidebar-card d-none d-lg-flex"> -->
                    <!-- <img class="sidebar-card-illustration mb-2" src="img/undraw_rocket.svg" alt="..."> -->
                    <!-- <p class="text-center mb-2"><strong>SB Admin Pro</strong> is packed with premium features, components, and more!</p> -->
                    <!-- <a class="btn btn-success btn-sm" href="https://startbootstrap.com/theme/sb-admin-pro">Upgrade to Pro!</a> -->
                </div>
        </ul>
    </div>
</body>
</html>
</body>
</html>