<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Fee Slip</title>
  <style>

  /* Resetting default margin and padding */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: Arial, sans-serif;
  background-color: #f0f0f0;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.container {
  background-color: #fff;
  border-radius: 10px;
  padding: 20px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  text-align: center;
}

h1 {
  margin-bottom: 20px;
}

.buttons {
  margin-bottom: 20px;
}

button {
  width: 50px;
  height: 50px;
  margin: 0 10px;
  border: none;
  border-radius: 50%;
  cursor: pointer;
}

.green {
  background-color: green;
}

.yellow {
  background-color: yellow;
}

.blue {
  background-color: blue;
}

.fee-form {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.row input[type="checkbox"] {
  margin-right: 5px;
}

.row input[type="text"] {
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 5px;
  flex: 1;
  margin-right: 5px;
}

  </style>




<body>
  <div class="container">
    <h1>Fee Slip</h1>
    <div class="buttons">
      <button class="green"></button>
      <button class="yellow"></button>
      <button class="blue"></button>
    </div>
    <div class="fee-form">
      <div class="row">
        <label for="receiptNumber">Receipt Number:</label>
        <span>12345</span>
      </div>
      <div class="row">
        <label for="smsCheckbox">Send SMS:</label>
        <input type="checkbox" id="smsCheckbox">
      </div>
      <div class="row">
        <label for="studentName">Student Name:</label>
        <span>John Doe</span>
      </div>
      <div class="row">
        <label for="fatherName">Father's Name:</label>
        <span>Michael Doe</span>
      </div>
      <div class="row">
        <label for="batchNumber">Batch Number:</label>
        <span>Batch A</span>
      </div>
      <div class="row">
        <label for="tuitionFee">Tuition Fee:</label>
        <span>$500</span>
      </div>
      <div class="row">
        <label for="fee">Fee:</label>
        <span>$550</span>
      </div>
      <div class="row">
        <label for="batchDefinition">Batch :</label>
        <span>Full-time</span>
      </div>Definition
    </div>
  </div>
</body>
</html>

 