<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
<a href="student information"></a>
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous"> -->
    <title>Dashboard</title>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
       <?php
       include "sidebar.php";
       ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
            <?php
              include "header.php";
            ?>
              <div class="container-fluid">
      <div class="container">
  <div class="row">
    <div class="col-md-3">
    <h4 class="font-weight-bold text-dark">Student</h4>
      <!-- Your content goes here -->
    </div>
    <div class="col-md-9">
        <div class="float-right">
        <button 
type="button" class="btn btn-infop-2 mr-1"  style="background-color:#46972C;color:white;"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
<path d="M6.6665 14.1667L9.99984 17.5M9.99984 17.5L13.3332 14.1667M9.99984 17.5V10M16.6665 13.9524C17.6844 13.1117 18.3332 11.8399 18.3332 10.4167C18.3332 7.88536 16.2811 5.83333 13.7498 5.83333C13.5677 5.83333 13.3974 5.73833 13.3049 5.58145C12.2182 3.73736 10.2119 2.5 7.9165 2.5C4.46472 2.5 1.6665 5.29822 1.6665 8.75C1.6665 10.4718 2.36271 12.0309 3.48896 13.1613" stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
</svg> <a class="link" href="addstudent.php" > ADD</a> </button>
     <button type="button" class="p-2"style=";border:none;color:white; border-radius: 8px;
background: #165BAA;"><i class=""><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<g id="trash-01">
<path id="Icon" d="M13.3333 4.99999V4.33332C13.3333 3.3999 13.3333 2.93319 13.1517 2.57667C12.9919 2.26307 12.7369 2.0081 12.4233 1.84831C12.0668 1.66666 11.6001 1.66666 10.6667 1.66666H9.33333C8.39991 1.66666 7.9332 1.66666 7.57668 1.84831C7.26308 2.0081 7.00811 2.26307 6.84832 2.57667C6.66667 2.93319 6.66667 3.3999 6.66667 4.33332V4.99999M8.33333 9.58332V13.75M11.6667 9.58332V13.75M2.5 4.99999H17.5M15.8333 4.99999V14.3333C15.8333 15.7335 15.8333 16.4335 15.5608 16.9683C15.3212 17.4387 14.9387 17.8212 14.4683 18.0608C13.9335 18.3333 13.2335 18.3333 11.8333 18.3333H8.16667C6.76654 18.3333 6.06647 18.3333 5.53169 18.0608C5.06129 17.8212 4.67883 17.4387 4.43915 16.9683C4.16667 16.4335 4.16667 15.7335 4.16667 14.3333V4.99999" stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
</g>
</svg></i>Delete</button>
    <button type="button" class="p-2"style="border:none;color:#344054; border-radius: 8px;
background: #ECE536;"><i class="" style="margin-right: 10px;border-radius: 10px;"></i> <a class="link" href="haseeb.php" >Edit </a></button>
    <button type="button" class="p-2"style="background-color:green;border:none;color:white;border-radius: 8px;
border: 1px solid #D0D5DD;
background: #46972C;"><i class="" style="color: #fdfcfc;margin-right:10px;"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
  <path d="M6.6665 14.1667L9.99984 17.5M9.99984 17.5L13.3332 14.1667M9.99984 17.5V10M16.6665 13.9524C17.6844 13.1117 18.3332 11.8399 18.3332 10.4167C18.3332 7.88536 16.2811 5.83333 13.7498 5.83333C13.5677 5.83333 13.3974 5.73833 13.3049 5.58145C12.2182 3.73736 10.2119 2.5 7.9165 2.5C4.46472 2.5 1.6665 5.29822 1.6665 8.75C1.6665 10.4718 2.36271 12.0309 3.48896 13.1613" stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
</svg></i>Export</button>
</div>
      <!-- Another column, taking up the other half of the container -->
    </div>
  </div>
</div>
    <section class="intro">
  <div class=" h-100">
    <div class="mask d-flex align-items-center h-100">
      <div class="container"style="background-color:white;border-radius:6px;">
        <div class="row justify-content-center">
          <div class="col-12">
            <div class="table-responsive">
              <table class="table mb-0">
                <tbody>
                    <tr>
                    <th scope="row"><input type="checkbox"class="mr-2">ID<svg  style="margin-left: 70px;" xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16" fill="none" margin-left="50px">
  <path d="M8.33366 3.33334V12.6667M8.33366 12.6667L13.0003 8.00001M8.33366 12.6667L3.66699 8.00001" stroke="#667085" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
</svg></th>
                    <td>First Name<svg  style="margin-left: 10px;" xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16" fill="none" margin-left="50px">
  <path d="M8.33366 3.33334V12.6667M8.33366 12.6667L13.0003 8.00001M8.33366 12.6667L3.66699 8.00001" stroke="#667085" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
</svg></td>
                    <td>Father Name<svg  style="margin-left: 10px;" xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16" fill="none" margin-left="50px">
  <path d="M8.33366 3.33334V12.6667M8.33366 12.6667L13.0003 8.00001M8.33366 12.6667L3.66699 8.00001" stroke="#667085" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
</svg></td>
                    <td>CNIC<svg  style="margin-left: 10px;" xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16" fill="none" margin-left="50px">
  <path d="M8.33366 3.33334V12.6667M8.33366 12.6667L13.0003 8.00001M8.33366 12.6667L3.66699 8.00001" stroke="#667085" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
</svg></td>
                    <td>Email<svg  style="margin-left: 10px;" xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16" fill="none" margin-left="50px">
  <path d="M8.33366 3.33334V12.6667M8.33366 12.6667L13.0003 8.00001M8.33366 12.6667L3.66699 8.00001" stroke="#667085" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
</svg></td>
                   <td>Contact<svg  style="margin-left: 10px;" xmlns="http://www.w3.org/2000/svg" width="17" height="16" viewBox="0 0 17 16" fill="none" margin-left="50px">
  <path d="M8.33366 3.33334V12.6667M8.33366 12.6667L13.0003 8.00001M8.33366 12.6667L3.66699 8.00001" stroke="#667085" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
</svg></td>
                  </tr>

                  <?php 
include "db.php";
$query = "SELECT * FROM add_student";
$select_all_posts_query = mysqli_query($connection, $query);

while($row = mysqli_fetch_assoc($select_all_posts_query)) {
    $std_id =  $row['std_id'];
   $student_name =  $row['student_name'];
   $Father_name =  $row['Father_name'];
   $CNIC =  $row['CNIC'];
   $Email =  $row['Email'];
   $Contact=$row['Contact'];
    + 



  
// Assuming $post_id is defined and contains the post ID value

// Example va


?>


                 <tr>
                 <th scope="row"><input type="checkbox"></button><?php $std_id?></th>
                    <td><?php echo $student_name?></td>
                    <td><?php echo $Father_name?></td>
                    <td><?php echo $CNIC?></td>
                    <td><?php echo $Email?></td>
                    <td><?php echo $Contact?><td>
                    </td>
                  </tr>
                  <!-- <th scope="row"><input type="checkbox"></button>Bold text column</th>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column<td>
                    </td>
                  </tr>
                  <th scope="row"><input type="checkbox"></button>Bold text column</th>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column<td>
                    </td>
                  </tr>
                  <th scope="row"><input type="checkbox"></button>Bold text column</th>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column<td>
                    </td>
                  </tr>
                  <th scope="row"><input type="checkbox"></button>Bold text column</th>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column<td>
                    </td>
                  </tr>
                  <th scope="row"><input type="checkbox"></button>Bold text column</th>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column<td>
                    </td>
                  </tr>
                  <th scope="row"><input type="checkbox"></button>Bold text column</th>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column<td>
                    </td>
                  </tr>
                  <th scope="row"><input type="checkbox"></button>Bold text column</th>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column<td>
                    </td>
                  </tr>
                  <th scope="row"><input type="checkbox"></button>Bold text column</th>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column<td>
                    </td>
                  </tr>
                  <th scope="row"><input type="checkbox"></button>Bold text column</th>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column</td>
                    <td>Regular text column<td>
                    </td> -->
                  </tr>

                <?php
}
                ?>
  
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
            <?php
include "footer.php";
?>
        </div>
        <!-- End of Content Wrapper -->

    </div>
         
                  <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
   
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

</body>

</html>