<?php
$db_host = 'localhost';
$db_user = 'root';
$db_password = '';
$db_name = '4idiot';

$connection = mysqli_connect("localhost", 'root', '', '4idiot');

// if ($connection) {
//     echo "We are connected";
// }


?>