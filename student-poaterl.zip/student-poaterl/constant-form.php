<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pdf document</title>
     <style>
      .Rectangle2 img {
    max-width: 100%;
    max-height: 100%;
    display: block;
    margin: auto;
    margin-top:80px;
}

.Link {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom:40px;
}
        /* Your existing styles and modifications */

        /* Add new styles or modifications for responsiveness here */
        @media (max-width: 768px) {
            /* Define styles for smaller screens (example: mobile devices) */
            /* Example: Adjust the styles for smaller screens */
            .form1 {
                width: 100%;
            }
            /* ... Add more responsive styles as needed */
        }

    </style> 
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">



  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body>
    <div class="form1">
<?php
include 'sidebar.php';
?>


    <div class="DivNkContent" style="width: 90%; height: 90%; padding-top: 31px; padding-bottom: 32px; padding-left: 0px; padding-right: 29px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
        <div class="DivNkContentBody" style="width: 1572px; height: 812px; position: relative">
            <div class="DivNkBlockBetween" style="width: 1572px; left: 0px; top: 0px; position: absolute; justify-content: space-between; align-items: center; display: inline-flex">
                <div class="DivNkBlockHeadContent" style="flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 8.80px; display: inline-flex">
                    <div class="Heading3Courses" style="color: #364A63; font-size: 28px; font-family: DM Sans; font-weight: 700; line-height: 30.80px; word-wrap: break-word">Consent Form</div>
                </div>
                <div class="DivNkBlockHeadContent"></div>
            </div>

    

            <div class="Rectangle1"    style="width: 1448px; height: 104px; left: 0px; top: 71px; position: absolute; background: white; border-radius: 20px"></div>
            <div class="YouCanFindZakatEligibilityCriteriaFromHere" style="width: 1481px; height: 34px; left: 33px; top: 123px; position: absolute"><span style="color: #526484; font-size: 22px; font-family: DM Sans; font-weight: 700; line-height: 23.10px; word-wrap: break-word">You can find Zakat Eligibility Criteria from </span><span style="color: #526484; font-size: 22px; font-family: DM Sans; font-weight: 700; text-decoration: underline; line-height: 23.10px; word-wrap: break-word">here</span><span style="color: #526484; font-size: 22px; font-family: DM Sans; font-weight: 700; line-height: 23.10px; word-wrap: break-word">.    </span></div>
            <div class="Item" style="padding: 8px; left: 1382px; top: 426px; position: absolute"></div>
            <div class="Link" style="width: 121px; height: 36px; left: 682px; top: 794px; position: absolute; background: #46972C; border-radius: 4px; border: 1px #46972C solid">
                <div class="Download" style="left: 31px; top: 8px; position: absolute; text-align: center; color: white; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 20px; letter-spacing: 0.26px; word-wrap: break-word">Download</div>
                <div class="Span" style="padding-left: 7.89px; left: 88px; top: 8px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: center; display: inline-flex">
                    <div class="Frame1"></div>

                                    </div>
            </div>
           
            <div class="Rectangle2" style="width: 574px; height: 592px; left: 445px; top: 189px; position: absolute; background: white; border-radius: 20px">
       <div ><img src="img 2/PDF.jpg" alt="">
       </div>
    </div>
        </div>
    </div>
    </div>
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>