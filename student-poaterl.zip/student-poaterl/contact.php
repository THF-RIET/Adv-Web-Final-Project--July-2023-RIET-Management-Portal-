<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
             /* Your existing styles and modifications */

        /* Add new styles or modifications for responsiveness here */
        @media (max-width: 320px) {
            /* Define styles for smaller screens (example: mobile devices) */
            /* Example: Adjust the styles for smaller screens */
            .contact1 {
                width: 100%;
            }
            /* ... Add more responsive styles as needed */
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>
<body>


<?php
include 'sidebar.php';
?>
   <div class="contact1">         

 <div class="container" >               

                <!-- <div style="width: 100px; height: 100px; position: relative">
    <div style="width: 432px; left: 485px; top: -1px; position: absolute; justify-content: space-between; align-items: center; display: inline-flex">
        <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 8.80px; display: inline-flex">
        </div>
        <div></div>
    </div> -->
    <div style="margin-left:350px; padding: 2px;  color: #364A63; font-size: 28px; font-family: DM Sans; font-weight: 700; line-height: 30.80px; word-wrap: break-word">Contact Student Relation Officer</div>

    <div style="padding: 2px; left: 983px; top: 426px; position: absolute"></div>
    <div style="left: 232px; top: 386px; position: absolute; text-align: center; color: white; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 20px; letter-spacing: 0.26px; word-wrap: break-word"></div>
    <div style="margin-left:200px; margin-top:40px; height: 557.20px; padding-top: 1px; padding-bottom: 13px; padding-left: 1px; padding-right: 1px; left: 449px; top: 107px; position: absolute; background: white; box-shadow: 0px 3px 9px rgba(0, 0, 0, 0.10); border-radius: 6px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
        <div style="width: 538px; height: 543.20px; position: relative; border-top-left-radius: 6px; border-top-right-radius: 6px">
            <div style="left: 0px; top: 0px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                <div style="align-self: stretch; padding-bottom: 14px; padding-left: 219.67px; padding-right: 219.67px; flex-direction: column; justify-content: flex-start; align-items: center; display: flex">
                    <div style="width: 98.66px; height: 16px"></div>
                </div>
                <div style="align-self: stretch; height: 64.30px; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 2.98px; display: flex">
                    <div style="align-self: stretch; padding-left: 94.09px; padding-right: 93.91px; flex-direction: column; justify-content: flex-start; align-items: center; display: flex">
                        <div style="text-align: center; color: #094A35; font-size: 24px; font-family: Ubuntu; font-weight: 700; line-height: 38.83px; word-wrap: break-word">CONTACT US</div>
                    </div>
                    <div style="align-self: stretch; height: 22.49px; padding-left: 136.70px; padding-right: 136.30px; flex-direction: column; justify-content: flex-start; align-items: center; display: flex">
                        <div style="text-align: center; color: #46972C; font-size: 15px; font-family: Ubuntu; font-weight: 400; line-height: 22.49px; word-wrap: break-word">Please fill this form in case of any query</div>
                    </div>
                </div>
            </div>
            <div style="height: 79px; padding-left: 36px; padding-right: 36px; padding-top: 12px; padding-bottom: 12px; left: 0px; top: 109.30px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 9px; display: inline-flex">
                <div style="align-self: stretch; height: 16px; padding-right: 427px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                    <div style="color: #46972C; font-size: 14px; font-family: Ubuntu; font-weight: 700; word-wrap: break-word">Name</div>
                </div>
                <div style="align-self: stretch; padding: 7px; background: white; box-shadow: 0px 1px 2px 1px rgba(0, 0, 0, 0.15) inset; border: 1px #CCCCCC solid; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                    <div style="width: 452px; height: 16px; position: relative"></div>
                </div>
            </div>
            <div style="height: 79px; padding-left: 36px; padding-right: 36px; padding-top: 12px; padding-bottom: 12px; left: 0px; top: 200.30px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 9px; display: inline-flex">
                <div style="align-self: stretch; height: 16px; padding-right: 423px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                    <div style="color: #46972C; font-size: 14px; font-family: Ubuntu; font-weight: 700; word-wrap: break-word">E-Mail</div>
                </div>
                <div style="align-self: stretch; padding: 7px; background: white; box-shadow: 0px 1px 2px 1px rgba(0, 0, 0, 0.15) inset; border: 1px #CCCCCC solid; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                    <div style="width: 452px; height: 16px; position: relative"></div>
                </div>
            </div>
            <div style="height: 155.91px; padding-top: 12px; padding-bottom: 15px; padding-left: 36px; padding-right: 36px; left: 0px; top: 291.30px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 9px; display: inline-flex">
                <div style="align-self: stretch; height: 16px; padding-right: 407px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                    <div style="color: #46972C; font-size: 14px; font-family: Ubuntu; font-weight: 700; word-wrap: break-word">Message</div>
                </div>
                <div style="width: 466px; height: 103.91px; position: relative; background: white; box-shadow: 0px 1px 2px 1px rgba(0, 0, 0, 0.15) inset; border: 1px #CCCCCC solid"></div>
            </div>
            <div style="height: 84px; padding-left: 36px; padding-right: 36px; padding-top: 24px; padding-bottom: 24px; left: 0px; top: 459.20px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                <div style="align-self: stretch; padding-left: 190.47px; padding-right: 190.48px; justify-content: center; align-items: flex-start; display: inline-flex">
                    <div style="align-self: stretch; padding-top: 10px; padding-bottom: 10px; padding-left: 15.62px; padding-right: 15.43px; background: #46972C; border: 1px #F18BA6 solid; flex-direction: column; justify-content: flex-start; align-items: center; display: inline-flex">
                        <div style="text-align: center; color: #F8F8F8; font-size: 14px; font-family: Ubuntu; font-weight: 700; word-wrap: break-word">SUBMIT</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
 </div>
 </div>         
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>