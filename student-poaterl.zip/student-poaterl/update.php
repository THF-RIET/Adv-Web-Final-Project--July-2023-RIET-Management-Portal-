<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Dashboard</title>
    <style>
         /* Your existing styles and modifications */

        /* Add new styles or modifications for responsiveness here */
        @media (max-width: 320px) {
            /* Define styles for smaller screens (example: mobile devices) */
            /* Example: Adjust the styles for smaller screens */
            .responsive1 {
                width: 100%;
            }
            /* ... Add more responsive styles as needed */
        }

    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link rel="stylesheet" href="css/sb-admin-2.css">
</head>
<body>
    <div class="responsive1">
    <div id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
    <div class="responsive1" class="sidebar">
        <ul class="navbar-nav  sidebar sidebar-dark accordion" id="accordionSidebar">
            <!-- Sidebar - Brand -->
            <a style="background-color: #46972C;" sidebar-brand d-flex align-items-center justify-content-center>
                <div class="sidebar-brand-icon p-2">
                    <img class="mr-2"src="img/hunar logo.png" alt="photo">
                     <svg xmlns="http://www.w3.org/2000/svg" width=" 21.984px" height="16.008px" viewBox="0 0 22 17" fill="none">
                        <path d="M21 9.5H0.984375C0.71875 9.5 0.488281 9.40234 0.292969 9.20703C0.0976563 9.01172 0 8.77344 0 8.49219C0 8.22656 0.0976563 7.99609 0.292969 7.80078C0.488281 7.60547 0.71875 7.50781 0.984375 7.50781H21C21.2656 7.50781 21.4961 7.60547 21.6914 7.80078C21.8867 7.99609 21.9844 8.22656 21.9844 8.49219C21.9844 8.77344 21.8867 9.01172 21.6914 9.20703C21.4961 9.40234 21.2656 9.5 21 9.5ZM21.9844 1.50781C21.9844 1.22656 21.8867 0.988281 21.6914 0.792969C21.4961 0.597656 21.2656 0.5 21 0.5H0.984375C0.71875 0.5 0.488281 0.597656 0.292969 0.792969C0.0976563 0.988281 0 1.22656 0 1.50781C0 1.77344 0.0976563 2.00391 0.292969 2.19922C0.488281 2.39453 0.71875 2.49219 0.984375 2.49219H21C21.2656 2.49219 21.4961 2.39453 21.6914 2.19922C21.8867 2.00391 21.9844 1.77344 21.9844 1.50781ZM21.9844 15.5C21.9844 15.2188 21.8867 14.9805 21.6914 14.7852C21.4961 14.5898 21.2656 14.4922 21 14.4922H0.984375C0.71875 14.4922 0.488281 14.5898 0.292969 14.7852C0.0976563 14.9805 0 15.2188 0 15.5C0 15.7812 0.0976563 16.0195 0.292969 16.2148C0.488281 16.4102 0.71875 16.5078 0.984375 16.5078H21C21.2656 16.5078 21.4961 16.4102 21.6914 16.2148C21.8867 16.0195 21.9844 15.7812 21.9844 15.5Z" fill="white"/>
                        </svg>                  
                </div>
                <div class="sidebar-brand-text mx-3"></div>
            </a>
            <!-- Divider -->
            <div class="sidebar-divider my-0 px-2">

                <!-- Nav Item - Dashboard -->
                <li class="nav-item active bg-gray-200 mt-5" style="border-radius:6px;width:100%">
                    <a class="nav-link" href="index.php">
                        <img src="img/Vector.svg" alt="photo">
                        <span class="text-primary ml-3">Dashboard</span></a>
                        
                </li>
                <!-- Divider -->
                <div class="sidebar-divider">
                    <!-- Heading -->
                    <div class="sidebar-heading">
                    </div>
                    <!-- Nav Item - Pages Collapse Menu -->
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="courses.php" >
                            <img src="img/Vector (1).svg" alt="photo">
                            <span class="font-weight-bold ml-3" style="Color:#8094AE;">Courses</span>
                            <div class="dropdown-content">
                                <a href=""></a>
                                <a href=""></a>
                                <a href=""></a>
                            </div>
                        </a>
                    </li>
                    <!-- Nav Item - Utilities Collapse Menu -->
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="free.php" >
                            <img src="img/Vector (2).svg" alt="photo">
                            <span class="font-weight-bold ml-3" style="Color:#8094AE;">Free Details</span>
                        </a>                    
                    </li>
                    <!-- Divider -->
                    <!-- Heading -->
                    <div class="sidebar-heading">
                    </div>
                    <!-- Nav Item - Pages Collapse Menu -->
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="schlor.php" >
                            <img src="img/Vector (3).svg" alt="photo">
                            <span class="font-weight-bold ml-3" style="Color:#8094AE;">Schloarship</span>
                        </a>
                            <div class="bg-white my-0 collapse-inner rounded">
                        </div>
                    </li>

                    <!-- Nav Item - Charts -->
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="contact.php">
                            <img src="img/Vector (4).svg" alt="photo">
                            <span class="font-weight-bold ml-3" style="Color:#8094AE;">Contact Form</span>
                        </a>
                            <div class="bg-white my-0 collapse-inner rounded">
                        </div>
                    </li>
                </li>
            
                    <!-- Nav Item - Tables -->
                    <li class="nav-item">
                        <a class="nav-link collapsed" href="contact.php" >
                            <img src="img/Vector (4).svg" alt="photo">
                            <span class="font-weight-bold ml-3" style="Color:#8094AE;">Contact SRO</span>
                        </a>
                            <div class="bg-white my-0 collapse-inner rounded">
                        </div>
                    </li>
                </li>
                    <!-- Divider -->
                    <hr class="sidebar-divider d-none d-md-block">

              
                </div>
        </ul>
    </div>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column"style="overflow-y: hidden;">

            <!-- Main Content -->
            <div id="content">
                

                <!-- Topbar -->
            <div class="header">
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                  

                    <!-- Topbar Search -->
                    <form
                        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            <button class="btn" type="button">
                                <i class="fas fa-search fa-sm"></i>
                            </button>
                            <input type="text" class="form-control bg-light border-0 small"
                                placeholder="search anything" aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">

                            </div>
                        </div>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="img/Vector (7).svg" alt="photo">
                                <!-- Counter - Alerts -->
                                <span class="badge badge-danger badge-counter"></span>
                            </a>
                        </li>
                        </a>           
                        </li>
                        <div class="topbar-divider d-none d-sm-block"></div>
                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="img-fluid rounded-circle m-1  p-2" style="background-color:#46972C"
                                src="img/Vector.png" alt="photo">
                            <ul class="list-group">
                                <span style="color: #46972C;">Administrator</span>
                                <span Class="text-dark">Dr.Adeel <img src="img/Vector (6).svg" alt="photo"></span>

                            </ul>
                            <!-- <span class="mr-2 d-lg-inline text-gray-600 small">Administrator</span>
                                <span class="mr-2 d-lg-inline text-gray-600 small">Dr.Adeel</span> -->
                        </a>
                        <!-- Dropdown - User Information -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                            aria-labelledby="userDropdown">
                            <a class="dropdown-item" href="update.php">
                                <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                Update Information
                              
                            </a>
                            <a class="dropdown-item" href="notfiction.php">
                                <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                Notifications
                            </a>
                            <a class="dropdown-item" href="persional.php">
                                <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                persionl Information
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                Logout
                            </a>
                        </div>
                    </li>                        

                </nav>
            </div>
                <!-- End of Topbar
                <div class="container-fluid"> -->
                    <!-- Content Row -->
                    <!-- <div class="row">
                        <div class="row"> -->

                            <!-- Area Chart -->
                            <!-- <div class="col-xl-2 col-lg-2">
                                </div>
                            </div> -->

                            <!-- Pie Chart -->
                            <!-- <div class="col-xl-4 col-lg-5">
                                <div class="card shadow mb-0">
                                </div>
                            </div>
                        </div>
                    </div> -->

                   

                        <!-- Content Column -->
                        <div class="col-lg-6 mb-4">

                       
                    
                    <!-- End of Content Wrapper -->
                    <div class="responsive1" style="width: 100%; height: 100%; position: relative">
                        <div style="height: 64.09px; padding-top: 21px; padding-bottom: 20px; padding-left: 29px; padding-right: 29px; left: -20px; top: 955px; position: absolute; background: white; box-shadow: 0px 1px 3px rgba(54, 74, 99, 0.05); border-top: 1px #E5E9F2 solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="padding-right: 979px; justify-content: flex-start; align-items: center; display: inline-flex">
                                <div style="align-self: stretch; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">© 2023 - RIET LMS by Advance Web Application Development Students of Batch July-2023</div>
                                </div>
                            </div>
                        </div>
                        <div style="width: 1572px; left: 22px; top: 41px; position: absolute; background: white; box-shadow: 0px 1px 3px rgba(54, 74, 99, 0.05); border-radius: 4px; justify-content: center; align-items: center; display: inline-flex">
                            <div style="flex: 1 1 0; height: 795px; padding-bottom: 0.44px; justify-content: center; align-items: flex-start; display: inline-flex">
                                <div style="width: 380px; align-self: stretch; padding-bottom: 63px; padding-right: 1px; border-right: 1px #E5E9F2 solid; flex-direction: column; justify-content: flex-start; align-items: center; display: inline-flex">
                                    <div style="align-self: stretch; height: 604px; flex-direction: column; justify-content: center; align-items: center; display: inline-flex">
                                        <div style="width: 379px; height: 604.27px; position: relative; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                            <div style="height: 91.89px; padding-top: 24px; padding-bottom: 25px; padding-left: 24px; padding-right: 24px; border-bottom: 1px #DBDFEA solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                <div style="width: 331px; justify-content: center; align-items: center; display: inline-flex">
                                                    <div style="width: 40px; align-self: stretch; padding-top: 8.45px; padding-bottom: 7.55px; padding-left: 9.83px; padding-right: 10.17px; background: #043C8B; border-radius: 20px; justify-content: center; align-items: center; display: inline-flex">
                                                        <div style="color: white; font-size: 14px; font-family: DM Sans; font-weight: 700; line-height: 23.10px; letter-spacing: 0.84px; word-wrap: break-word">AB</div>
                                                    </div>
                                                    <div style="align-self: stretch; padding-left: 16px; flex-direction: column; justify-content: center; align-items: flex-start; display: inline-flex">
                                                        <div style="padding-bottom: 0.80px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                                            <div style="color: #364A63; font-size: 14px; font-family: DM Sans; font-weight: 700; line-height: 23.10px; word-wrap: break-word">Abu Bin Ishtiyak</div>
                                                            <div style="color: #8094AE; font-size: 12px; font-family: DM Sans; font-weight: 400; line-height: 19.80px; word-wrap: break-word">info@softnio.com</div>
                                                        </div>
                                                    </div>
                                                    <div style="flex: 1 1 0; align-self: stretch; padding-top: 9px; padding-bottom: 9px; padding-left: 151.54px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                        <div style="width: 18.45px; height: 18px; padding-top: 0.76px; padding-bottom: 1.49px; padding-left: 0.09px; padding-right: 14.59px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                                            <div style="width: 3.76px; height: 15.75px; background: #526484"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="width: 379px; height: 52.80px; position: relative">
                                                <div style="height: 18px; padding-right: 10px; left: 24px; top: 16.39px; position: absolute; opacity: 0.80; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                    <div style="width: 18px; height: 18px; padding-top: 0.47px; padding-bottom: 1.23px; padding-right: 1.72px; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                        <div style="width: 16.28px; height: 16.29px; background: #043C8B"></div>
                                                    </div>
                                                </div>
                                                <div style="left: 56px; top: 16px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                    <div style="color: #043C8B; font-size: 14px; font-family: DM Sans; font-weight: 500; line-height: 20.80px; word-wrap: break-word"><a href="opi.php">Personal Infomation</a></div>
                                                </div>
                                                <div style="width: 16px; height: 20.80px; padding-top: 6.07px; padding-bottom: 6.74px; padding-right: 11.34px; left: 343px; top: 36.80px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                    <div style="width: 4.66px; height: 7.98px; background: #043C8B"></div>
                                                </div>
                                            </div>
                                            <div style="height: 77.80px; padding-bottom: 1px; border-bottom: 1px #DBDFEA solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                <div style="height: 76.80px; padding-top: 12px; padding-bottom: 12px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                                    <div style="width: 379px; height: 52.80px; position: relative">
                                                        <div style="height: 18px; padding-right: 10px; left: 24px; top: 16.39px; position: absolute; opacity: 0.80; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                            <div style="width: 18px; height: 18px; padding-top: 1.62px; padding-bottom: 2.36px; padding-right: 4.50px; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                                <div style="width: 13.50px; height: 14.03px; background: #8094AE"></div>
                                                            </div>
                                                        </div>
                                                        <div style="left: 56px; top: 16px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                            <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 500; line-height: 20.80px; word-wrap: break-word"><a href="Notification.php"> Notifications</a></div>
                                                        </div>
                                                        <div style="width: 16px; height: 20.80px; padding-top: 6.07px; padding-bottom: 6.74px; padding-right: 11.34px; left: 343px; top: 36.80px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                            <div style="width: 4.66px; height: 7.98px; background: #8094AE"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="width: 331px; height: 104.56px; position: relative">
                                                <div style="left: 0px; top: 0px; position: absolute; color: #8094AE; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 1.65px; word-wrap: break-word">Last Login</div>
                                                <div style="left: 0px; top: 21.19px; position: absolute; color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">06-29-2020 02:39pm</div>
                                                <div style="left: 0px; top: 60.28px; position: absolute; color: #8094AE; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 1.65px; word-wrap: break-word">Login IP</div>
                                                <div style="left: 0px; top: 81.47px; position: absolute; color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">192.129.243.28</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div style="width: 1192px; align-self: stretch; padding-top: 40px; padding-bottom: 127.56px; padding-left: 40px; padding-right: 40px; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 19.52px; display: inline-flex">
                                    <div style="align-self: stretch; height: 57.48px; justify-content: center; align-items: center; gap: 762px; display: inline-flex">
                                        <div style="align-self: stretch; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 7.39px; display: inline-flex">
                                            <div style="color: #364A63; font-size: 24px; font-family: DM Sans; font-weight: 700; line-height: 26.40px; word-wrap: break-word">Update Personal Information</div>
                                            <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Basic info, like your name and address.</div>
                                        </div>
                                        <div style="align-self: stretch; padding-top: 9px; padding-bottom: 9px; padding-left: 8.77px; padding-right: 2.78px; justify-content: flex-start; align-items: center; display: inline-flex">
                                            <div style="width: 18.45px; height: 18px; padding-top: 1.88px; padding-bottom: 1.11px; padding-left: 0.09px; padding-right: 3.34px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                <div style="width: 15.01px; height: 15.01px; background: #526484"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="align-self: stretch; height: 550px; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 32px; display: inline-flex">
                                        <div style="width: 1112px; height: 573.19px; position: relative">
                                            <div style="height: 29.19px; padding-top: 8px; padding-bottom: 7.19px; padding-left: 20px; padding-right: 1042px; left: 0px; top: 0px; position: absolute; background: #EBEEF2; border-radius: 4px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                <div style="color: #8094AE; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 2.20px;">Father </div>
                                            </div>
                                            <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 33.19px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                                                <div style="flex: 1 1 0; height: 25px; padding-right: 426px; justify-content: flex-start; align-items: center; display: flex">
                                                    <div style="width: 536px; padding-right: 472px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px;">Father Name</div>
                                                    </div>
                                                    <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                        <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">Abu Bin Ishtiyak</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 106.94px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                                                <div style="flex: 1 1 0; height: 25px; padding-right: 483px; justify-content: flex-start; align-items: center; display: flex">
                                                    <div style="width: 536px; padding-right: 447px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Father CNIC</div>
                                                    </div>
                                                    <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                        <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">Ishtiyak</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 180.69px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                                                <div style="flex: 1 1 0; height: 25px; padding-right: 413px; justify-content: flex-start; align-items: center; display: flex">
                                                    <div style="width: 536px; padding-right: 501px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Father Occupation</div>
                                                    </div>
                                                    <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                        <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">info@softnio.com</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 254.44px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                                                <div style="flex: 1 1 0; height: 25px; padding-right: 454px; justify-content: flex-start; align-items: center; display: flex">
                                                    <div style="width: 536px; padding-right: 439px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Father Contact</div>
                                                    </div>
                                                    <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                        <div style="color: #8094AE; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">Not add yet</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 328.19px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                                                <div style="width: 1072px; height: 25px; position: relative">
                                                    <div style="height: 24px; padding-right: 455px; left: 0px; top: 0.81px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Father Employment Status</div>
                                                    </div>
                                                    <div style="left: 536px; top: 2.50px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                        <div style="width: 20px; height: 20px; background: rgba(229, 233, 242, 0.70); border-radius: 9999px; border: 1px black solid"></div>
                                                    </div>
                                                    <div style="left: 568px; top: 0px; position: absolute; color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">On-Job</div>
                                                    <div style="left: 704px; top: 2.31px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                        <div style="width: 20px; height: 20px; background: rgba(229, 233, 242, 0.70); border-radius: 9999px; border: 1px black solid"></div>
                                                    </div>
                                                    <div style="left: 731px; top: -0.19px; position: absolute; color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">Job-less</div>
                                                    <div style="left: 846px; top: 2.31px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                        <div style="width: 20px; height: 20px; background: rgba(229, 233, 242, 0.70); border-radius: 9999px; border: 1px black solid"></div>
                                                    </div>
                                                    <div style="left: 873px; top: -0.19px; position: absolute; color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">Deceased (Late)</div>
                                                </div>
                                            </div>
                                            <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 401.94px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                                                <div style="width: 1072px; height: 25px; position: relative">
                                                    <div style="height: 24px; padding-right: 466px; left: 0px; top: 0.50px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Father Salary Range</div>
                                                    </div>
                                                    <div style="left: 536px; top: 0px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                        <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">20,000 - 30,000</div>
                                                    </div>
                                                    <div style="width: 16px; height: 20.80px; left: 665px; top: 11.56px; position: absolute; transform: rotate(89.68deg); transform-origin: 0 0">
                                                        <div style="width: 4.66px; height: 7.98px; left: 0px; top: 6.07px; position: absolute; background: #043C8B"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="padding-left: 19px; padding-right: 19px; padding-top: 8px; padding-bottom: 8px; left: 1015px; top: 522px; position: absolute; background: #46972C; border-radius: 4px; border: 1px #46972C solid; justify-content: flex-start; align-items: center; gap: 4px; display: inline-flex">
                                                <div style="padding-left: 7.89px; flex-direction: column; justify-content: flex-start; align-items: center; display: inline-flex">
                                                    <div style="text-align: center; color: white; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 20px; letter-spacing: 0.26px; word-wrap: break-word"><a href="opi.php"> Next</a></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>


                  
                    

                </div>
                <!-- End of Page Wrapper -->
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                        <div class="copyright my-auto">
                            <span style="font-size:15px;color: #8094AE;">© 2023 - RIET LMS by Advance Web Application Development students of Batch july-2023</span>
                        </div>
                    </div>
                </footer> 
                </footer>
                </div>
                <!-- Scroll to Top Button-->
                <a class="scroll-to-top rounded" href="#page-top">
                    <i class="fas fa-angle-up"></i>
                </a>
                <!-- Bootstrap core JavaScript-->
                <script src="vendor/jquery/jquery.min.js"></script>
                <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>    

                <!-- Core plugin JavaScript-->
                <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

                <!-- Custom scripts for all pages-->
                <script src="js/sb-admin-2.min.js"></script>

                <!-- Page level plugins -->
                <script src="vendor/chart.js/Chart.min.js"></script>

                <!-- Page level custom scripts -->
                <script src="js/demo/chart-area-demo.js"></script>
                <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>