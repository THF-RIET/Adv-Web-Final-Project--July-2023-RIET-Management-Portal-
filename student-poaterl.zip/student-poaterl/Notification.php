<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Student-Potrels</title>
    <style>
             /* Your existing styles and modifications */

        /* Add new styles or modifications for responsiveness here */
        @media (max-width: 320px) {
            /* Define styles for smaller screens (example: mobile devices) */
            /* Example: Adjust the styles for smaller screens */
            .noti1 {
                width: 100%;
            }
            /* ... Add more responsive styles as needed */
        }
    </style>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>
<body>
   <div class="noti1"> 
<div id="page-top">
        <?php
include 'sidebar.php';

?>
        


            <div style="width: 100%; height: 100%; background: white; box-shadow: 0px 1px 3px rgba(54, 74, 99, 0.05); border-radius: 4px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                <div style="align-self: stretch; height: 795px; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                    <div style="width: 380px; padding-right: 1px; border-right: 1px #E5E9F2 solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                        <div style="width: 379px; height: 604px; flex-direction: column; justify-content: center; align-items: center; display: flex">
                            <div style="width: 379px; height: 604.27px; position: relative; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                <div style="height: 91.89px; padding-top: 24px; padding-bottom: 25px; padding-left: 24px; padding-right: 24px; border-bottom: 1px #DBDFEA solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="width: 331px; justify-content: center; align-items: center; display: inline-flex">
                                        <div style="width: 40px; align-self: stretch; padding-top: 8.45px; padding-bottom: 7.55px; padding-left: 9.83px; padding-right: 10.17px; background: #043C8B; border-radius: 20px; justify-content: center; align-items: center; display: inline-flex">
                                            <div style="color: white; font-size: 14px; font-family: DM Sans; font-weight: 700; line-height: 23.10px; letter-spacing: 0.84px; word-wrap: break-word">AB</div>
                                        </div>
                                        <div style="align-self: stretch; padding-left: 16px; flex-direction: column; justify-content: center; align-items: flex-start; display: inline-flex">
                                            <div style="padding-bottom: 0.80px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                                <div style="color: #364A63; font-size: 14px; font-family: DM Sans; font-weight: 700; line-height: 23.10px; word-wrap: break-word">Abu Bin Ishtiyak</div>
                                                <div style="color: #8094AE; font-size: 12px; font-family: DM Sans; font-weight: 400; line-height: 19.80px; word-wrap: break-word">info@softnio.com</div>
                                            </div>
                                        </div>
                                        <div style="flex: 1 1 0; align-self: stretch; padding-top: 9px; padding-bottom: 9px; padding-left: 151.54px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                            <div style="width: 18.45px; height: 18px; padding-top: 0.76px; padding-bottom: 1.49px; padding-left: 0.09px; padding-right: 14.59px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                                <div style="width: 3.76px; height: 15.75px; background: #526484"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div style="width: 379px; height: 52.80px; position: relative">
                                    <div style="height: 18px; padding-right: 10px; left: 24px; top: 16.39px; position: absolute; opacity: 0.80; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="width: 18px; height: 18px; padding-top: 0.47px; padding-bottom: 1.23px; padding-right: 1.72px; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                            <div style="width: 16.28px; height: 16.29px; background: #526484"></div>
                                        </div>
                                    </div>
                                    <div style="left: 56px; top: 16px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 500; line-height: 20.80px; word-wrap: break-word"> <a href="persional.php"> Personal Infomation</a></div>
                                    </div>
                                    <div style="width: 16px; height: 20.80px; padding-top: 6.07px; padding-bottom: 6.74px; padding-right: 11.34px; left: 343px; top: 36.80px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="width: 4.66px; height: 7.98px; background: #526484"></div>
                                    </div>
                                </div>
                                <div style="height: 77.80px; padding-bottom: 1px; border-bottom: 1px #DBDFEA solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="height: 76.80px; padding-top: 12px; padding-bottom: 12px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                        <div style="width: 379px; height: 52.80px; position: relative">
                                            <div style="height: 18px; padding-right: 10px; left: 24px; top: 16.39px; position: absolute; opacity: 0.80; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                <div style="width: 18px; height: 18px; padding-top: 1.62px; padding-bottom: 2.36px; padding-right: 4.50px; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                    <div style="width: 13.50px; height: 14.03px; background: #043C8B"></div>
                                                </div>
                                            </div>
                                            <div style="left: 56px; top: 16px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                <div style="color: #043C8B; font-size: 14px; font-family: DM Sans; font-weight: 500; line-height: 20.80px; word-wrap: break-word"><a href="Notification.php">Notifications</a></div>
                                            </div>
                                            <div style="width: 16px; height: 20.80px; padding-top: 6.07px; padding-bottom: 6.74px; padding-right: 11.34px; left: 343px; top: 36.80px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                <div style="width: 4.66px; height: 7.98px; background: #043C8B"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div style="width: 331px; height: 104.56px; position: relative">
                                <div style="left: 0px; top: 5px; position: absolute; color: #8094AE; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 1.65px; word-wrap: break-word">Last Login</div>
                                    <div style="left: 0px; top: 21.19px; position: absolute; color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">06-29-2020 02:39pm</div>
                                    <div style="left: 0px; top: 60.28px; position: absolute; color: #8094AE; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 1.65px; word-wrap: break-word">Login IP</div>
                                    <div style="left: 0px; top: 81.47px; position: absolute; color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">192.129.243.28</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="flex: 1 1 0; padding-top: 40px; padding-bottom: 103.89px; padding-left: 40px; padding-right: 40px; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 20px; display: inline-flex">
                        <div style="padding-top: 10.73px; padding-bottom: 10.75px; justify-content: center; align-items: center; gap: 938px; display: inline-flex">
                            <div style="align-self: stretch; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 7.39px; display: inline-flex">
                                <div style="color: #364A63; font-size: 24px; font-family: DM Sans; font-weight: 700; line-height: 26.40px;margin-top: 10px;">Notifications</div>
                            </div>
                            <div style="padding-top: 9px; padding-bottom: 9px; padding-left: 8.77px; padding-right: 2.78px"></div>
                        </div>
                        <div style="height: 573.19px; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 32px; display: flex">
                            <div style="width: 1192px; height: 794.56px; position: relative">
                                <div style="height: 29.19px; padding-top: 8px; padding-bottom: 7.19px; padding-left: 20px; padding-right: 1042px; left: 0px; top: 0px; position: absolute; background: #EBEEF2; border-radius: 4px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #E85347; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 2.20px; word-wrap: break-word">Unread</div>
                                </div>
                                <div style="height: 29.19px; padding-top: 8px; padding-bottom: 7.19px; padding-left: 20px; padding-right: 1042px; left: 0px; top: 339.52px; position: absolute; background: #EBEEF2; border-radius: 4px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="width: 56px; color: #46972C; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 2.20px; word-wrap: break-word">READ</div>
                                </div>
                                <div style="width: 1112px; height: 74px; left: 0px; top: 57.52px; position: absolute; background: rgba(235, 237, 242, 0.50); border-radius: 20px; border-bottom: 1px #E5E9F2 solid">
                                    <div style="width: 199px; padding-right: 426px; left: 64px; top: 37px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                                        <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                            <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 300; line-height: 20.75px; word-wrap: break-word"></div>
                                        </div>
                                    </div>
                                    <div style="padding-right: 325px; left: 64px; top: 15px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                                        <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">You have Requested to withdraw</div>
                                    </div>
                                    <div style="width: 45px; height: 43px; left: 13px; top: 15px; position: absolute; background: rgba(70, 151, 44, 0.40); border-radius: 9999px"></div>
                                    <div style="width: 20px; height: 25px; left: 26px; top: 24px; position: absolute; color: white; font-size: 20px; font-family: DM Sans; font-weight: 700; line-height: 20px; word-wrap: break-word">N</div>
                                </div>
                                <div style="width: 1112px; height: 74px; left: 0px; top: 147.52px; position: absolute; background: rgba(235, 237, 242, 0.50); border-radius: 20px; border-bottom: 1px #E5E9F2 solid">
                                    <div style="width: 199px; padding-right: 426px; left: 64px; top: 37px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                                        <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                            <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word"></div>
                                        </div>
                                    </div>  
                                    <div style="padding-right: 325px; left: 64px; top: 15px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                                        <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">You have Requested to withdraw</div>
                                    </div>
                                    <div style="width: 45px; height: 43px; left: 13px; top: 15px; position: absolute; background: rgba(70, 151, 44, 0.40); border-radius: 9999px"></div>
                                    <div style="width: 1112px; height: 74px; left: 0px; top: 91px; position: absolute; background: rgba(235, 237, 242, 0.50); border-radius: 20px; border-bottom: 1px #E5E9F2 solid">
                                        <div style="width: 199px; padding-right: 426px; left: 64px; top: 37px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                                            <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word"></div>
                                            </div>
                                        </div>
                                        <div style="padding-right: 325px; left: 64px; top: 15px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                                            <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">You have Requested to withdraw</div>
                                        </div>
                                        <div style="width: 45px; height: 43px; left: 13px; top: 15px; position: absolute; background: rgba(70, 151, 44, 0.40); border-radius: 9999px"></div>
                                        <div style="width: 20px; height: 25px; left: 26px; top: 24px; position: absolute; color: white; font-size: 20px; font-family: DM Sans; font-weight: 700; line-height: 20px; word-wrap: break-word">N</div>
                                    </div>
                                    <div style="width: 20px; height: 25px; left: 26px; top: 24px; position: absolute; color: white; font-size: 20px; font-family: DM Sans; font-weight: 700; line-height: 20px; word-wrap: break-word">N</div>
                                </div>
                                <div style="width: 1112px; height: 74px; left: 0px; top: 503.52px; position: absolute; background: rgba(235, 237, 242, 0.50); border-radius: 20px; border-bottom: 1px #E5E9F2 solid">
                                    <div style="width: 199px; padding-right: 426px; left: 64px; top: 37px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                                        <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                            <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word"></div>
                                        </div>
                                    </div>
                                    <div style="padding-right: 325px; left: 64px; top: 15px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                                        <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">You have Requested to withdraw</div>
                                    </div>
                                    <div style="width: 45px; height: 43px; left: 13px; top: 15px; position: absolute; background: rgba(70, 151, 44, 0.40); border-radius: 9999px"></div>
                                    <div style="width: 20px; height: 25px; left: 26px; top: 24px; position: absolute; color: white; font-size: 20px; font-family: DM Sans; font-weight: 700; line-height: 20px; word-wrap: break-word">N</div>
                                </div>
                                <div style="width: 1112px; height: 74px; left: 0px; top: 397.52px; position: absolute; background: rgba(235, 237, 242, 0.50); border-radius: 20px; border-bottom: 1px #E5E9F2 solid">
                                    <div style="width: 199px; padding-right: 426px; left: 64px; top: 37px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                                        <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                            <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word"></div>
                                        </div>
                                    </div>
                                    <div style="padding-right: 325px; left: 64px; top: 15px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                                        <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">You have Requested to withdraw</div>
                                    </div>
                                    <div style="width: 45px; height: 43px; left: 13px; top: 15px; position: absolute; background: rgba(70, 151, 44, 0.40); border-radius: 9999px"></div>
                                    <div style="width: 20px; height: 25px; left: 26px; top: 24px; position: absolute; color: white; font-size: 20px; font-family: DM Sans; font-weight: 700; line-height: 20px; word-wrap: break-word">N</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
   

        <!-- End of Sidebar -->

     

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->
   

   

                </nav>
                <!-- End of Topbar -->



            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>