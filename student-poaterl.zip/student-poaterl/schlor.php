<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Dashboard</title>
    <style>
             /* Your existing styles and modifications */

        /* Add new styles or modifications for responsiveness here */
        @media (max-width: 320px) {
            /* Define styles for smaller screens (example: mobile devices) */
            /* Example: Adjust the styles for smaller screens */
            .scho1 {
                width: 100%;
            }
            /* ... Add more responsive styles as needed */
        }
    </style>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link rel="stylesheet" href="css/sb-admin-2.css">
</head>
<body>
    <div class="scho1">
    <div  id="page-top">
    <!-- Page Wrapper -->
<?php

include 'sidebar.php';

?>

                <div class="countainer">

                <div style="width: 100%; height: 100%; padding-top: 31px; padding-bottom: 32px; padding-left: 29px; padding-right: 29px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                    <div style="width: 1572px; height: 812px; position: relative">
                        <div style="width: 1572px; left: 0px; top: 0px; position: absolute; justify-content: space-between; align-items: center; display: inline-flex">
                            <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 8.80px; display: inline-flex">
                                <div style="color: #364A63; font-size: 28px; font-family: DM Sans; font-weight: 700; line-height: 30.80px; word-wrap: break-word">Scholarship Policy</div>
                            </div>
                            <div></div>
                        </div>
                        <div style="width: 1548px; height: 294px; left: 0px; top: 112px; position: absolute; background: white; border-radius: 20px"></div>
                        <div style="width: 1481px; height: 239px; left: 29px; top: 122px; position: absolute; color: #526484; font-size: 22px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Our institution is committed to fostering equal educational opportunities for all students, regardless of their financial circumstances. To support this mission, we have implemented a need-based scholarship policy that takes into account students' financial status. We proudly offer scholarships ranging from 20% to 80% of tuition fees, with the 20% scholarship being funded by generous donations from our community. For those who require higher assistance levels of 40%, 60%, or 80% and are eligible for Zakat, we encourage you to reach out to our Student Relations Officer at the office for personalized support. Alternatively, if you believe you qualify for the 20% scholarship, please feel free to contact us for further assistance. Your education matters to us, and we are here to help ensure that financial constraints do not hinder your academic journey. If you think that you’re eligible for Zakat then Please fill out the form below to initiate the scholarship application process.</div>
                        <div style="left: 0px; top: 52px; position: absolute; color: #3C4D62; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">You have not applied yet for the scholarship.</div>
                        <div style="padding: 8px; left: 1382px; top: 426px; position: absolute"></div>
                        <div style="padding-left: 19px; padding-right: 19px; padding-top: 8px; padding-bottom: 8px; left: 1358px; top: 434px; position: absolute; background: #46972C; border-radius: 4px; border: 1px #46972C solid; justify-content: flex-start; align-items: center; gap: 4px; display: inline-flex">
                            <div style="padding-top: 1px; padding-bottom: 1px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                <div style="width: 18.45px; height: 18px; padding-top: 1.88px; padding-bottom: 2.62px; padding-left: 0.09px; padding-right: 4.86px; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="width: 13.50px; height: 13.50px; background: white ">+ </div>
                                </div>
                            </div>
                            <div style="padding-left: 7.89px; flex-direction: column; justify-content: flex-start; align-items: center; display: inline-flex">
                                <div style="text-align: center; color: white; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 20px; letter-spacing: 0.26px; word-wrap: break-word"><a href="PDF.php">Apply for Zakat</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>


                
                <!-- End of Page Wrapper -->
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                        <div class="copyright my-auto">
                            <span style="font-size:15px;color: #8094AE;">© 2023 - RIET LMS by Advance Web Application Development students of Batch july-2023</span>
                        </div>
                    </div>
                </footer> 
                </footer>
                </div>
                <!-- Scroll to Top Button-->
                <a class="scroll-to-top rounded" href="#page-top">
                    <i class="fas fa-angle-up"></i>
                </a>
                <!-- Bootstrap core JavaScript-->
                <script src="vendor/jquery/jquery.min.js"></script>
                <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

                <!-- Core plugin JavaScript-->
                <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

                <!-- Custom scripts for all pages-->
                <script src="js/sb-admin-2.min.js"></script>

                <!-- Page level plugins -->
                <script src="vendor/chart.js/Chart.min.js"></script>

                <!-- Page level custom scripts -->
                <script src="js/demo/chart-area-demo.js"></script>
                <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>






