<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Dashboard</title>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link rel="stylesheet" href="css/sb-admin-2.css">
    <style>
        /* Add this to your existing CSS or in a separate stylesheet */
        body {
            margin: 0;
            padding: 0;
            font-family: 'DM Sans', sans-serif; /* Add the desired font-family */
            box-sizing: border-box;
        }

        .main-container {
            width: 100%;
            max-width: 1200px; /* Set a maximum width for the main container */
            margin: 0 auto; /* Center the main container */
            padding: 10px; /* Add padding to the main container */
        }
             /* Your existing styles and modifications */

        /* Add new styles or modifications for responsiveness here */
        @media (max-width: 321px) {
            /* Define styles for smaller screens (example: mobile devices) */
            /* Example: Adjust the styles for smaller screens */
            .noti1 {
                width: 2560;
            }
            /* ... Add more responsive styles as needed */
        }
    
    </style>

</head>
<body> 
     <div id="page-top">
    <!-- Page Wrapper -->
<?php

include 'sidebar.php';

?>

                <div class="countainer">
                <div class="countainer" style="width: 100%; height: 100%; padding-top: 31px; padding-bottom: 32px; padding-left: 29px; padding-right: 29px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                    <div style="width: 1050px; height: 750px; position: relative">
                        <div style="width: 1572px; left: 0px; top: 0px; position: absolute; justify-content: space-between; align-items: center; display: inline-flex">
                            <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 8.80px; display: inline-flex">
                                <div style="color: #364A63; font-size: 28px; font-family: DM Sans; font-weight: 700; line-height: 30.80px; word-wrap: break-word">Dashboard</div>
                            </div>
                            <div></div>
                        </div>
                        <div class="countainer" style="width: 1548px; height: 454px; left: 0px; top: 112px; position: absolute; background: white; border-radius: 20px"></div>
           
                        <div  class=" countainer"style="width: 1481px; height: 239px; left: 29px; top: 122px; position: absolute; color: #526484; font-size: 22px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">
                        <div style="color: #364A63; font-size: 28px; font-family: DM Sans; font-weight: 700; line-height: 30.80px; word-wrap: break-word">   Introductions</div>
                        <br>

                        Our institution is committed to fostering equal educational opportunities for all students, regardless of their financial circumstances. To support this mission, we have implemented a need-based scholarship policy that takes into account students' financial status. We proudly offer scholarships ranging from 20% to 80% of tuition fees, with the 20% scholarship being funded by generous donations from our community. For those who require higher assistance levels of 40%, 60%, or 80% and are eligible for Zakat, we encourage you to reach out to our Student Relations Officer at the office for personalized support. Alternatively, if you believe you qualify for the 20% scholarship, please feel free to contact us for further assistance. Your education matters to us, and we are here to help ensure that financial constraints do not hinder your academic journey. If you think that you’re eligible for Zakat then Please fill out the form below to initiate the scholarship application process.</div>
                        <div style="left: 0px; top: 52px; position: absolute; color: #3C4D62; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Welcome to lernig to managment system </div>
                        <div style="padding: 8px; left: 1382px; top: 426px; position: absolute"></div>
                            
                            </div>
                          
                        
                    </div>
                </div>
                </div>


                
                <!-- End of Page Wrapper -->
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                        <div class="copyright my-auto">
                            <span style="font-size:15px;color: #8094AE;">© 2023 - RIET LMS by Advance Web Application Development students of Batch july-2023</span>
                        </div>
                    </div>
                </footer> 
                </footer>
                <!-- Scroll to Top Button-->
                <a class="scroll-to-top rounded" href="#page-top">
                    <i class="fas fa-angle-up"></i>
                </a>
                <!-- Bootstrap core JavaScript-->
                <script src="vendor/jquery/jquery.min.js"></script>
                <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

                <!-- Core plugin JavaScript-->
                <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

                <!-- Custom scripts for all pages-->
                <script src="js/sb-admin-2.min.js"></script>

                <!-- Page level plugins -->
                <script src="vendor/chart.js/Chart.min.js"></script>

                <!-- Page level custom scripts -->
                <script src="js/demo/chart-area-demo.js"></script>
                <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>