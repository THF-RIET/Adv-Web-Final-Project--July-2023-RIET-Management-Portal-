<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Dashboard</title>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link rel="stylesheet" href="css/sb-admin-2.css">
    <style>
        /* Add this to your existing CSS or in a separate stylesheet */
      
             /* Your existing styles and modifications */

        /* Add new styles or modifications for responsiveness here */
        @media (max-width: 321px) {
            /* Define styles for smaller screens (example: mobile devices) */
            /* Example: Adjust the styles for smaller screens */
            .noti1 {
                width: 2560;
            }
            /* ... Add more responsive styles as needed */
        }
    
    </style>

</head>
<body> 
     <div id="page-top">
    <!-- Page Wrapper -->
<?php

include 'sidebar.php';

?>

<div style="width: 100%; height: 100%; position: relative">
    <div style="width: 97px; padding-bottom: 0.20px; left: 29px; top: 31px; position: absolute; justify-content: center; align-items: center; display: inline-flex">
        <div style="flex: 1 1 0; align-self: stretch; justify-content: space-between; align-items: center; display: inline-flex">
            <div style="flex-direction: column; justify-content: center; align-items: flex-start; gap: 8.80px; display: inline-flex">
                <div style="color: #364A63; font-size: 28px; font-family: DM Sans; font-weight: 700; line-height: 30.80px; word-wrap: break-word"></div>
                <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word"></div>
            </div>
        </div>
    </div>
    <!-- <div style="height: 64.09px; padding-top: 21px; padding-bottom: 20px; padding-left: 29px; padding-right: 29px; left: -20px; top: 955px; position: absolute; background: white; box-shadow: 0px 1px 3px rgba(54, 74, 99, 0.05); border-top: 1px #E5E9F2 solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
        <div style="padding-right: 979px; justify-content: flex-start; align-items: center; display: inline-flex">
            <div style="align-self: stretch; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">© 2023 - RIET LMS by Advance Web Application Development Students of Batch July-2023</div>
            </div>
        </div>
    </div> -->
    
    <div style="height: 358.39px; padding-top: 31px; padding-bottom: 32px; padding-left: 29px; padding-right: 29px; left: 0px; top: 106px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
        <div style="height: 295.39px; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 27.09px; display: flex">
            <div style="width: 1572px; justify-content: space-between; align-items: center; display: inline-flex">
                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 8.80px; display: inline-flex">
                    <div style="color: #364A63; font-size: 28px; font-family: DM Sans; font-weight: 700; line-height: 30.80px; word-wrap: break-word">Dashboard</div>
              
                </div>
                <div></div>
            </div>
            <div style="color: #364A63; font-size: 28px; font-family: DM Sans; font-weight: 700; line-height: 30.80px; word-wrap: break-word">COURSES</div>
                    <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">You are registered in one course.</div>
                </div>
            
            <div style="height: 204.50px; background: white; box-shadow: 0px 1px 3px rgba(54, 74, 99, 0.05); border-radius: 4px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                <div style="align-self: stretch; height: 204.50px; padding-bottom: 16px; flex-direction: column; justify-content: flex-start; align-items: center; gap: 16px; display: flex">
                    <div style="height: 120.50px; padding-bottom: 1px; border-bottom: 1px #DBDFEA solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                        <div style="flex-direction: column; justify-content: center; align-items: flex-start; display: flex">
                            <div style="padding-right: 24.70px; justify-content: flex-start; align-items: center; display: inline-flex">
                                <div style="padding-top: 14.49px; padding-bottom: 14.01px; padding-left: 24px; padding-right: 10px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="width: 18px; height: 18px; background: white; box-shadow: 0px 1px 1px 2px rgba(16, 25, 36, 0.08) inset; border-radius: 4px; border: 2px #DBDFEA solid"></div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 8px; padding-right: 360.66px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Course Name</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 8px; padding-right: 95.09px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Status</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 26px; padding-right: 26.08px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; justify-content: center; align-items: center; display: flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Batch</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 26px; padding-right: 6.08px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; justify-content: flex-end; align-items: center; display: flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">July-Aug</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 26px; padding-right: 7.08px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; justify-content: flex-end; align-items: center; display: flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Aug-Sep</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 26px; padding-right: 8.08px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; justify-content: flex-end; align-items: center; display: flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Sep-Oct</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 26px; padding-right: 8.08px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; justify-content: flex-end; align-items: center; display: flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Oct-Nov</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 26px; padding-right: 7.08px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; justify-content: flex-end; align-items: center; display: flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Nov-Dec</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 26px; padding-right: 9.08px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; justify-content: flex-end; align-items: center; display: flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Dec-Jan</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 26px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; justify-content: flex-end; align-items: center; display: flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Admission Fee</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 8px; padding-right: 52.05px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid"></div>
                            </div>
                            <div style="flex-direction: column; justify-content: center; align-items: flex-start; display: flex">
                                <div style="padding-right: 24.70px; justify-content: flex-start; align-items: center; display: inline-flex">
                                    <div style="padding-top: 28.49px; padding-bottom: 26.51px; padding-left: 24px; padding-right: 10px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="width: 18px; height: 18px; background: white; box-shadow: 0px 1px 1px 2px rgba(16, 25, 36, 0.08) inset; border-radius: 4px; border: 2px #DBDFEA solid"></div>
                                    </div>
                                    <div style="padding-top: 16px; padding-bottom: 17px; padding-left: 8px; padding-right: 20px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="padding-right: 244.16px; justify-content: flex-start; align-items: center; gap: 28.50px; display: inline-flex">
                                            <div style="width: 40px; align-self: stretch; padding-top: 8.45px; padding-bottom: 7.55px; padding-left: 9.81px; padding-right: 10.19px; background: #46972C; border-radius: 4px; justify-content: center; align-items: center; display: inline-flex">
                                                <div style="color: white; font-size: 14px; font-family: DM Sans; font-weight: 700; line-height: 23.10px; letter-spacing: 0.84px; word-wrap: break-word">GD</div>
                                            </div>
                                            <div style="align-self: stretch; padding-bottom: 0.14px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                <div style="color: #364A63; font-size: 15.60px; font-family: DM Sans; font-weight: 700; line-height: 17.16px; word-wrap: break-word">Graphic Design </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="width: 119px; padding-top: 27.49px; padding-bottom: 25.51px; padding-left: 8px; padding-right: 46.05px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: center; align-items: flex-start; display: inline-flex">
                                        <div style="padding-left: 7px; padding-right: 7px; padding-top: 1px; padding-bottom: 1px; background: #46972C; border-radius: 3px; border: 1px #46972C solid; justify-content: flex-start; align-items: center; display: inline-flex">
                                            <div style="text-align: center; color: white; font-size: 10.80px; font-family: DM Sans; font-weight: 500; line-height: 18px; letter-spacing: 0.11px; word-wrap: break-word">Active</div>
                                        </div>
                                    </div>
                                    <div style="padding-top: 18px; padding-bottom: 24.05px; padding-left: 8px; padding-right: 32.84px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">July-Batch23</div>
                                    </div>
                                    <div style="width: 88px; padding-top: 18px; padding-bottom: 24.05px; padding-left: 8px; padding-right: 32.84px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Submitted</div>
                                    </div>
                                    <div style="width: 77px; padding-top: 24.95px; padding-bottom: 24.05px; padding-left: 8px; padding-right: 32.84px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Submitted</div>
                                    </div>
                                    <div style="width: 87px; padding-top: 24.95px; padding-bottom: 24.05px; padding-left: 8px; padding-right: 32.84px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Submitted</div>
                                    </div>
                                    <div style="padding-top: 24.95px; padding-bottom: 24.05px; padding-left: 8px; padding-right: 32.84px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Submitted</div>
                                    </div>
                                    <div style="width: 91px; padding-top: 24.95px; padding-bottom: 24.05px; padding-left: 8px; padding-right: 32.84px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Submitted</div>
                                    </div>
                                    <div style="width: 88px; padding-top: 24.95px; padding-bottom: 24.05px; padding-left: 8px; padding-right: 32.84px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Submitted</div>
                                    </div>
                                    <div style="width: 92px; padding-top: 18px; padding-bottom: 24.05px; padding-left: 8px; padding-right: 32.84px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Submitted</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="width: 1540px; justify-content: space-between; align-items: center; display: inline-flex">
                        <div style="padding-top: 8px; padding-bottom: 8px; padding-left: 8px; padding-right: 8.52px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                <div style="padding-left: 11px; padding-right: 11px; padding-top: 10px; padding-bottom: 10px; background: white; border-top-left-radius: 4px; border-top-right-radius: 4px; border: 1px #E5E9F2 solid; justify-content: center; align-items: center; display: flex">
                                    <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 16px; word-wrap: break-word">Prev</div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="padding-left: 11px; padding-right: 11px; padding-top: 10px; padding-bottom: 10px; background: white; border: 1px #E5E9F2 solid; justify-content: center; align-items: center; display: inline-flex">
                                        <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 16px; word-wrap: break-word">1</div>
                                    </div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="padding-left: 11px; padding-right: 11px; padding-top: 10px; padding-bottom: 10px; background: white; border: 1px #E5E9F2 solid; justify-content: center; align-items: center; display: inline-flex">
                                        <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 16px; word-wrap: break-word">2</div>
                                    </div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="padding-top: 12px; padding-bottom: 11px; padding-left: 11px; padding-right: 11px; border: 1px #E5E9F2 solid; justify-content: center; align-items: center; display: inline-flex">
                                        <div style="width: 13px; height: 13px; padding-top: 4.88px; padding-bottom: 5.42px; padding-right: 1.62px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                            <div style="width: 11.38px; height: 2.70px; background: #526484"></div>
                                        </div>
                                    </div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="padding-left: 11px; padding-right: 11px; padding-top: 10px; padding-bottom: 10px; background: white; border: 1px #E5E9F2 solid; justify-content: center; align-items: center; display: inline-flex">
                                        <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 16px; word-wrap: break-word">6</div>
                                    </div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="padding-left: 11px; padding-right: 11px; padding-top: 10px; padding-bottom: 10px; background: white; border: 1px #E5E9F2 solid; justify-content: center; align-items: center; display: inline-flex">
                                        <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 16px; word-wrap: break-word">7</div>
                                    </div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="padding-top: 10px; padding-bottom: 10px; padding-left: 11px; padding-right: 10.56px; background: white; border-top-left-radius: 4px; border-top-right-radius: 4px; border: 1px #E5E9F2 solid; justify-content: center; align-items: center; display: inline-flex">
                                        <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 16px; word-wrap: break-word">Next</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div style="padding-top: 8px; padding-bottom: 8px; padding-right: 0.10px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="justify-content: flex-start; align-items: center; display: inline-flex">
                                <div style="padding-left: 8px; padding-right: 8px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; text-transform: uppercase; line-height: 21.45px; word-wrap: break-word">Page</div>
                                </div>
                                <div style="width: 73.94px; height: 36px; position: relative">
                                    <div style="width: 1px; height: 1px; left: 8px; top: 0px; position: absolute; background: white; border-radius: 4px">
                                        <div style="width: 12px; height: 12px; padding-left: 1.50px; padding-right: 1.50px; padding-top: 3.75px; padding-bottom: 3.75px; left: -27px; top: -5.50px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                            <div style="width: 9px; height: 4.50px; border: 1.50px #343A40 solid"></div>
                                        </div>
                                        <div style="height: 20px; left: 0px; top: 0px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                            <div style="color: #3C4D62; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 20px; word-wrap: break-word">1</div>
                                        </div>
                                    </div>
                                    <div style="width: 58px; padding: 1px; left: 8px; top: 0px; position: absolute; background: white; border-radius: 4px; border: 1px #DBDFEA solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="padding-top: 7px; padding-bottom: 7px; padding-left: 16px; padding-right: 36px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                            <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; text-transform: uppercase; line-height: 20px; word-wrap: break-word">1</div>
                                        </div>
                                    </div>
                                    <div style="width: 13px; height: 13px; padding-top: 4.33px; padding-bottom: 4.89px; padding-right: 6.53px; left: 41.44px; top: 24.50px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="width: 6.47px; height: 3.78px; background: #526484"></div>
                                    </div>
                                </div>
                                <div style="padding-left: 8px; padding-right: 8px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; text-transform: uppercase; line-height: 21.45px; word-wrap: break-word">OF 1</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>          
                <!-- End of Page Wrapper -->
  
                <!-- Scroll to Top Button-->
                <a class="scroll-to-top rounded" href="#page-top">
                    <i class="fas fa-angle-up"></i>
                </a>
                <!-- Bootstrap core JavaScript-->
                <script src="vendor/jquery/jquery.min.js"></script>
                <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

                <!-- Core plugin JavaScript-->
                <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

                <!-- Custom scripts for all pages-->
                <script src="js/sb-admin-2.min.js"></script>

                <!-- Page level plugins -->
                <script src="vendor/chart.js/Chart.min.js"></script>

                <!-- Page level custom scripts -->
                <script src="js/demo/chart-area-demo.js"></script>
                <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>