<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Student-Potrels</title>
    <style>
             /* Your existing styles and modifications */

        /* Add new styles or modifications for responsiveness here */
        @media (max-width: 320px) {
            /* Define styles for smaller screens (example: mobile devices) */
            /* Example: Adjust the styles for smaller screens */
            .free1 {
                width: 100%;
            }
            /* ... Add more responsive styles as needed */
        }
    </style>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body>  
      
      <div class="free1">
    <div id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">
    <!-- Sidebar -->
<div class="free1" class="sidebar">
    <ul class="navbar-nav  sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a style="background-color: #46972C;" sidebar-brand d-flex align-items-center justify-content-center
            href="index.html">
            <div class="sidebar-brand-icon p-2">
                <img class="mr-2"src="img/hunar logo.png" alt="photo">
                 <svg xmlns="http://www.w3.org/2000/svg" width=" 21.984px" height="16.008px" viewBox="0 0 22 17" fill="none">
                    <path d="M21 9.5H0.984375C0.71875 9.5 0.488281 9.40234 0.292969 9.20703C0.0976563 9.01172 0 8.77344 0 8.49219C0 8.22656 0.0976563 7.99609 0.292969 7.80078C0.488281 7.60547 0.71875 7.50781 0.984375 7.50781H21C21.2656 7.50781 21.4961 7.60547 21.6914 7.80078C21.8867 7.99609 21.9844 8.22656 21.9844 8.49219C21.9844 8.77344 21.8867 9.01172 21.6914 9.20703C21.4961 9.40234 21.2656 9.5 21 9.5ZM21.9844 1.50781C21.9844 1.22656 21.8867 0.988281 21.6914 0.792969C21.4961 0.597656 21.2656 0.5 21 0.5H0.984375C0.71875 0.5 0.488281 0.597656 0.292969 0.792969C0.0976563 0.988281 0 1.22656 0 1.50781C0 1.77344 0.0976563 2.00391 0.292969 2.19922C0.488281 2.39453 0.71875 2.49219 0.984375 2.49219H21C21.2656 2.49219 21.4961 2.39453 21.6914 2.19922C21.8867 2.00391 21.9844 1.77344 21.9844 1.50781ZM21.9844 15.5C21.9844 15.2188 21.8867 14.9805 21.6914 14.7852C21.4961 14.5898 21.2656 14.4922 21 14.4922H0.984375C0.71875 14.4922 0.488281 14.5898 0.292969 14.7852C0.0976563 14.9805 0 15.2188 0 15.5C0 15.7812 0.0976563 16.0195 0.292969 16.2148C0.488281 16.4102 0.71875 16.5078 0.984375 16.5078H21C21.2656 16.5078 21.4961 16.4102 21.6914 16.2148C21.8867 16.0195 21.9844 15.7812 21.9844 15.5Z" fill="white"/>
                    </svg> 
               
            </div>
            <div class="sidebar-brand-text mx-3"></div>
        </a>

        <!-- Divider -->
        <div class="sidebar-divider my-0 px-2">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active bg-gray-200 mt-5" style="border-radius:6px;width:100%">
                    <a class="nav-link" href="index.php">
                        <img src="img/Vector.svg" alt="photo">
                        <span class="text-primary ml-3">Dashboard</span></a>
                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header"></h6>
                        <a class="collapse-item" href="persional.php">Persional Informaion</a>
                        <a class="collapse-item" href="update.php">update Information</a>
                    </div>
                </div>
                </li>


            <!-- Divider -->
            <div class="sidebar-divider">

                <!-- Heading -->
                <div class="sidebar-heading">
                </div>

                <!-- Nav Item - Pages Collapse Menu -->
                <li class="nav-item">
                    <a class="nav-link collapsed" href="courses.php" >
                        <img src="img/Vector (1).svg" alt="photo">
                        <span class="font-weight-bold ml-3" style="Color:#8094AE;">Courses</span>
                    </a>
                   
                    </div>
                   
                </li>

                <!-- Nav Item - Utilities Collapse Menu -->
                <li class="nav-item">
                    <a class="nav-link collapsed" href="free.php">
                        <img src="img/Vector (2).svg" alt="photo">
                        <span class="font-weight-bold ml-3" style="Color:#8094AE;">Free Detils</span>
                    </a>
                   
                </li>
                <!-- Divider -->
                <!-- <hr class="sidebar-divider"> -->

                <!-- Heading -->
                <div class="sidebar-heading">
                </div>

                <!-- Nav Item - Pages Collapse Menu -->
                <li class="nav-item">
                    <a class="nav-link collapsed" href="Schlor.php">
                        <img src="img/Vector (3).svg" alt="photo">
                        <span class="font-weight-bold ml-3" style="Color:#8094AE;">Schloarship</span>
                    </a>
                    <div id="collapsePages" class="collapse" aria-labelledby="headingPages"
                        data-parent="#accordionSidebar">
                        
                </li>

                <!-- Nav Item - Charts -->
                <li class="nav-item">
                    <a class="nav-link collapsed" href="constant-form.php">
                        <img src="img/Vector (4).svg" alt="photo">
                        <span class="font-weight-bold ml-3" style="Color:#8094AE;">Constact foam</span>
                    </a>
                    <div id="collapsePages" class="collapse" aria-labelledby="headingPages"
                        data-parent="#accordionSidebar">
                        
                </li>
                <!-- <li class="nav-item">
            <a class="nav-link" href="charts.html">
              <img src="img/Vector (4).svg" alt="photo">
                <span>OJT records</span>
            </a>
        </li>   -->
                <!-- Nav Item - Tables -->
                <li class="nav-item">
                    <a class="nav-link collapsed" href="contact.php">
                        <img src="img/Vector (5).svg" alt="photo">
                        <span class="font-weight-bold ml-3" style="Color:#8094AE;">Contact SRO</span></a>
                </li>
                <!-- Divider -->
                <hr class="sidebar-divider d-none d-md-block">

                <!-- Sidebar Toggler (Sidebar)
        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div> -->

                <!-- Sidebar Message -->
                <!-- <div class="sidebar-card d-none d-lg-flex"> -->
                <!-- <img class="sidebar-card-illustration mb-2" src="img/undraw_rocket.svg" alt="..."> -->
                <!-- <p class="text-center mb-2"><strong>SB Admin Pro</strong> is packed with premium features, components, and more!</p> -->
                <!-- <a class="btn btn-success btn-sm" href="https://startbootstrap.com/theme/sb-admin-pro">Upgrade to Pro!</a> -->
            </div>
    </ul>
</div>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column"style="overflow-y: hidden;">

        <!-- Main Content -->
        <div id="content">
            

            <!-- Topbar -->
        <div class="free1" class="header">
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                <!-- Sidebar Toggle (Topbar) -->
                <!-- <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button> -->

                <!-- Topbar Search -->
                <form
                    class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                    <div class="input-group">
                        <button class="btn" type="button">
                            <i class="fas fa-search fa-sm"></i>
                        </button>
                        <input type="text" class="form-control bg-light border-0 small"
                            placeholder="search anything" aria-label="Search" aria-describedby="basic-addon2">
                        <div class="input-group-append">

                        </div>
                    </div>
                </form>

                <!-- Topbar Navbar -->
                <ul  class="navbar-nav ml-auto">

                    <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                    <li class="nav-item dropdown no-arrow d-sm-none">
                        <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-search fa-fw"></i>
                        </a>
                        <!-- Dropdown - Messages -->
                        <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                            aria-labelledby="searchDropdown">
                            <form class="form-inline mr-auto w-100 navbar-search">
                                <div class="input-group">
                                    <input type="text" class="form-control bg-light border-0 small"
                                        placeholder="Search for..." aria-label="Search"
                                        aria-describedby="basic-addon2">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="button">
                                            <i class="fas fa-search fa-sm"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </li>

                    <!-- Nav Item - Alerts -->
                    <li class="nav-item dropdown no-arrow mx-1">
                        <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="img/Vector (7).svg" alt="photo">
                            <!-- Counter - Alerts -->
                            <span class="badge badge-danger badge-counter"></span>
                        </a>
                        <!-- Dropdown - Alerts -->
                        <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                            aria-labelledby="alertsDropdown">
                            <h6 class="dropdown-header">
                                Alerts Center
                            </h6>
                            <a class="dropdown-item d-flex align-items-center" href="#">
                                <div class="mr-3">
                                    <div class="icon-circle bg-primary">
                                        <i class="fas fa-file-alt text-white"></i>
                                    </div>
                                </div>
                                <div>
                                    <div class="small text-gray-500">December 12, 2019</div>
                                    <span class="font-weight-bold">A new monthly report is ready to download!</span>
                                </div>
                            </a>
                            <a class="dropdown-item d-flex align-items-center" href="#">
                                <div class="mr-3">
                                    <div class="icon-circle bg-success">
                                        <i class="fas fa-donate text-white"></i>
                                    </div>
                                </div>
                                <div>
                                    <div class="small text-gray-500">December 7, 2019</div>
                                    $290.29 has been deposited into your account!
                                </div>
                            </a>
                            <a class="dropdown-item d-flex align-items-center" href="#">
                                <div class="mr-3">
                                    <div class="icon-circle bg-warning">
                                        <i class="fas fa-exclamation-triangle text-white"></i>
                                    </div>
                                </div>
                                <div>
                                    <div class="small text-gray-500">December 2, 2019</div>
                                    Spending Alert: We've noticed unusually high spending for your account.
                                </div>
                            </a>
                            <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                        </div>
                    </li>

                    <!-- Nav Item - Messages -->
                    <!-- <li class="nav-item dropdown no-arrow mx-1">
                        <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-envelope fa-fw"></i> -->
                    <!-- Counter - Messages -->
                    <!-- <span class="badge badge-danger badge-counter">7</span> -->
                    </a>
                    <!-- Dropdown - Messages -->
                    <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                        aria-labelledby="messagesDropdown">
                        <h6 class="dropdown-header">
                            Message Center
                        </h6>
                        <a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="dropdown-list-image mr-3">
                                <img class="rounded-circle" src="img/undraw_profile_1.svg" alt="...">
                                <div class="status-indicator bg-success"></div>
                            </div>
                            <div class="font-weight-bold">
                                <div class="text-truncate">Hi there! I am wondering if you can help me with a
                                    problem I've been having.</div>
                                <div class="small text-gray-500">Emily Fowler · 58m</div>
                            </div>
                        </a>
                        <a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="dropdown-list-image mr-3">
                                <img class="rounded-circle" src="img/undraw_profile_2.svg" alt="...">
                                <div class="status-indicator"></div>
                            </div>
                            <div>
                                <div class="text-truncate">I have the photos that you ordered last month, how
                                    would you like them sent to you?</div>
                                <div class="small text-gray-500">Jae Chun · 1d</div>
                            </div>
                        </a>
                        <a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="dropdown-list-image mr-3">
                                <img class="rounded-circle" src="img/undraw_profile_3.svg" alt="...">
                                <div class="status-indicator bg-warning"></div>
                            </div>
                            <div>
                                <div class="text-truncate">Last month's report looks great, I am very happy with
                                    the progress so far, keep up the good work!</div>
                                <div class="small text-gray-500">Morgan Alvarez · 2d</div>
                            </div>
                        </a>
                        <a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="dropdown-list-image mr-3">
                                <img class="rounded-circle" src="https://source.unsplash.com/Mv9hjnEUHR4/60x60"
                                    alt="...">
                                <div class="status-indicator bg-success"></div>
                            </div>
                            <div>
                                <div class="text-truncate">Am I a good boy? The reason I ask is because someone
                                    told me that people say this to all dogs, even if they aren't good...</div>
                                <div class="small text-gray-500">Chicken the Dog · 2w</div>
                            </div>
                        </a>
                        <a class="dropdown-item text-center small text-gray-500" href="#">Read More Messages</a>
                    </div>
                    </li>

                    <div class="topbar-divider d-none d-sm-block"></div>

                    <!-- Nav Item - User Information -->
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="img-fluid rounded-circle m-1  p-2" style="background-color:#46972C"
                                src="img/Vector.png" alt="photo">
                            <ul class="list-group">
                                <span style="color: #46972C;">Administrator</span>
                                <span Class="text-dark">Dr.Adeel <img src="img/Vector (6).svg" alt="photo"></span>

                            </ul>
                            <!-- <span class="mr-2 d-lg-inline text-gray-600 small">Administrator</span>
                                <span class="mr-2 d-lg-inline text-gray-600 small">Dr.Adeel</span> -->
                        </a>
                        <!-- Dropdown - User Information -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                            aria-labelledby="userDropdown">
                            <a class="dropdown-item" href="#">
                                <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                Profile
                            </a>
                            <a class="dropdown-item" href="#">
                                <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                Settings
                            </a>
                            <a class="dropdown-item" href="#">
                                <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                Activity Log
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                Logout
                            </a>
                        </div>
                    </li>

                </ul>

            </nav>
        </div>
            <!-- End of Topbar -->
            <div style="width: 100%; height: 100%; position: relative">
    <div style="width: 307px; padding-bottom: 0.20px; left: 29px; top: 31px; position: absolute; justify-content: center; align-items: center; display: inline-flex">
        <div style="flex: 1 1 0; align-self: stretch; justify-content: space-between; align-items: center; display: inline-flex">
            <div style="flex-direction: column; justify-content: center; align-items: flex-start; gap: 8.80px; display: inline-flex">
                <div style="color: #364A63; font-size: 28px; font-family: DM Sans; font-weight: 700; line-height: 30.80px; word-wrap: break-word"></div>
                <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word"></div>
            </div>
        </div>
    </div>
    <div style="height: 64.09px; padding-top: 21px; padding-bottom: 20px; padding-left: 29px; padding-right: 29px; left: -20px; top: 955px; position: absolute; background: white; box-shadow: 0px 1px 3px rgba(54, 74, 99, 0.05); border-top: 1px #E5E9F2 solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
        <div style="padding-right: 979px; justify-content: flex-start; align-items: center; display: inline-flex">
            <div style="align-self: stretch; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">© 2023 - RIET LMS by Advance Web Application Development Students of Batch July-2023</div>
            </div>
        </div>
    </div>
    
    <div style="height: 358.39px; padding-top: 31px; padding-bottom: 32px; padding-left: 29px; padding-right: 29px; left: 0px; top: 106px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
        <div style="height: 295.39px; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 27.09px; display: flex">
            <div style="width: 1572px; justify-content: space-between; align-items: center; display: inline-flex">
                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 8.80px; display: inline-flex">
                    <div style="color: #364A63; font-size: 28px; font-family: DM Sans; font-weight: 700; line-height: 30.80px; word-wrap: break-word">Fee Details</div>
                    <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">You are registered in one course.</div>
                </div>
                <div></div>
            </div>
            <!-- <div style="margin-left: 1100px;">
                        <button type="button" class="btn btn-primary">VIEW</button>
                        <button type="button" class="btn btn-success">UPDATE</button>
                        <button type="button" class="btn btn-danger">DELETE</button>
                    </div> -->
            <div style=" height: 204.50px; background: white; box-shadow: 0px 1px 3px rgba(54, 74, 99, 0.05); border-radius: 4px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                <div style="align-self: stretch; height: 204.50px; padding-bottom: 16px; flex-direction: column; justify-content: flex-start; align-items: center; gap: 16px; display: flex">
                    <div style="margin-right:130px; height: 120.50px; padding-bottom: 1px; border-bottom: 1px #DBDFEA solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                        <div style="flex-direction: column; justify-content: center; align-items: flex-start; display: flex">
                            <div style="padding-right: 24.70px; justify-content: flex-start; align-items: center; display: inline-flex">
                                <div style="padding-top: 14.49px; padding-bottom: 14.01px; padding-left: 24px; padding-right: 10px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="width: 18px; height: 18px; background: white; box-shadow: 0px 1px 1px 2px rgba(16, 25, 36, 0.08) inset; border-radius: 4px; border: 2px #DBDFEA solid"></div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 8px; padding-right: 360.66px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Course Name</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 8px; padding-right: 95.09px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Status</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 26px; padding-right: 26.08px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; justify-content: center; align-items: center; display: flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Batch</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 26px; padding-right: 6.08px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; justify-content: flex-end; align-items: center; display: flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">July-Aug</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 26px; padding-right: 7.08px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; justify-content: flex-end; align-items: center; display: flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Aug-Sep</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 26px; padding-right: 8.08px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; justify-content: flex-end; align-items: center; display: flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Sep-Oct</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 26px; padding-right: 8.08px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; justify-content: flex-end; align-items: center; display: flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Oct-Nov</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 26px; padding-right: 7.08px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; justify-content: flex-end; align-items: center; display: flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Nov-Dec</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 26px; padding-right: 9.08px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; justify-content: flex-end; align-items: center; display: flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Dec-Jan</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 26px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; justify-content: flex-end; align-items: center; display: flex">
                                    <div style="color: #8094AE; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 21.45px; word-wrap: break-word">Admission Fee</div>
                                </div>
                                <div style="padding-top: 12.28px; padding-bottom: 12.22px; padding-left: 8px; padding-right: 52.05px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid"></div>
                            </div>
                            <div style="flex-direction: column; justify-content: center; align-items: flex-start; display: flex">
                                <div style="padding-right: 24.70px; justify-content: flex-start; align-items: center; display: inline-flex">
                                    <div style="padding-top: 28.49px; padding-bottom: 26.51px; padding-left: 24px; padding-right: 10px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="width: 18px; height: 18px; background: white; box-shadow: 0px 1px 1px 2px rgba(16, 25, 36, 0.08) inset; border-radius: 4px; border: 2px #DBDFEA solid"></div>
                                    </div>
                                    <div style="padding-top: 16px; padding-bottom: 17px; padding-left: 8px; padding-right: 20px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="padding-right: 244.16px; justify-content: flex-start; align-items: center; gap: 28.50px; display: inline-flex">
                                            <div style="width: 40px; align-self: stretch; padding-top: 8.45px; padding-bottom: 7.55px; padding-left: 9.81px; padding-right: 10.19px; background: #46972C; border-radius: 4px; justify-content: center; align-items: center; display: inline-flex">
                                                <div style="color: white; font-size: 14px; font-family: DM Sans; font-weight: 700; line-height: 23.10px; letter-spacing: 0.84px; word-wrap: break-word">GD</div>
                                            </div>
                                            <div style="align-self: stretch; padding-bottom: 0.14px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                                <div style="color: #364A63; font-size: 15.60px; font-family: DM Sans; font-weight: 700; line-height: 17.16px; word-wrap: break-word">Graphic Design </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="width: 119px; padding-top: 27.49px; padding-bottom: 25.51px; padding-left: 8px; padding-right: 46.05px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: center; align-items: flex-start; display: inline-flex">
                                        <div style="padding-left: 7px; padding-right: 7px; padding-top: 1px; padding-bottom: 1px; background: #46972C; border-radius: 3px; border: 1px #46972C solid; justify-content: flex-start; align-items: center; display: inline-flex">
                                            <div style="text-align: center; color: white; font-size: 10.80px; font-family: DM Sans; font-weight: 500; line-height: 18px; letter-spacing: 0.11px; word-wrap: break-word">Active</div>
                                        </div>
                                    </div>
                                    <div style="padding-top: 18px; padding-bottom: 24.05px; padding-left: 8px; padding-right: 32.84px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">July-Batch23</div>
                                    </div>
                                    <div style="width: 88px; padding-top: 18px; padding-bottom: 24.05px; padding-left: 8px; padding-right: 32.84px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Submitted</div>
                                    </div>
                                    <div style="width: 77px; padding-top: 24.95px; padding-bottom: 24.05px; padding-left: 8px; padding-right: 32.84px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Submitted</div>
                                    </div>
                                    <div style="width: 87px; padding-top: 24.95px; padding-bottom: 24.05px; padding-left: 8px; padding-right: 32.84px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Submitted</div>
                                    </div>
                                    <div style="padding-top: 24.95px; padding-bottom: 24.05px; padding-left: 8px; padding-right: 32.84px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Submitted</div>
                                    </div>
                                    <div style="width: 91px; padding-top: 24.95px; padding-bottom: 24.05px; padding-left: 8px; padding-right: 32.84px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Submitted</div>
                                    </div>
                                    <div style="width: 88px; padding-top: 24.95px; padding-bottom: 24.05px; padding-left: 8px; padding-right: 32.84px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Submitted</div>
                                    </div>
                                    <div style="width: 92px; padding-top: 18px; padding-bottom: 24.05px; padding-left: 8px; padding-right: 32.84px; border-bottom: 1px rgba(219, 223, 234, 0.90) solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Submitted</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="width: 1540px; justify-content: space-between; align-items: center; display: inline-flex">
                        <div style="padding-top: 8px; padding-bottom: 8px; padding-left: 8px; padding-right: 8.52px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                <div style="padding-left: 11px; padding-right: 11px; padding-top: 10px; padding-bottom: 10px; background: white; border-top-left-radius: 4px; border-top-right-radius: 4px; border: 1px #E5E9F2 solid; justify-content: center; align-items: center; display: flex">
                                    <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 16px; word-wrap: break-word">Prev</div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="padding-left: 11px; padding-right: 11px; padding-top: 10px; padding-bottom: 10px; background: white; border: 1px #E5E9F2 solid; justify-content: center; align-items: center; display: inline-flex">
                                        <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 16px; word-wrap: break-word">1</div>
                                    </div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="padding-left: 11px; padding-right: 11px; padding-top: 10px; padding-bottom: 10px; background: white; border: 1px #E5E9F2 solid; justify-content: center; align-items: center; display: inline-flex">
                                        <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 16px; word-wrap: break-word">2</div>
                                    </div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="padding-top: 12px; padding-bottom: 11px; padding-left: 11px; padding-right: 11px; border: 1px #E5E9F2 solid; justify-content: center; align-items: center; display: inline-flex">
                                        <div style="width: 13px; height: 13px; padding-top: 4.88px; padding-bottom: 5.42px; padding-right: 1.62px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                            <div style="width: 11.38px; height: 2.70px; background: #526484"></div>
                                        </div>
                                    </div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="padding-left: 11px; padding-right: 11px; padding-top: 10px; padding-bottom: 10px; background: white; border: 1px #E5E9F2 solid; justify-content: center; align-items: center; display: inline-flex">
                                        <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 16px; word-wrap: break-word">6</div>
                                    </div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="padding-left: 11px; padding-right: 11px; padding-top: 10px; padding-bottom: 10px; background: white; border: 1px #E5E9F2 solid; justify-content: center; align-items: center; display: inline-flex">
                                        <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 16px; word-wrap: break-word">7</div>
                                    </div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="padding-top: 10px; padding-bottom: 10px; padding-left: 11px; padding-right: 10.56px; background: white; border-top-left-radius: 4px; border-top-right-radius: 4px; border: 1px #E5E9F2 solid; justify-content: center; align-items: center; display: inline-flex">
                                        <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 16px; word-wrap: break-word">Next</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div style="padding-top: 8px; padding-bottom: 8px; padding-right: 220px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="justify-content: flex-start; align-items: center; display: inline-flex">
                                <div style="padding-left: 8px; padding-right: 8px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; text-transform: uppercase; line-height: 21.45px; word-wrap: break-word">Page</div>
                                </div>
                                <div style="width: 73.94px; height: 36px; position: relative">
                                    <div style="width: 1px; height: 1px; left: 8px; top: 0px; position: absolute; background: white; border-radius: 4px">
                                        <div style="width: 12px; height: 12px; padding-left: 1.50px; padding-right: 1.50px; padding-top: 3.75px; padding-bottom: 3.75px; left: -27px; top: -5.50px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                            <div style="width: 9px; height: 4.50px; border: 1.50px #343A40 solid"></div>
                                        </div>
                                        <div style="height: 20px; left: 0px; top: 0px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                            <div style="color: #3C4D62; font-size: 13px; font-family: DM Sans; font-weight: 400; line-height: 20px; word-wrap: break-word">1</div>
                                        </div>
                                    </div>
                                    <div style="width: 58px; padding: 1px; left: 8px; top: 0px; position: absolute; background: white; border-radius: 4px; border: 1px #DBDFEA solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="padding-top: 7px; padding-bottom: 7px; padding-left: 16px; padding-right: 36px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                            <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; text-transform: uppercase; line-height: 20px; word-wrap: break-word">1</div>
                                        </div>
                                    </div>
                                    <div style="width: 13px; height: 13px; padding-top: 4.33px; padding-bottom: 4.89px; padding-right: 6.53px; left: 41.44px; top: 24.50px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="width: 6.47px; height: 3.78px; background: #526484"></div>
                                    </div>
                                </div>
                                <div style="padding-left: 8px; padding-right: 8px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #526484; font-size: 13px; font-family: DM Sans; font-weight: 400; text-transform: uppercase; line-height: 21.45px; word-wrap: break-word">OF 1</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
   

        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->
   

   

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    

                    <!-- Content Row -->
                

                        

                        <!-- Earnings (Monthly) Card Example -->
                  

                        <!-- Earnings (Monthly) Card Example -->
                 

                        <!-- Earnings (Monthly) Card Example -->
                        

                        <!-- Pending Requests Card Example -->
                      

                    <!-- Content Row -->

                   

                    <!-- Content Row -->
                   
                <!-- /.container-fluid -->

            
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
            <div style="width: 100%; height: 100%; padding-top: 21px; padding-bottom: 20px; padding-left: 29px; padding-right: 29px; background: white; box-shadow: 0px 1px 3px rgba(54, 74, 99, 0.05); border-top: 1px #E5E9F2 solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
    <div style="padding-right: 979px; justify-content: flex-start; align-items: center; display: inline-flex">
        <div style="align-self: stretch; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
            <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">© 2023 - RIET LMS by Advance Web Application Development Students of Batch July-2023</div>
        </div>
    </div>
</div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
    </div>
</body>

</html>