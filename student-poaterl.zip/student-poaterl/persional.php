<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
             /* Your existing styles and modifications */

        /* Add new styles or modifications for responsiveness here */
        @media (max-width: 320px) {
            /* Define styles for smaller screens (example: mobile devices) */
            /* Example: Adjust the styles for smaller screens */
            .pers1 {
                width: 100%;
            }
            /* ... Add more responsive styles as needed */
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>
<body>
    <div class="pers1">
   <?php
include 'sidebar.php';

?>

<div style="width: 100%; height: 100%; padding-bottom: 36px; background: white; box-shadow: 0px 1px 3px rgba(54, 74, 99, 0.05); border-radius: 4px; justify-content: center; align-items: center; display: inline-flex">
    <div style="flex: 1 1 0; align-self: stretch; padding-bottom: 0.44px; justify-content: center; align-items: flex-start; display: inline-flex">
        <div style="width: 380px; align-self: stretch; padding-bottom: 63px; padding-right: 1px; border-right: 1px #E5E9F2 solid; flex-direction: column; justify-content: flex-start; align-items: center; display: inline-flex">
            <div style="align-self: stretch; height: 604px; flex-direction: column; justify-content: center; align-items: center; display: inline-flex">
                <div style="width: 379px; height: 604.27px; position: relative; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                    <div style="height: 91.89px; padding-top: 24px; padding-bottom: 25px; padding-left: 24px; padding-right: 24px; border-bottom: 1px #DBDFEA solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                        <div style="width: 331px; justify-content: center; align-items: center; display: inline-flex">
                            <div style="width: 40px; align-self: stretch; padding-top: 8.45px; padding-bottom: 7.55px; padding-left: 9.83px; padding-right: 10.17px; background: #043C8B; border-radius: 20px; justify-content: center; align-items: center; display: inline-flex">
                                <div style="color: white; font-size: 14px; font-family: DM Sans; font-weight: 700; line-height: 23.10px; letter-spacing: 0.84px; word-wrap: break-word">AB</div>
                            </div>
                            <div style="align-self: stretch; padding-left: 90px; flex-direction: column; justify-content: center; align-items: flex-start; display: inline-flex">
                                <div style="padding-bottom: 0.80px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                    <div style="color: #364A63; font-size: 14px; font-family: DM Sans; font-weight: 700; line-height: 23.10px; word-wrap: break-word">Abu Bin Ishtiyak</div>
                                    <div style="color: #8094AE; font-size: 12px; font-family: DM Sans; font-weight: 400; line-height: 19.80px; word-wrap: break-word">info@softnio.com</div>
                                </div>
                            </div>
                            <div style="flex: 1 1 0; align-self: stretch; padding-top: 9px; padding-bottom: 9px; padding-left: 151.54px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                <div style="width: 18.45px; height: 18px; padding-top: 0.76px; padding-bottom: 1.49px; padding-left: 0.09px; padding-right: 14.59px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                    <div style="width: 3.76px; height: 15.75px; background: #526484"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="width: 379px; height: 52.80px; position: relative">
                        <div style="height: 18px; padding-right: 10px; left: 24px; top: 16.39px; position: absolute; opacity: 0.80; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="width: 18px; height: 18px; padding-top: 0.47px; padding-bottom: 1.23px; padding-right: 1.72px; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                <div style="width: 16.28px; height: 16.29px; background: #043C8B"></div>
                            </div>
                        </div>
                        <div style="left: 120px; top: 16px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="color: #043C8B; font-size: 14px; font-family: DM Sans; font-weight: 500; line-height: 20.80px; word-wrap: break-word"> <a href="update1.php">Persional Infomation</a></div>
                        </div>
                        <div style="width: 16px; height: 20.80px; padding-top: 6.07px; padding-bottom: 6.74px; padding-right: 11.34px; left: 343px; top: 36.80px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="width: 4.66px; height: 7.98px; background: #043C8B"></div>
                        </div>
                    </div>
                    <div style="height: 77.80px; padding-bottom: 1px; border-bottom: 1px #DBDFEA solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                        <div style="height: 76.80px; padding-top: 12px; padding-bottom: 12px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                            <div style="width: 379px; height: 52.80px; position: relative">
                                <div style="height: 18px; padding-right: 10px; left: 24px; top: 16.39px; position: absolute; opacity: 0.80; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="width: 18px; height: 18px; padding-top: 1.62px; padding-bottom: 2.36px; padding-right: 4.50px; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="width: 13.50px; height: 14.03px; background: #8094AE"></div>
                                    </div>
                                </div>
                                <div style="left: 120px; top: 16px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 500; line-height: 20.80px; word-wrap: break-word"><a href="Notification.php"> Notifications</a></div>
                                </div>
                                <div style="width: 16px; height: 20.80px; padding-top: 6.07px; padding-bottom: 6.74px; padding-right: 11.34px; left: 343px; top: 36.80px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="width: 4.66px; height: 7.98px; background: #8094AE"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="width: 331px; height: 104.56px; position: relative">
                        <div style="left: 110px; top: 0px; position: absolute; color: #8094AE; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 1.65px; word-wrap: break-word">Last Login</div>
                        <div style="left: 110px; top: 21.19px; position: absolute; color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">06-29-2020 02:39pm</div>
                        <div style="left: 110px; top: 60.28px; position: absolute; color: #8094AE; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 1.65px; word-wrap: break-word">Login IP</div>
                        <div style="left: 110px; top: 81.47px; position: absolute; color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">192.129.243.28</div>
                    </div>
                </div>
            </div>
        </div>
        <div style="width: 1192px; height: 794.56px; position: relative; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
            <div style="justify-content: center; align-items: center; gap: 834px; display: inline-flex">
                <div style="align-self: stretch; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 7.39px; display: inline-flex">
                    <div style="color: #364A63; font-size: 24px; font-family: DM Sans; font-weight: 700; line-height: 26.40px; word-wrap: break-word">Personal Information</div>
                    <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; ">Basic info, like your name and address.</div>
                </div>
                <div style="align-self: stretch; padding-top: 9px; padding-bottom: 9px; padding-left: 8.77px; padding-right: 2.78px; justify-content: flex-start; align-items: center; display: inline-flex">
                    <div style="width: 18.45px; height: 18px; padding-top: 1.88px; padding-bottom: 1.11px; padding-left: 0.09px; padding-right: 3.34px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                        <div style="width: 15.01px; height: 15.01px; background: #526484"></div>
                    </div>
                </div>
            </div>
            <div style="width: 1112px; height: 573.19px; position: relative">
                <div style="height: 29.19px; padding-top: 8px; padding-bottom: 7.19px; padding-left: 20px; padding-right: 1042px; left: 0px; top: 0px; position: absolute; background: #EBEEF2; border-radius: 4px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                    <div style="color: #8094AE; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 2.20px; word-wrap: break-word">Basics</div>
                </div>
                <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 33.19px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                    <div style="flex: 1 1 0; height: 25px; padding-right: 426px; justify-content: flex-start; align-items: center; display: flex">
                        <div style="width: 536px; padding-right: 2px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Full Name as per Matric Marksheet</div>
                        </div>
                        <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">Abu Bin Ishtiyak</div>
                        </div>
                    </div>
                </div>
                <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 106.94px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                    <div style="flex: 1 1 0; height: 25px; padding-right: 483px; justify-content: flex-start; align-items: center; display: flex">
                        <div style="width: 536px; padding-right: 447px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">CNIC</div>
                        </div>
                        <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">Ishtiyak</div>
                        </div>
                    </div>
                </div>
                <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 180.69px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                    <div style="flex: 1 1 0; height: 25px; padding-right: 413px; justify-content: flex-start; align-items: center; display: flex">
                        <div style="width: 536px; padding-right: 501px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Email</div>
                        </div>
                        <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">info@softnio.com</div>
                        </div>
                    </div>
                </div>
                <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 254.44px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                    <div style="flex: 1 1 0; height: 25px; padding-right: 454px; justify-content: flex-start; align-items: center; display: flex">
                        <div style="width: 536px; padding-right: 439px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Phone Number preferably WhatsApp</div>
                        </div>
                        <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="color: #8094AE; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">Not add yet</div>
                        </div>
                    </div>
                </div>
                <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 328.19px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                    <div style="flex: 1 1 0; height: 25px; padding-right: 449px; justify-content: flex-start; align-items: center; display: flex">
                        <div style="width: 536px; padding-right: 455px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Date of Birth</div>
                        </div>
                        <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">29 Feb, 1986</div>
                        </div>
                    </div>
                </div>
                <div style="width: 1072px; padding-right: 408px; left: 20px; top: 421px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                    <div style="width: 536px; padding-right: 482px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Gender</div>
                    </div>
                    <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                        <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">Male                          Female </div>
                    </div>
                </div>
                <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 456px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                    <div style="flex: 1 1 0; height: 25px; padding-right: 470px; justify-content: flex-start; align-items: center; display: flex">
                        <div style="width: 536px; padding-right: 466px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Address</div>
                        </div>
                        <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="width: 453px; color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">2337 Kildeer Drive, Kentucky, Canada</div>
                        </div>
                    </div>
                </div>
            </div>
            <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                <div style="flex: 1 1 0; height: 25px; padding-right: 470px; justify-content: flex-start; align-items: center; display: flex">
                    <div style="width: 536px; padding-right: 466px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                        <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Domicile</div>
                    </div>
                    <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                        <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">Sindh</div>
                    </div>
                </div>
            </div>
            <div style="margin-left:1000px; padding-left: 19px; padding-right: 19px; padding-top: 8px; padding-bottom: 8px; background: #46972C; border-radius: 4px; border: 1px #46972C solid; justify-content: flex-start; align-items: center; gap: 4px; display: inline-flex">
                <div style="padding-top: 1px; padding-bottom: 1px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                    <div style="width: 18.45px; height: 18px; padding-top: 1.88px; padding-bottom: 2.62px; padding-left: 0.09px; padding-right: 4.86px; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                        <div style="width: 13.50px; height: 13.50px; background: white"></div>
                    </div>
                </div>
                <div style="padding-left: 7.89px; flex-direction: column; justify-content: flex-start; align-items: center; display: inline-flex">
                    <div style=" text-align: center; color: white; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 20px; letter-spacing: 0.26px; word-wrap: break-word"><a href="update1.php">Download ID Card</a></div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>