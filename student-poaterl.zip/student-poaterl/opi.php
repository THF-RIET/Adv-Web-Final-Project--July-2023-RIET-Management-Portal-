<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Dashboard</title>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link rel="stylesheet" href="css/sb-admin-2.css">
    <style>
        /* Add this to your existing CSS or in a separate stylesheet */
        body {
            margin: 0;
            padding: 0;
            font-family: 'DM Sans', sans-serif; /* Add the desired font-family */
            box-sizing: border-box;
        }

        .main-container {
            width: 100%;
            max-width: 1200px; /* Set a maximum width for the main container */
            margin: 0 auto; /* Center the main container */
            padding: 10px; /* Add padding to the main container */
        }

        /* Add new styles or modifications for responsiveness here */
        @media (max-width: 320px) {
            /* Define styles for smaller screens (example: mobile devices) */
            /* Example: Adjust the styles for smaller screens */
            .opi1 {
                width: 100%;
            }
            /* ... Add more responsive styles as needed */
        }

        
    </style>

</head>
<body>
<?php
   include 'sidebar.php';
?>
                
            <div style="width: 100%; height: 100%; position: relative">
    <div style="height: 64.09px; padding-top: 21px; padding-bottom: 20px; padding-left: 29px; padding-right: 29px; left: -20px; top: 955px; position: absolute; background: white; box-shadow: 0px 1px 3px rgba(54, 74, 99, 0.05); border-top: 1px #E5E9F2 solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
        <div style="padding-right: 979px; justify-content: flex-start; align-items: center; display: inline-flex">
            <div style="align-self: stretch; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word"></div>
            </div>
        </div>
    </div>
    <div style="width: 1572px; height: 845px; left: 22px; top: 41px; position: absolute; background: white; box-shadow: 0px 1px 3px rgba(54, 74, 99, 0.05); border-radius: 4px">
        <div style="height: 795px; padding-bottom: 0.44px; left: 0px; top: 0px; position: absolute; justify-content: center; align-items: flex-start; display: inline-flex">
            <div style="width: 380px; align-self: stretch; padding-bottom: 63px; padding-right: 1px; border-right: 1px #E5E9F2 solid; flex-direction: column; justify-content: flex-start; align-items: center; display: inline-flex">
                <div style="align-self: stretch; height: 604px; flex-direction: column; justify-content: center; align-items: center; display: inline-flex">
                    <div style="width: 379px; height: 604.27px; position: relative; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                        <div style="height: 91.89px; padding-top: 24px; padding-bottom: 25px; padding-left: 24px; padding-right: 24px; border-bottom: 1px #DBDFEA solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="width: 331px; justify-content: center; align-items: center; display: inline-flex">
                                <div style="width: 40px; align-self: stretch; padding-top: 8.45px; padding-bottom: 7.55px; padding-left: 9.83px; padding-right: 10.17px; background: #043C8B; border-radius: 20px; justify-content: center; align-items: center; display: inline-flex">
                                    <div style="color: white; font-size: 14px; font-family: DM Sans; font-weight: 700; line-height: 23.10px; letter-spacing: 0.84px; word-wrap: break-word">AB</div>
                                </div>
                                <div style="align-self: stretch; padding-left: 16px; flex-direction: column; justify-content: center; align-items: flex-start; display: inline-flex">
                                    <div style="padding-bottom: 0.80px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                        <div style="color: #364A63; font-size: 14px; font-family: DM Sans; font-weight: 700; line-height: 23.10px; word-wrap: break-word">Abu Bin Ishtiyak</div>
                                        <div style="color: #8094AE; font-size: 12px; font-family: DM Sans; font-weight: 400; line-height: 19.80px; word-wrap: break-word">info@softnio.com</div>
                                    </div>
                                </div>
                                <div style="flex: 1 1 0; align-self: stretch; padding-top: 9px; padding-bottom: 9px; padding-left: 151.54px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="width: 18.45px; height: 18px; padding-top: 0.76px; padding-bottom: 1.49px; padding-left: 0.09px; padding-right: 14.59px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                        <div style="width: 3.76px; height: 15.75px; background: #526484"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div style="width: 379px; height: 52.80px; position: relative">
                            <div style="height: 18px; padding-right: 10px; left: 24px; top: 16.39px; position: absolute; opacity: 0.80; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                <div style="width: 18px; height: 18px; padding-top: 0.47px; padding-bottom: 1.23px; padding-right: 1.72px; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="width: 16.28px; height: 16.29px; background: #043C8B"></div>
                                </div>
                            </div>
                            <div style="left: 56px; top: 16px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                <div style="color: #043C8B; font-size: 14px; font-family: DM Sans; font-weight: 500; line-height: 20.80px; word-wrap: break-word"><a href="Upi.php"> Personal Infomation</a></div>
                            </div>
                            <div style="width: 16px; height: 20.80px; padding-top: 6.07px; padding-bottom: 6.74px; padding-right: 11.34px; left: 343px; top: 36.80px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                <div style="width: 4.66px; height: 7.98px; background: #043C8B"></div>
                            </div>
                        </div>
                        <div style="height: 77.80px; padding-bottom: 1px; border-bottom: 1px #DBDFEA solid; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="height: 76.80px; padding-top: 12px; padding-bottom: 12px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                                <div style="width: 379px; height: 52.80px; position: relative">
                                    <div style="height: 18px; padding-right: 10px; left: 24px; top: 16.39px; position: absolute; opacity: 0.80; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="width: 18px; height: 18px; padding-top: 1.62px; padding-bottom: 2.36px; padding-right: 4.50px; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                            <div style="width: 13.50px; height: 14.03px; background: #8094AE"></div>
                                        </div>
                                    </div>
                                    <div style="left: 56px; top: 16px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 500; line-height: 20.80px; word-wrap: break-word"><a href="Notification.php"> Notifications</a></div>
                                    </div>
                                    <div style="width: 16px; height: 20.80px; padding-top: 6.07px; padding-bottom: 6.74px; padding-right: 11.34px; left: 343px; top: 36.80px; position: absolute; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                        <div style="width: 4.66px; height: 7.98px; background: #8094AE"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div style="width: 331px; height: 104.56px; position: relative">
                            <div style="left: 0px; top: 0px; position: absolute; color: #8094AE; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 1.65px; word-wrap: break-word">Last Login</div>
                            <div style="left: 0px; top: 21.19px; position: absolute; color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">06-29-2020 02:39pm</div>
                            <div style="left: 0px; top: 60.28px; position: absolute; color: #8094AE; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 1.65px; word-wrap: break-word">Login IP</div>
                            <div style="left: 0px; top: 81.47px; position: absolute; color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">192.129.243.28</div>
                        </div>
                    </div>
                </div>
            </div>
            <div style="width: 1192px; height: 794.56px; position: relative; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: flex">
                <div style="justify-content: center; align-items: center; gap: 762px; display: inline-flex">
                    <div style="align-self: stretch; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 7.39px; display: inline-flex">
                        <div style="color: #364A63; font-size: 24px; font-family: DM Sans; font-weight: 700; line-height: 26.40px; word-wrap: break-word">Update Personal Information</div>
                        <div style="color: #526484; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Basic info, like your name and address.</div>
                    </div>
                    <div style="align-self: stretch; padding-top: 9px; padding-bottom: 9px; padding-left: 8.77px; padding-right: 2.78px; justify-content: flex-start; align-items: center; display: inline-flex">
                        <div style="width: 18.45px; height: 18px; padding-top: 1.88px; padding-bottom: 1.11px; padding-left: 0.09px; padding-right: 3.34px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="width: 15.01px; height: 15.01px; background: #526484"></div>
                        </div>
                    </div>
                </div>
                <div style="height: 573.19px; flex-direction: column; justify-content: flex-start; align-items: flex-start; gap: 32px; display: inline-flex">
                    <div style="width: 1112px; height: 573.19px; position: relative">
                        <div style="height: 29.19px; padding-top: 8px; padding-bottom: 7.19px; padding-left: 20px; padding-right: 1042px; left: 0px; top: 0px; position: absolute; background: #EBEEF2; border-radius: 4px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="color: #8094AE; font-size: 11px; font-family: DM Sans; font-weight: 700; text-transform: uppercase; line-height: 13.20px; letter-spacing: 2.20px; word-wrap: break-word">Education </div>
                        </div>
                        <div style="width: 1112px; height: 85px; left: 0px; top: 33.19px; position: absolute; border-bottom: 1px #E5E9F2 solid">
                            <div style="width: 946.11px; padding-right: 426px; left: 20px; top: 30px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                                <div style="width: 536px; padding-right: 472px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Qualification</div>
                                </div>
                            </div>
                            <div style="left: 556px; top: 35.33px; position: absolute; color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">Matriculation</div>
                            <div style="padding-left: 19px; padding-right: 19px; padding-top: 8px; padding-bottom: 8px; left: 1019.11px; top: 24px; position: absolute; background: #46972C; border-radius: 4px; border: 1px #46972C solid; justify-content: flex-start; align-items: center; gap: 4px; display: inline-flex">
                                <div style="padding-left: 7.89px; flex-direction: column; justify-content: flex-start; align-items: center; display: inline-flex">
                                    <div style="text-align: center; color: white; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 20px; letter-spacing: 0.26px; word-wrap: break-word">Add</div>
                                </div>
                            </div>
                        </div>
                        <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 106.94px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                            <div style="flex: 1 1 0; height: 25px; padding-right: 483px; justify-content: flex-start; align-items: center; display: flex">
                                <div style="width: 536px; padding-right: 447px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">SSC %</div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">89%</div>
                                </div>
                            </div>
                        </div>
                        <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 180.69px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                            <div style="flex: 1 1 0; height: 25px; padding-right: 413px; justify-content: flex-start; align-items: center; display: flex">
                                <div style="width: 536px; padding-right: 501px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Upload CNIC </div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">Only  .png</div>
                                </div>
                            </div>
                        </div>
                        <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 254.44px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                            <div style="flex: 1 1 0; height: 25px; padding-right: 454px; justify-content: flex-start; align-items: center; display: flex">
                                <div style="width: 536px; padding-right: 439px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Upload CNIC </div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">Only.png </div>
                                </div>
                            </div>
                        </div>
                        <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 328.19px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                            <div style="flex: 1 1 0; height: 25px; padding-right: 449px; justify-content: flex-start; align-items: center; display: flex">
                                <div style="width: 536px; padding-right: 455px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Father CNIC </div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">Only select .png format</div>
                                </div>
                            </div>
                        </div>
                        <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; left: 0px; top: 401.94px; position: absolute; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                            <div style="flex: 1 1 0; height: 25px; padding-right: 470px; justify-content: flex-start; align-items: center; display: flex">
                                <div style="width: 536px; padding-right: 466px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word">Upload Father CNIC (Back)</div>
                                </div>
                                <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                    <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word"> select.png </div>
                                </div>
                            </div>
                        </div>
                        <div style="width: 1072px; padding-right: 408px; left: 20px; top: 512.19px; position: absolute; justify-content: flex-start; align-items: center; display: inline-flex">
                            <div style="width: 536px; padding-right: 482px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word"> Matriculation Marksheet </div>
                            </div>
                            <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                                <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word">select.png </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div style="width: 1112px; padding-top: 24px; padding-bottom: 25px; padding-left: 20px; padding-right: 20px; border-bottom: 1px #E5E9F2 solid; justify-content: flex-start; align-items: center; display: inline-flex">
                    <div style="flex: 1 1 0; height: 25px; padding-right: 470px; justify-content: flex-start; align-items: center; display: flex">
                        <div style="width: 536px; padding-right: 466px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="color: #8094AE; font-size: 14px; font-family: DM Sans; font-weight: 400; line-height: 23.10px; word-wrap: break-word"> Matriculation Marksheet </div>
                        </div>
                        <div style="flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                            <div style="color: #526484; font-size: 15px; font-family: DM Sans; font-weight: 400; line-height: 24.75px; word-wrap: break-word"> select .png </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div style="padding-left: 19px; padding-right: 19px; padding-top: 8px; padding-bottom: 8px; left: 1413px; top: 795px; position: absolute; background: #46972C; border-radius: 4px; border: 1px #46972C solid; justify-content: flex-start; align-items: center; gap: 4px; display: inline-flex">
            <div style="padding-top: 1px; padding-bottom: 1px; flex-direction: column; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                <div style="width: 18.45px; height: 18px; padding-top: 1.88px; padding-bottom: 2.62px; padding-left: 0.09px; padding-right: 4.86px; justify-content: flex-start; align-items: flex-start; display: inline-flex">
                    <div style="width: 13.50px; height: 13.50px; background: white"></div>
                </div>
            </div>
            <div style="padding-left: 7.89px; flex-direction: column; justify-content: flex-start; align-items: center; display: inline-flex">
                <div style="text-align: center; color: white; font-size: 13px; font-family: DM Sans; font-weight: 700; line-height: 20px; letter-spacing: 0.26px; word-wrap: break-word"><a href="UPI.php">Update</a></div>
            </div>
        </div>
    </div>
</div>
</div> 



                
                <!-- End of Page Wrapper -->
             
                <!-- Scroll to Top Button-->
                <a class="scroll-to-top rounded" href="#page-top">
                    <i class="fas fa-angle-up"></i>
                </a>
                <!-- Bootstrap core JavaScript-->
                <script src="vendor/jquery/jquery.min.js"></script>
                <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

                <!-- Core plugin JavaScript-->
                <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

                <!-- Custom scripts for all pages-->
                <script src="js/sb-admin-2.min.js"></script>

                <!-- Page level plugins -->
                <script src="vendor/chart.js/Chart.min.js"></script>

                <!-- Page level custom scripts -->
                <script src="js/demo/chart-area-demo.js"></script>
                <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>